// Class NCLevelSequence.CutsceneBlendCameraNC01
// Size: 0x230 (Inherited: 0x220)
struct ACutsceneBlendCameraNC01 : AActor {
	struct UCameraComponent* CameraComponent; // 0x220(0x08)
	struct USceneComponent* SceneComponent; // 0x228(0x08)
};

// Class NCLevelSequence.CutsceneBlendCameraCineTypeNC01
// Size: 0x238 (Inherited: 0x230)
struct ACutsceneBlendCameraCineTypeNC01 : ACutsceneBlendCameraNC01 {
	struct UCineCameraComponent* CineCameraComponent; // 0x230(0x08)
};

// Class NCLevelSequence.LevelSequenceBlendPlayerNC01
// Size: 0xdb0 (Inherited: 0xb88)
struct ULevelSequenceBlendPlayerNC01 : ULevelSequencePlayer {
	char pad_B88[0x208]; // 0xb88(0x208)
	struct ULevelSequence* PrePhaseSequence; // 0xd90(0x08)
	struct UMovieSceneSequence* OriginalSequence; // 0xd98(0x08)
	struct ULevelSequence* PostPhaseSequence; // 0xda0(0x08)
	bool bDebugNoUseMotionBlend; // 0xda8(0x01)
	char pad_DA9[0x7]; // 0xda9(0x07)

	void SkipCutScene(); // Function NCLevelSequence.LevelSequenceBlendPlayerNC01.SkipCutScene // (Final|Native|Public|BlueprintCallable) // @ game+0xa434e0
	void SetCutSceneBlendOption(struct FCutSceneBlendTimeOption& TimeOption); // Function NCLevelSequence.LevelSequenceBlendPlayerNC01.SetCutSceneBlendOption // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa43420
	void AddActorBindingCutSceneBlend(struct FCutSceneBlendActorBinding& BindingActorData); // Function NCLevelSequence.LevelSequenceBlendPlayerNC01.AddActorBindingCutSceneBlend // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa42fe0
};

// Class NCLevelSequence.LevelSequenceLoadingLibrary
// Size: 0x28 (Inherited: 0x28)
struct ULevelSequenceLoadingLibrary : UBlueprintFunctionLibrary {

	void OnLevelSequenceLoaded__DelegateSignature(struct ULevelSequence* LevelSequence, struct USequenceDynamicParameterListNC01* DynamicParamDataList); // DelegateFunction NCLevelSequence.LevelSequenceLoadingLibrary.OnLevelSequenceLoaded__DelegateSignature // (Public|Delegate) // @ game+0x2849850
	void MarkAsRecent(struct FSoftObjectPath InLevelSequence); // Function NCLevelSequence.LevelSequenceLoadingLibrary.MarkAsRecent // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0xa43340
	void LoadLevelSequence(struct FSoftObjectPath InLevelSequence, struct FSoftObjectPath InDynamicParamDataList, struct FDelegate OnLoaded, int32_t InPriority, bool InReleaseWhenEndOfPlay); // Function NCLevelSequence.LevelSequenceLoadingLibrary.LoadLevelSequence // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0xa430f0
};

