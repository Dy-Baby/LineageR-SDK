// WidgetBlueprintGeneratedClass UI_HUD_ItemLog_All.UI_HUD_ItemLog_All_C
// Size: 0x3d8 (Inherited: 0x398)
struct UUI_HUD_ItemLog_All_C : ULMRItemLogWidget {
	struct UWidgetAnimation* Ani_UP_FadeIn; // 0x398(0x08)
	struct UWidgetAnimation* ani_Up; // 0x3a0(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot; // 0x3a8(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot_2; // 0x3b0(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot_3; // 0x3b8(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot_4; // 0x3c0(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot_5; // 0x3c8(0x08)
	struct UUI_HUD_ItemLogSlot_C* UI_HUD_ItemLog_Slot_6; // 0x3d0(0x08)
};

