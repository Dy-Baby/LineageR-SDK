// BlueprintGeneratedClass BP_MoveArrowDecal_Core.BP_MoveArrowDecal_Core_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_MoveArrowDecal_Core_C : ALMRMoveArrowDecal {
};

