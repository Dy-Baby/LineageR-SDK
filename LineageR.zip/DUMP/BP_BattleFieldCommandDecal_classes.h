// BlueprintGeneratedClass BP_BattleFieldCommandDecal.BP_BattleFieldCommandDecal_C
// Size: 0x250 (Inherited: 0x250)
struct ABP_BattleFieldCommandDecal_C : ALMRDecalActor {
};

