// WidgetBlueprintGeneratedClass BP_NcSimpleLoginSlotWidget.BP_NcSimpleLoginSlotWidget_C
// Size: 0x570 (Inherited: 0x570)
struct UBP_NcSimpleLoginSlotWidget_C : UNcSimpleLoginSlotWidget {
};

