// WidgetBlueprintGeneratedClass UI_HUD_LocalName.UI_HUD_LocalName_C
// Size: 0x2f0 (Inherited: 0x2d8)
struct UUI_HUD_LocalName_C : ULMRLocalNameWidget {
	struct ULMRImage* FX_Dot; // 0x2d8(0x08)
	struct ULMRImage* FX_Line; // 0x2e0(0x08)
	struct ULMRImage* img_Bg; // 0x2e8(0x08)
};

