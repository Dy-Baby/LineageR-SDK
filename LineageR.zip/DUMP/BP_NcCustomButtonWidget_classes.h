// WidgetBlueprintGeneratedClass BP_NcCustomButtonWidget.BP_NcCustomButtonWidget_C
// Size: 0x408 (Inherited: 0x408)
struct UBP_NcCustomButtonWidget_C : UNcCustomButtonWidget {
};

