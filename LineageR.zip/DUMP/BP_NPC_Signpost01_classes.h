// BlueprintGeneratedClass BP_NPC_Signpost01.BP_NPC_Signpost01_C
// Size: 0x250 (Inherited: 0x250)
struct ABP_NPC_Signpost01_C : ALMRSignPost {
};

