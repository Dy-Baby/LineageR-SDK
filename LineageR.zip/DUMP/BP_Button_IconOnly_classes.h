// WidgetBlueprintGeneratedClass BP_Button_IconOnly.BP_Button_IconOnly_C
// Size: 0x328 (Inherited: 0x310)
struct UBP_Button_IconOnly_C : ULMRTemplateIconButton {
	struct UWidgetAnimation* ani_select; // 0x310(0x08)
	struct ULMRImage* Img_Focuse; // 0x318(0x08)
	struct ULMRImage* img_Glow; // 0x320(0x08)
};

