// WidgetBlueprintGeneratedClass UI_Chat_TranslateBtn.UI_Chat_TranslateBtn_C
// Size: 0x348 (Inherited: 0x308)
struct UUI_Chat_TranslateBtn_C : ULMRChatTranslationButtonWidget {
	struct UWidgetAnimation* Ani_Load; // 0x308(0x08)
	struct ULMRImage* LMRImage; // 0x310(0x08)
	struct ULMRImage* LMRImage_2; // 0x318(0x08)
	struct ULMRImage* LMRImage_3; // 0x320(0x08)
	struct ULMRImage* LMRImage_4; // 0x328(0x08)
	struct ULMRImage* LMRImage_5; // 0x330(0x08)
	struct ULMRImage* LMRImage_59; // 0x338(0x08)
	struct ULMRCheckBox* ToggleButton_AutoTrans_N; // 0x340(0x08)
};

