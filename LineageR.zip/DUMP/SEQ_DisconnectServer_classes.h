// BlueprintGeneratedClass SEQ_DisconnectServer.SequenceDirector_C
// Size: 0x38 (Inherited: 0x30)
struct USequenceDirector_C : ULevelSequenceDirector {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x30(0x08)

	void SequenceEvent__ENTRYPOINTSequenceDirector_1(struct USkeletalMeshComponent* SkeletalMeshComponent0); // Function SEQ_DisconnectServer.SequenceDirector_C.SequenceEvent__ENTRYPOINTSequenceDirector_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2849850
	void SkeletalMeshComponent0_Event_1(struct USkeletalMeshComponent* SkeletalMeshComponent0); // Function SEQ_DisconnectServer.SequenceDirector_C.SkeletalMeshComponent0_Event_1 // (BlueprintCallable|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_SequenceDirector(int32_t EntryPoint); // Function SEQ_DisconnectServer.SequenceDirector_C.ExecuteUbergraph_SequenceDirector // (Final|UbergraphFunction) // @ game+0x2849850
};

