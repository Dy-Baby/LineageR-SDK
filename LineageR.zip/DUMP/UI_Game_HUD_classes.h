// WidgetBlueprintGeneratedClass UI_Game_HUD.UI_Game_HUD_C
// Size: 0x490 (Inherited: 0x440)
struct UUI_Game_HUD_C : ULMRGameHUDWidget {
	struct UUI_HUD_autoSlot_C* UI_HUD_autoSlot; // 0x440(0x08)
	struct Uui_HUD_buff_SlotList_C* ui_HUD_buff_SlotList; // 0x448(0x08)
	struct UUI_HUD_Communication_C* UI_HUD_Communication; // 0x450(0x08)
	struct UUI_HUD_DeviceStatus_C* UI_HUD_DeviceStatus; // 0x458(0x08)
	struct UUI_HUD_ItemLog_All_C* UI_HUD_ItemLog_All; // 0x460(0x08)
	struct UUI_HUD_menu_C* UI_HUD_menu; // 0x468(0x08)
	struct UUI_HUD_Noti_Scroll_new_C* UI_HUD_Noti_Scroll_new; // 0x470(0x08)
	struct UUI_HUD_QSlot_C* UI_HUD_QSlot; // 0x478(0x08)
	struct UUI_HUD_SpellCycle_C* UI_HUD_SpellCycle; // 0x480(0x08)
	struct UUI_InstDungeonTimeout_C* UI_InstDungeonTimeout; // 0x488(0x08)
};

