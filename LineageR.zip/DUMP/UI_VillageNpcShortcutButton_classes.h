// WidgetBlueprintGeneratedClass UI_VillageNpcShortcutButton.UI_VillageNpcShortcutButton_C
// Size: 0x538 (Inherited: 0x500)
struct UUI_VillageNpcShortcutButton_C : ULMRVillageNpcShortcutButtonWidget {
	struct UOverlay* BG_Black; // 0x500(0x08)
	struct ULMRImage* ButtonBg; // 0x508(0x08)
	struct ULMRImage* fx_circle_Deco_N; // 0x510(0x08)
	struct ULMRImage* fx_circle_glowOutline_N; // 0x518(0x08)
	struct ULMRImage* fx_glow_N; // 0x520(0x08)
	struct ULMRImage* img_Icon; // 0x528(0x08)
	struct ULMRImage* Img_Icon_Close; // 0x530(0x08)
};

