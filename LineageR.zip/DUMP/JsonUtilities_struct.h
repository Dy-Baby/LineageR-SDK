// ScriptStruct JsonUtilities.JsonObjectWrapper
// Size: 0x20 (Inherited: 0x00)
struct FJsonObjectWrapper {
	struct FString JsonString; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

