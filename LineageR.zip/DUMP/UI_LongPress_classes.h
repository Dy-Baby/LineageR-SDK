// WidgetBlueprintGeneratedClass UI_LongPress.UI_LongPress_C
// Size: 0x440 (Inherited: 0x440)
struct UUI_LongPress_C : ULMRLongPressWidget {
};

