// Class AppsFlyerSDK.AppsFlyerSDKBlueprint
// Size: 0x28 (Inherited: 0x28)
struct UAppsFlyerSDKBlueprint : UBlueprintFunctionLibrary {

	void waitForATTUserAuthorizationWithTimeoutInterval(int32_t timeoutInterval); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.waitForATTUserAuthorizationWithTimeoutInterval // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x434dd90
	void Start(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.Start // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f65b0
	void setCustomerUserId(struct FString customerUserId); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.setCustomerUserId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x434dcc0
	void logEvent(struct FString EventName, struct TMap<struct FString, struct FString> Values); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.logEvent // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x434daf0
	struct FString getAppsFlyerUID(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.getAppsFlyerUID // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x434da70
	struct FString advertisingIdentifier(); // Function AppsFlyerSDK.AppsFlyerSDKBlueprint.advertisingIdentifier // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x434da70
};

// Class AppsFlyerSDK.AppsFlyerSDKCallbacks
// Size: 0xf0 (Inherited: 0xb0)
struct UAppsFlyerSDKCallbacks : UActorComponent {
	struct FMulticastInlineDelegate OnAppOpenAttribution; // 0xb0(0x10)
	struct FMulticastInlineDelegate OnConversionDataReceived; // 0xc0(0x10)
	struct FMulticastInlineDelegate OnAppOpenAttributionFailure; // 0xd0(0x10)
	struct FMulticastInlineDelegate OnConversionDataRequestFailure; // 0xe0(0x10)
};

// Class AppsFlyerSDK.AppsFlyerSDKSettings
// Size: 0x68 (Inherited: 0x28)
struct UAppsFlyerSDKSettings : UObject {
	struct FString appsFlyerDevKey; // 0x28(0x10)
	struct FString appleAppID; // 0x38(0x10)
	bool bIsDebug; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString CurrencyCode; // 0x50(0x10)
	bool bDisableSKAdNetwork; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

