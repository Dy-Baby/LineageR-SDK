// Class CommunitySdk.CommunityButtonWidget
// Size: 0x278 (Inherited: 0x258)
struct UCommunityButtonWidget : UUserWidget {
	struct FString Label; // 0x258(0x10)
	struct FMulticastInlineDelegate OnClickDelegate; // 0x268(0x10)
};

// Class CommunitySdk.CommunityChatAPI
// Size: 0x28 (Inherited: 0x28)
struct UCommunityChatAPI : UBlueprintFunctionLibrary {

	void SetConfigInfoWithUrl(struct FString ApiSrvUrl); // Function CommunitySdk.CommunityChatAPI.SetConfigInfoWithUrl // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f71a0
	void SetConfigInfo(struct FString AppVersion, struct FString ApiSrvUrl); // Function CommunitySdk.CommunityChatAPI.SetConfigInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f70c0
};

// Class CommunitySdk.CommunityCoreAPI
// Size: 0x28 (Inherited: 0x28)
struct UCommunityCoreAPI : UBlueprintFunctionLibrary {

	void SetLocale(struct FString Locale); // Function CommunitySdk.CommunityCoreAPI.SetLocale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f73d0
	void SetLanguageCode(struct FString languageCode); // Function CommunitySdk.CommunityCoreAPI.SetLanguageCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7340
	void SetEnableLog(bool Enabled); // Function CommunitySdk.CommunityCoreAPI.SetEnableLog // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f72c0
	void SetCountryCode(struct FString CountryCode); // Function CommunitySdk.CommunityCoreAPI.SetCountryCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7230
	bool IsInitialized(); // Function CommunitySdk.CommunityCoreAPI.IsInitialized // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6ce0
	bool IsEnabledLog(); // Function CommunitySdk.CommunityCoreAPI.IsEnabledLog // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6cb0
	void Initialize(struct FString AppID, struct FString AppSecret, struct FString AppVersion, struct FString LocalConfigFile); // Function CommunitySdk.CommunityCoreAPI.Initialize // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6b10
	struct FString GetSdkVersion(); // Function CommunitySdk.CommunityCoreAPI.GetSdkVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6a70
	struct FString GetLocale(); // Function CommunitySdk.CommunityCoreAPI.GetLocale // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f69f0
	struct FString GetLanguageCode(); // Function CommunitySdk.CommunityCoreAPI.GetLanguageCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6970
	struct FString GetCountryCode(); // Function CommunitySdk.CommunityCoreAPI.GetCountryCode // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f68f0
	struct FString GetAppVersion(); // Function CommunitySdk.CommunityCoreAPI.GetAppVersion // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6870
	struct FString GetAppSecret(); // Function CommunitySdk.CommunityCoreAPI.GetAppSecret // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f67f0
	struct FString GetAppId(); // Function CommunitySdk.CommunityCoreAPI.GetAppId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6770
	struct UCommunityCoreAPI* Get(); // Function CommunitySdk.CommunityCoreAPI.Get // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8f6710
};

// Class CommunitySdk.CommunityLaunchExternalWebBrowserDialogWidget
// Size: 0x268 (Inherited: 0x258)
struct UCommunityLaunchExternalWebBrowserDialogWidget : UUserWidget {
	struct FString TargetUrl; // 0x258(0x10)

	void Show(); // Function CommunitySdk.CommunityLaunchExternalWebBrowserDialogWidget.Show // (Final|Native|Public) // @ game+0x8f74f0
	void LaunchExternalWebrowser(struct FString URL); // Function CommunitySdk.CommunityLaunchExternalWebBrowserDialogWidget.LaunchExternalWebrowser // (Final|Native|Public|BlueprintCallable) // @ game+0x8f6d10
	void Hide(); // Function CommunitySdk.CommunityLaunchExternalWebBrowserDialogWidget.Hide // (Final|Native|Public) // @ game+0x8f6af0
};

// Class CommunitySdk.CommunityLiveAPI
// Size: 0x28 (Inherited: 0x28)
struct UCommunityLiveAPI : UBlueprintFunctionLibrary {

	struct UCommunityLiveAPI* Get(); // Function CommunitySdk.CommunityLiveAPI.Get // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8f6730
};

// Class CommunitySdk.CommunityUIAPI
// Size: 0x28 (Inherited: 0x28)
struct UCommunityUIAPI : UBlueprintFunctionLibrary {

	void UpdateGameCharacter(struct FString GameAccountID, struct FString ServerId, struct FString ServerName, struct FString CharacterId, struct FString CharacterName, struct FString GroupID, struct FString GroupName, int32_t Level); // Function CommunitySdk.CommunityUIAPI.UpdateGameCharacter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f75b0
	void StartWidget(bool Visible); // Function CommunitySdk.CommunityUIAPI.StartWidget // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7530
	void ShutdownWidget(); // Function CommunitySdk.CommunityUIAPI.ShutdownWidget // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7510
	void SetStoreType(struct FString StoreType); // Function CommunitySdk.CommunityUIAPI.SetStoreType // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6680
	void SetServiceAlias(struct FString ServiceAlias); // Function CommunitySdk.CommunityUIAPI.SetServiceAlias // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7460
	void SetBuildAge(struct FString BuildAge); // Function CommunitySdk.CommunityUIAPI.SetBuildAge // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7030
	void OpenWidgetMenu(); // Function CommunitySdk.CommunityUIAPI.OpenWidgetMenu // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f7010
	void OpenCommunityEx(struct FString AuthnToken, struct FString Login_Url, struct FString Target_Url); // Function CommunitySdk.CommunityUIAPI.OpenCommunityEx // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6ee0
	void OpenCommunity(struct FString Uri); // Function CommunitySdk.CommunityUIAPI.OpenCommunity // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6e50
	void Initialize(); // Function CommunitySdk.CommunityUIAPI.Initialize // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6c90
	struct UCommunityUIAPI* Get(); // Function CommunitySdk.CommunityUIAPI.Get // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8f6750
	void Execute(struct FString Uri); // Function CommunitySdk.CommunityUIAPI.Execute // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6680
	void DidCompleteScreenShot(struct FString ScreenshotFilePath); // Function CommunitySdk.CommunityUIAPI.DidCompleteScreenShot // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f65f0
	void CloseWidgetMenu(); // Function CommunitySdk.CommunityUIAPI.CloseWidgetMenu // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f65d0
	void CloseCommunityLive(); // Function CommunitySdk.CommunityUIAPI.CloseCommunityLive // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f65b0
	void CloseCommunity(); // Function CommunitySdk.CommunityUIAPI.CloseCommunity // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6590
	void ClearGameCharacter(); // Function CommunitySdk.CommunityUIAPI.ClearGameCharacter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f6570
	void ApplyPlugin(struct FString PluginName, struct FString Network, struct FString Region, struct FString ConfigPath); // Function CommunitySdk.CommunityUIAPI.ApplyPlugin // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x8f63f0
	void AddThemeFiles(struct TArray<struct FString>& FilePaths, struct FString DefaultThemeFilePath); // Function CommunitySdk.CommunityUIAPI.AddThemeFiles // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x8f62d0
};

// Class CommunitySdk.CommunityWebViewWidget
// Size: 0x280 (Inherited: 0x258)
struct UCommunityWebViewWidget : UUserWidget {
	struct UWebBrowser* CommunityWebBrowser; // 0x258(0x08)
	struct UButton* CloseButton; // 0x260(0x08)
	struct UButton* BackButton; // 0x268(0x08)
	struct FString HomeURL; // 0x270(0x10)

	void Show(); // Function CommunitySdk.CommunityWebViewWidget.Show // (Final|Native|Public) // @ game+0x8f74f0
	void LoadURL(struct FString URL); // Function CommunitySdk.CommunityWebViewWidget.LoadURL // (Final|Native|Public) // @ game+0x8f6db0
	void Hide(); // Function CommunitySdk.CommunityWebViewWidget.Hide // (Final|Native|Public) // @ game+0x8f6af0
};

// Class CommunitySdk.GoogleSTTAPI
// Size: 0x28 (Inherited: 0x28)
struct UGoogleSTTAPI : UBlueprintFunctionLibrary {

	struct UGoogleSTTAPI* Get(); // Function CommunitySdk.GoogleSTTAPI.Get // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x8fcba0
};

// Class CommunitySdk.TranslateAPI
// Size: 0x28 (Inherited: 0x28)
struct UTranslateAPI : UBlueprintFunctionLibrary {

	struct FString Translate(struct FString SourceLanguage, struct FString SourceText, struct FString TargetLanguage, struct FString SentFrom, float MilliSec); // Function CommunitySdk.TranslateAPI.Translate // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x907900
	bool SetConfigInfo(struct FString ApiSrvUrl, struct FString GameCode); // Function CommunitySdk.TranslateAPI.SetConfigInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x907810
	bool IsInitialized(); // Function CommunitySdk.TranslateAPI.IsInitialized // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x9077e0
};

// Class CommunitySdk.VoiceRecorder
// Size: 0x540 (Inherited: 0x4c0)
struct AVoiceRecorder : ACharacter {
	char pad_4C0[0x80]; // 0x4c0(0x80)
};

