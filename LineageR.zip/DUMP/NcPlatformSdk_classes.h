// Class NcPlatformSdk.NcWidgetBase
// Size: 0x3e0 (Inherited: 0x258)
struct UNcWidgetBase : UUserWidget {
	char pad_258[0x18]; // 0x258(0x18)
	struct UNcWidget_Template* NcWidget_Template; // 0x270(0x08)
	char pad_278[0x10]; // 0x278(0x10)
	enum class ENcWidgetColorType Color; // 0x288(0x01)
	char pad_289[0x157]; // 0x289(0x157)

	void BroadcastOnClickCloseButton(); // Function NcPlatformSdk.NcWidgetBase.BroadcastOnClickCloseButton // (Final|Native|Public) // @ game+0x8946b0
};

// Class NcPlatformSdk.NcAlertWidget
// Size: 0x400 (Inherited: 0x3e0)
struct UNcAlertWidget : UNcWidgetBase {
	struct UNcRichTextBlock* MessageTextBlock; // 0x3e0(0x08)
	struct UNcBorder* ContentBorder; // 0x3e8(0x08)
	struct UScrollBox* ContentScrollBox; // 0x3f0(0x08)
	struct USizeBox* ContentSizeBox; // 0x3f8(0x08)
};

// Class NcPlatformSdk.NcAgeSelectWidget
// Size: 0x430 (Inherited: 0x400)
struct UNcAgeSelectWidget : UNcAlertWidget {
	char pad_400[0x18]; // 0x400(0x18)
	struct UNcRichTextBlock* UnderlineButtonText; // 0x418(0x08)
	struct UNcButton* UnderlineButton; // 0x420(0x08)
	struct UVerticalBox* BottomSlot; // 0x428(0x08)

	void OnClickUnderLineButtonHandler(); // Function NcPlatformSdk.NcAgeSelectWidget.OnClickUnderLineButtonHandler // (Final|Native|Private) // @ game+0x891530
};

// Class NcPlatformSdk.NcAssetLoader
// Size: 0x28 (Inherited: 0x28)
struct UNcAssetLoader : UObject {
};

// Class NcPlatformSdk.NcAuthAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcAuthAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcBackupAuthAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcBackupAuthAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcBaseAnimationDialogWidget
// Size: 0x448 (Inherited: 0x3e0)
struct UNcBaseAnimationDialogWidget : UNcWidgetBase {
	struct FAnimationDialogAnimation ShowAnimation; // 0x3e0(0x18)
	struct FAnimationDialogAnimation HideAnimation; // 0x3f8(0x18)
	char pad_410[0x38]; // 0x410(0x38)
};

// Class NcPlatformSdk.NcBorder
// Size: 0x2d0 (Inherited: 0x298)
struct UNcBorder : UBorder {
	char pad_298[0x8]; // 0x298(0x08)
	enum class ENcWidgetBorderType BorderType; // 0x2a0(0x01)
	char pad_2A1[0x3]; // 0x2a1(0x03)
	struct FLinearColor WidgetColor; // 0x2a4(0x10)
	bool bWillChangeColorWhenChildIsFocused; // 0x2b4(0x01)
	char pad_2B5[0x3]; // 0x2b5(0x03)
	struct FLinearColor FocusedColor; // 0x2b8(0x10)
	int32_t BorderRadius; // 0x2c8(0x04)
	char pad_2CC[0x4]; // 0x2cc(0x04)
};

// Class NcPlatformSdk.NcBorder_Background
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Background : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_Box
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Box : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_Line1
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Line1 : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_Line2
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Line2 : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_PointText
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_PointText : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_Text1
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Text1 : UNcBorder {
};

// Class NcPlatformSdk.NcBorder_Text2
// Size: 0x2d0 (Inherited: 0x2d0)
struct UNcBorder_Text2 : UNcBorder {
};

// Class NcPlatformSdk.NcButton
// Size: 0x4b8 (Inherited: 0x450)
struct UNcButton : UButton {
	enum class ENcWidgetBorderType BorderType; // 0x450(0x01)
	char pad_451[0x3]; // 0x451(0x03)
	struct FLinearColor NormalColorType; // 0x454(0x10)
	struct FLinearColor HoveredColorType; // 0x464(0x10)
	struct FLinearColor PressedColorType; // 0x474(0x10)
	struct FLinearColor DisabledColorType; // 0x484(0x10)
	int32_t BorderRadius; // 0x494(0x04)
	struct FLinearColor NormalButtonTextColor; // 0x498(0x10)
	struct FLinearColor DisabledButtonTextColor; // 0x4a8(0x10)
};

// Class NcPlatformSdk.NcButton_Button1
// Size: 0x4b8 (Inherited: 0x4b8)
struct UNcButton_Button1 : UNcButton {
};

// Class NcPlatformSdk.NcButton_Button2
// Size: 0x4b8 (Inherited: 0x4b8)
struct UNcButton_Button2 : UNcButton {
};

// Class NcPlatformSdk.NcCampaignAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcCampaignAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcCheckBox
// Size: 0x428 (Inherited: 0x3e0)
struct UNcCheckBox : UNcWidgetBase {
	char pad_3E0[0x18]; // 0x3e0(0x18)
	struct FLinearColor UncheckedColor; // 0x3f8(0x10)
	struct FLinearColor CheckedColor; // 0x408(0x10)
	struct UImage* Background; // 0x418(0x08)
	struct UCheckBox* CheckBox; // 0x420(0x08)

	void BroadcastCheckStateChanged(bool bIsChecked); // Function NcPlatformSdk.NcCheckBox.BroadcastCheckStateChanged // (Final|Native|Private) // @ game+0x890e10
};

// Class NcPlatformSdk.NcCoinPaymentAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcCoinPaymentAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcConfigurationAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcConfigurationAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcConsoleAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcConsoleAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcCountrySelectWidget
// Size: 0x468 (Inherited: 0x3e0)
struct UNcCountrySelectWidget : UNcWidgetBase {
	struct UNcBorder* CountrySelectorBorder; // 0x3e0(0x08)
	struct UComboBoxString* CountrySelector; // 0x3e8(0x08)
	struct USizeBox* CountrySelectorSizeBox; // 0x3f0(0x08)
	char pad_3F8[0x70]; // 0x3f8(0x70)

	void SetSelectedOptionToInitialCountry(); // Function NcPlatformSdk.NcCountrySelectWidget.SetSelectedOptionToInitialCountry // (Final|Native|Public) // @ game+0x8918d0
	void SetInitialCountry(struct FString CountryCode); // Function NcPlatformSdk.NcCountrySelectWidget.SetInitialCountry // (Final|Native|Public) // @ game+0x891830
	void OnCountrySelectChanged(struct FString SelectedItem, enum class ESelectInfo SelectionType); // Function NcPlatformSdk.NcCountrySelectWidget.OnCountrySelectChanged // (Final|Native|Private) // @ game+0x891570
	void LockSelection(); // Function NcPlatformSdk.NcCountrySelectWidget.LockSelection // (Final|Native|Public) // @ game+0x891480
	struct FString GetSelectedCountry(); // Function NcPlatformSdk.NcCountrySelectWidget.GetSelectedCountry // (Final|Native|Public) // @ game+0x891200
	void AddCountry(struct FString CountryCode); // Function NcPlatformSdk.NcCountrySelectWidget.AddCountry // (Final|Native|Public) // @ game+0x890d70
};

// Class NcPlatformSdk.NcCouponAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcCouponAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcCustomButtonWidget
// Size: 0x408 (Inherited: 0x3e0)
struct UNcCustomButtonWidget : UNcWidgetBase {
	struct UNcButton* CustomButton; // 0x3e0(0x08)
	struct UImage* CustomButtonLeftIcon; // 0x3e8(0x08)
	struct UImage* CustomButtonRightIcon; // 0x3f0(0x08)
	struct UNcRichTextBlock* CustomButtonText; // 0x3f8(0x08)
	struct UNcBorder* ButtonBorder; // 0x400(0x08)
};

// Class NcPlatformSdk.NcDailyStampAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcDailyStampAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcDeviceListSlotWidget
// Size: 0x4a0 (Inherited: 0x3e0)
struct UNcDeviceListSlotWidget : UNcWidgetBase {
	char pad_3E0[0x58]; // 0x3e0(0x58)
	struct UCanvasPanel* SlotPanel; // 0x438(0x08)
	struct UButton* ButtonDelete; // 0x440(0x08)
	struct UButton* ButtonChangeName; // 0x448(0x08)
	struct UNcRichTextBlock* TextDelete; // 0x450(0x08)
	struct UNcRichTextBlock* TextChangeName; // 0x458(0x08)
	struct UTextBlock* TextDeviceName; // 0x460(0x08)
	struct UTextBlock* TextRegistrationDate; // 0x468(0x08)
	struct USizeBox* DeviceNameSizeBox; // 0x470(0x08)
	struct UCanvasPanel* VerticalLineCanvas; // 0x478(0x08)
	struct UNcBorder* Background; // 0x480(0x08)
	struct UNcBorder* TopLine; // 0x488(0x08)
	struct UNcBorder* BottomLine; // 0x490(0x08)
	struct UNcBorder* VerticalLine; // 0x498(0x08)

	void BroadcastOnClickDelete(); // Function NcPlatformSdk.NcDeviceListSlotWidget.BroadcastOnClickDelete // (Final|Native|Private) // @ game+0x891050
	void BroadcastOnClickChangeName(); // Function NcPlatformSdk.NcDeviceListSlotWidget.BroadcastOnClickChangeName // (Final|Native|Private) // @ game+0x891010
};

// Class NcPlatformSdk.NcDeviceListWidget
// Size: 0x460 (Inherited: 0x3e0)
struct UNcDeviceListWidget : UNcWidgetBase {
	char pad_3E0[0x40]; // 0x3e0(0x40)
	struct UTextBlock* TextTitle; // 0x420(0x08)
	struct UTextBlock* TextSelectDevice; // 0x428(0x08)
	struct UTextBlock* TextNote1; // 0x430(0x08)
	struct UTextBlock* TextNote2; // 0x438(0x08)
	struct UTextBlock* TextNote3; // 0x440(0x08)
	struct USizeBox* ScrollContentsSizeBox; // 0x448(0x08)
	struct UScrollBox* ContentScroll; // 0x450(0x08)
	struct UVerticalBox* DeviceListBox; // 0x458(0x08)
};

// Class NcPlatformSdk.NcDimmedWidget
// Size: 0x3e8 (Inherited: 0x3e0)
struct UNcDimmedWidget : UNcWidgetBase {
	struct UNcBorder* Background; // 0x3e0(0x08)
};

// Class NcPlatformSdk.NcExtraAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcExtraAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcGeneralWebViewWidget
// Size: 0x4a0 (Inherited: 0x3e0)
struct UNcGeneralWebViewWidget : UNcWidgetBase {
	char pad_3E0[0x90]; // 0x3e0(0x90)
	struct UHorizontalBox* CloseHorizontalBox; // 0x470(0x08)
	struct USpacer* CloseSpacer; // 0x478(0x08)
	struct UButton* CloseButton; // 0x480(0x08)
	struct UNcWebBrowser* Window; // 0x488(0x08)
	char pad_490[0x10]; // 0x490(0x10)

	void Show(int32_t ZOrder); // Function NcPlatformSdk.NcGeneralWebViewWidget.Show // (Native|Public) // @ game+0x8918f0
	void LoadURL(struct FString InUrl); // Function NcPlatformSdk.NcGeneralWebViewWidget.LoadURL // (Final|Native|Public) // @ game+0x8913e0
	void HandleOnWebBrowserClosed(bool HasError, struct FString ErrorMsg); // Function NcPlatformSdk.NcGeneralWebViewWidget.HandleOnWebBrowserClosed // (Final|Native|Private) // @ game+0x8912b0
	struct FString GetUrl(); // Function NcPlatformSdk.NcGeneralWebViewWidget.GetUrl // (Final|Native|Public|Const) // @ game+0x891280
	void ExecuteJavascript(struct FString JavascriptExp); // Function NcPlatformSdk.NcGeneralWebViewWidget.ExecuteJavascript // (Final|Native|Public) // @ game+0x891160
	void BroadcastOnUrlChanged(struct FText& InText); // Function NcPlatformSdk.NcGeneralWebViewWidget.BroadcastOnUrlChanged // (Final|Native|Private|HasOutParms) // @ game+0x891090
	void BroadcastOnClickClose(); // Function NcPlatformSdk.NcGeneralWebViewWidget.BroadcastOnClickClose // (Final|Native|Private) // @ game+0x891030
	void BroadcastOnBeforePopup(struct FString InUrl, struct FString Frame); // Function NcPlatformSdk.NcGeneralWebViewWidget.BroadcastOnBeforePopup // (Final|Native|Private) // @ game+0x890ea0
};

// Class NcPlatformSdk.NcGoogleAchievementAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcGoogleAchievementAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcGoogleAuthAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcGoogleAuthAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcGoogleLeaderboardAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcGoogleLeaderboardAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcGooglePlayAccountCheckWidget
// Size: 0x438 (Inherited: 0x400)
struct UNcGooglePlayAccountCheckWidget : UNcAlertWidget {
	char pad_400[0x18]; // 0x400(0x18)
	struct UTexture2D* GoogleIcon; // 0x418(0x08)
	struct UNcRichTextBlock_Text2* UnderlineButtonText; // 0x420(0x08)
	struct UNcButton* UnderlineButton; // 0x428(0x08)
	struct UVerticalBox* BottomSlot; // 0x430(0x08)

	void OnClickRetryButtonHandler(); // Function NcPlatformSdk.NcGooglePlayAccountCheckWidget.OnClickRetryButtonHandler // (Final|Native|Private) // @ game+0x891530
};

// Class NcPlatformSdk.NcGoogleSdkAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcGoogleSdkAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcInputPhoneNumberWidget
// Size: 0x440 (Inherited: 0x3e0)
struct UNcInputPhoneNumberWidget : UNcWidgetBase {
	struct UEditableTextBox* PhoneNumberEditableTextBox; // 0x3e0(0x08)
	struct UNcRichTextBlock* MessageRichTextBlock; // 0x3e8(0x08)
	struct UComboBoxString* CountryComboBox; // 0x3f0(0x08)
	struct UNcRichTextBlock* CountryCodeTextBlock; // 0x3f8(0x08)
	struct USizeBox* SizeBox_2; // 0x400(0x08)
	struct USizeBox* SizeBox_3; // 0x408(0x08)
	struct UNcBorder* CountrySelectorBorder; // 0x410(0x08)
	struct UNcBorder* PhoneNumberBorder; // 0x418(0x08)
	struct UHorizontalBox* PhoneNumberHorizontalBox; // 0x420(0x08)
	struct UNcBorder* CountryNumberBorder; // 0x428(0x08)
	char pad_430[0x10]; // 0x430(0x10)

	void OnPhoneNumberInputTextChanged(struct FText& Text); // Function NcPlatformSdk.NcInputPhoneNumberWidget.OnPhoneNumberInputTextChanged // (Final|Native|Private|HasOutParms) // @ game+0x891690
};

// Class NcPlatformSdk.NcInputTextAlertWidget
// Size: 0x408 (Inherited: 0x3e0)
struct UNcInputTextAlertWidget : UNcWidgetBase {
	char pad_3E0[0x8]; // 0x3e0(0x08)
	struct UNcRichTextBlock* MessageTextBlock; // 0x3e8(0x08)
	struct USizeBox* NameInputSizeBox; // 0x3f0(0x08)
	struct UNcBorder* NameInputBorder; // 0x3f8(0x08)
	struct UEditableTextBox* NameInput; // 0x400(0x08)

	void OnTextChanged(struct FText& Text); // Function NcPlatformSdk.NcInputTextAlertWidget.OnTextChanged // (Final|Native|Private|HasOutParms) // @ game+0x891760
};

// Class NcPlatformSdk.NcItemTradeAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcItemTradeAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcLoggerAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcLoggerAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcNlpAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcNlpAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcOneStorePaymentV2API
// Size: 0x28 (Inherited: 0x28)
struct UNcOneStorePaymentV2API : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcPaymentV2API
// Size: 0x28 (Inherited: 0x28)
struct UNcPaymentV2API : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcPlatformSdkAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcPlatformSdkAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcPlatformSdkBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UNcPlatformSdkBPLibrary : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcPrivacyWidget
// Size: 0x428 (Inherited: 0x3e0)
struct UNcPrivacyWidget : UNcWidgetBase {
	struct USizeBox* SizeBox_01; // 0x3e0(0x08)
	struct UNcRichTextBlock* MessageTextBlock; // 0x3e8(0x08)
	struct UNcCheckBox* CheckBox_01; // 0x3f0(0x08)
	struct UNcRichTextBlock* TextBlock_01; // 0x3f8(0x08)
	struct UNcRichTextBlock* TextBlock_02; // 0x400(0x08)
	struct UButton* DetailViewButton; // 0x408(0x08)
	struct UNcBorder* CheckListBorder; // 0x410(0x08)
	struct UNcRichTextBlock* DetailTextBlock; // 0x418(0x08)
	struct UTextBlock* DetailArrowText; // 0x420(0x08)

	void OnClickedDetailViewButton(); // Function NcPlatformSdk.NcPrivacyWidget.OnClickedDetailViewButton // (Final|Native|Private) // @ game+0x891550
	void OnChangedCheckBoxState(bool bIsChecked); // Function NcPlatformSdk.NcPrivacyWidget.OnChangedCheckBoxState // (Final|Native|Private) // @ game+0x8914a0
};

// Class NcPlatformSdk.NcPushAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcPushAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcRichTextBlock
// Size: 0x6d0 (Inherited: 0x690)
struct UNcRichTextBlock : URichTextBlock {
	bool bWillOverrideFontSize; // 0x690(0x01)
	char pad_691[0x3]; // 0x691(0x03)
	int32_t OverridedFontSize; // 0x694(0x04)
	bool bWillOverrideFontColor; // 0x698(0x01)
	char pad_699[0x7]; // 0x699(0x07)
	struct FSlateColor OverridedFontColor; // 0x6a0(0x28)
	bool bApplyUnderline; // 0x6c8(0x01)
	char pad_6C9[0x7]; // 0x6c9(0x07)
};

// Class NcPlatformSdk.NcRichTextBlockDecorator
// Size: 0x28 (Inherited: 0x28)
struct UNcRichTextBlockDecorator : URichTextBlockDecorator {
};

// Class NcPlatformSdk.NcRichTextBlock_Text1
// Size: 0x6d0 (Inherited: 0x6d0)
struct UNcRichTextBlock_Text1 : UNcRichTextBlock {
};

// Class NcPlatformSdk.NcRichTextBlock_Text2
// Size: 0x6d0 (Inherited: 0x6d0)
struct UNcRichTextBlock_Text2 : UNcRichTextBlock {
};

// Class NcPlatformSdk.NcRichTextBlock_ButtonText1
// Size: 0x6d0 (Inherited: 0x6d0)
struct UNcRichTextBlock_ButtonText1 : UNcRichTextBlock {
};

// Class NcPlatformSdk.NcRichTextBlock_PointText
// Size: 0x6d0 (Inherited: 0x6d0)
struct UNcRichTextBlock_PointText : UNcRichTextBlock {
};

// Class NcPlatformSdk.NcSamsungPaymentAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcSamsungPaymentAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcSecondaryAuthAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcSecondaryAuthAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcShopAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcShopAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcShowAbnormalRefundSlotWidget
// Size: 0x488 (Inherited: 0x3e0)
struct UNcShowAbnormalRefundSlotWidget : UNcWidgetBase {
	char pad_3E0[0x18]; // 0x3e0(0x18)
	struct UTextBlock* TextDate; // 0x3f8(0x08)
	struct UNcRichTextBlock* TextItemName; // 0x400(0x08)
	struct UNcRichTextBlock* TextPaymentKey; // 0x408(0x08)
	struct UTextBlock* TextPurchaseButton; // 0x410(0x08)
	struct UNcButton* PurchaseButton; // 0x418(0x08)
	struct UNcBorder* Background; // 0x420(0x08)
	struct USizeBox* MainSizeBox; // 0x428(0x08)
	struct UNcBorder* UpperLine; // 0x430(0x08)
	struct UNcBorder* BottomLine; // 0x438(0x08)
	struct UHorizontalBox* MainHorizontalBox; // 0x440(0x08)
	struct UVerticalBox* ItemNameVerticalBox; // 0x448(0x08)
	struct USpacer* UpperSpacer; // 0x450(0x08)
	struct USpacer* BottomSpacer; // 0x458(0x08)
	struct USizeBox* PurchaseSizeBox; // 0x460(0x08)
	struct USpacer* ItemNameSpacer; // 0x468(0x08)
	struct USpacer* DateSpacer; // 0x470(0x08)
	char pad_478[0x10]; // 0x478(0x10)

	void BroadcastOnClickPurchaseButton(); // Function NcPlatformSdk.NcShowAbnormalRefundSlotWidget.BroadcastOnClickPurchaseButton // (Final|Native|Private) // @ game+0x891070
};

// Class NcPlatformSdk.NcShowAbnormalRefundWidget
// Size: 0x4b0 (Inherited: 0x3e0)
struct UNcShowAbnormalRefundWidget : UNcWidgetBase {
	char pad_3E0[0x30]; // 0x3e0(0x30)
	struct UTextBlock* TextTitle; // 0x410(0x08)
	struct UTextBlock* TextDescription1; // 0x418(0x08)
	struct UTextBlock* TextDescription2; // 0x420(0x08)
	struct UTextBlock* TextDescription3; // 0x428(0x08)
	struct UTextBlock* TextDescription4; // 0x430(0x08)
	struct UTextBlock* TextCS; // 0x438(0x08)
	struct UNcRichTextBlock* TextContact; // 0x440(0x08)
	struct UVerticalBox* RefundListBox; // 0x448(0x08)
	struct UButton* ContactButton; // 0x450(0x08)
	struct USizeBox* ContentSizeBox; // 0x458(0x08)
	struct UHorizontalBox* FooterHorizontalBox1; // 0x460(0x08)
	struct UHorizontalBox* FooterHorizontalBox2; // 0x468(0x08)
	struct UScrollBox* ContentScrollBox; // 0x470(0x08)
	struct UVerticalBox* ContentVerticalBox; // 0x478(0x08)
	struct UTextBlock* FooterHead1; // 0x480(0x08)
	struct UTextBlock* FooterHead2; // 0x488(0x08)
	struct UCanvasPanel* InquireCanvas; // 0x490(0x08)
	char pad_498[0x18]; // 0x498(0x18)

	void BroadcastOnClickContactButton(); // Function NcPlatformSdk.NcShowAbnormalRefundWidget.BroadcastOnClickContactButton // (Final|Native|Private) // @ game+0x8946f0
};

// Class NcPlatformSdk.NcShowAgreementSlotWidget
// Size: 0x4e8 (Inherited: 0x3e0)
struct UNcShowAgreementSlotWidget : UNcWidgetBase {
	char pad_3E0[0x30]; // 0x3e0(0x30)
	struct UNcCheckBox* CheckBox; // 0x410(0x08)
	struct UVerticalBox* ItemTextLinesVerticalBox; // 0x418(0x08)
	struct UHorizontalBox* ItemTextHorizontalBox; // 0x420(0x08)
	struct UOverlay* ItemTextOverlay; // 0x428(0x08)
	struct UNcRichTextBlock* ItemText; // 0x430(0x08)
	struct UButton* TextButton; // 0x438(0x08)
	struct UButton* DetailButton; // 0x440(0x08)
	struct UNcRichTextBlock* DetailText; // 0x448(0x08)
	struct UTextBlock* SubDescriptionText; // 0x450(0x08)
	struct UHorizontalBox* TitleHorizontalBox; // 0x458(0x08)
	struct UHorizontalBox* SubDescriptionHorizontalBox; // 0x460(0x08)
	struct UHorizontalBox* DetailHorizontalBox; // 0x468(0x08)
	struct USizeBox* MainSizeBox; // 0x470(0x08)
	struct UTextBlock* DetailArrow; // 0x478(0x08)
	struct USpacer* CheckBoxSpacer; // 0x480(0x08)
	struct USpacer* SubDescriptionSpacer; // 0x488(0x08)
	struct USpacer* DatailSpacer; // 0x490(0x08)
	char pad_498[0x50]; // 0x498(0x50)

	void ToggleCheckBoxState(); // Function NcPlatformSdk.NcShowAgreementSlotWidget.ToggleCheckBoxState // (Final|Native|Private) // @ game+0x895210
	void BroadcastOnClickDetailLink(); // Function NcPlatformSdk.NcShowAgreementSlotWidget.BroadcastOnClickDetailLink // (Final|Native|Private) // @ game+0x894730
	void BroadcastOnCheckStateChanged(bool bIsChecked); // Function NcPlatformSdk.NcShowAgreementSlotWidget.BroadcastOnCheckStateChanged // (Final|Native|Private) // @ game+0x894600
};

// Class NcPlatformSdk.NcShowAgreementWidget
// Size: 0x440 (Inherited: 0x3e0)
struct UNcShowAgreementWidget : UNcWidgetBase {
	struct UTextBlock* Message; // 0x3e0(0x08)
	struct UNcBorder* CheckListBackground; // 0x3e8(0x08)
	struct UVerticalBox* CheckListBox; // 0x3f0(0x08)
	char pad_3F8[0x48]; // 0x3f8(0x48)
};

// Class NcPlatformSdk.NcShowCampaignWidget
// Size: 0x5a0 (Inherited: 0x4a0)
struct UNcShowCampaignWidget : UNcGeneralWebViewWidget {
	char pad_4A0[0x68]; // 0x4a0(0x68)
	struct UVerticalBox* LayoutVerticalBox; // 0x508(0x08)
	struct UCanvasPanel* WindowPanel; // 0x510(0x08)
	struct UCanvasPanel* CloseBarPanel; // 0x518(0x08)
	struct UNcBorder* CloseBarBackground; // 0x520(0x08)
	struct UTextBlock* Title; // 0x528(0x08)
	struct UTextBlock* ExceptCheckTitle; // 0x530(0x08)
	struct UButton* ExceptCheckButton; // 0x538(0x08)
	struct UNcCheckBox* ExceptCheckBox; // 0x540(0x08)
	struct USizeBox* ExceptCheckTitleSizeBox; // 0x548(0x08)
	struct USizeBox* TitleSizeBox; // 0x550(0x08)
	struct UHorizontalBox* CloseBarHorizontalBox; // 0x558(0x08)
	struct UOverlay* ExceptTitleOverlay; // 0x560(0x08)
	struct UHorizontalBox* ExceptCheckButtonHorizontalBox; // 0x568(0x08)
	struct USizeBox* ExceptCheckButtonSizeBox; // 0x570(0x08)
	struct USizeBox* CloseButtonSizeBox; // 0x578(0x08)
	struct USpacer* CheckBoxSpacer; // 0x580(0x08)
	char pad_588[0x18]; // 0x588(0x18)

	void SetTemplete(int32_t TemplateType, struct FString TitleString, struct FString ExceptTitleString); // Function NcPlatformSdk.NcShowCampaignWidget.SetTemplete // (Final|Native|Public) // @ game+0x8950e0
	void OnUnhoveredExceptCheckButton(); // Function NcPlatformSdk.NcShowCampaignWidget.OnUnhoveredExceptCheckButton // (Final|Native|Private) // @ game+0x894e80
	void OnReleasedExceptCheckButton(); // Function NcPlatformSdk.NcShowCampaignWidget.OnReleasedExceptCheckButton // (Final|Native|Private) // @ game+0x894e20
	void OnPressedExceptCheckButton(); // Function NcPlatformSdk.NcShowCampaignWidget.OnPressedExceptCheckButton // (Final|Native|Private) // @ game+0x894dc0
	void OnInputEnabled(); // Function NcPlatformSdk.NcShowCampaignWidget.OnInputEnabled // (Final|Native|Private) // @ game+0x894d80
	void OnHoveredExceptCheckButton(); // Function NcPlatformSdk.NcShowCampaignWidget.OnHoveredExceptCheckButton // (Final|Native|Private) // @ game+0x894d60
	struct FDateTime GetVisibleStartTime(); // Function NcPlatformSdk.NcShowCampaignWidget.GetVisibleStartTime // (Final|Native|Public|HasDefaults) // @ game+0x8949b0
	void BroadcastOnClickExceptCheck(); // Function NcPlatformSdk.NcShowCampaignWidget.BroadcastOnClickExceptCheck // (Final|Native|Private) // @ game+0x894750
	void BroadcastOnClickCloseCampaign(); // Function NcPlatformSdk.NcShowCampaignWidget.BroadcastOnClickCloseCampaign // (Final|Native|Private) // @ game+0x8946d0
	void BroadcastOnCampaignWebBrowserClosed(bool HasError, struct FString ErrorMsg); // Function NcPlatformSdk.NcShowCampaignWidget.BroadcastOnCampaignWebBrowserClosed // (Final|Native|Private) // @ game+0x8944d0
};

// Class NcPlatformSdk.NcShowLoginProviderCircleWidget
// Size: 0x470 (Inherited: 0x3e0)
struct UNcShowLoginProviderCircleWidget : UNcWidgetBase {
	struct UTexture2D* GuestIcon; // 0x3e0(0x08)
	struct UTexture2D* GoogleIcon; // 0x3e8(0x08)
	struct UTexture2D* FacebookIcon; // 0x3f0(0x08)
	struct UTexture2D* TwitterIcon; // 0x3f8(0x08)
	struct UTexture2D* LineIcon; // 0x400(0x08)
	struct UTexture2D* AppleIcon; // 0x408(0x08)
	struct UTexture2D* VKIcon; // 0x410(0x08)
	struct UTexture2D* BeanfunIcon; // 0x418(0x08)
	struct UTexture2D* GameCenterIcon; // 0x420(0x08)
	char pad_428[0x18]; // 0x428(0x18)
	struct UButton* ProviderButton; // 0x440(0x08)
	struct UImage* ButtonBorder; // 0x448(0x08)
	struct UTextBlock* ProviderText; // 0x450(0x08)
	struct USizeBox* TextSizeBox; // 0x458(0x08)
	struct USpacer* ButtonSpacer; // 0x460(0x08)
	char pad_468[0x8]; // 0x468(0x08)

	void SetProviderText(struct FText& InText); // Function NcPlatformSdk.NcShowLoginProviderCircleWidget.SetProviderText // (Final|Native|Private|HasOutParms) // @ game+0x894f40
	void SetProviderImage(struct UTexture2D* InImage); // Function NcPlatformSdk.NcShowLoginProviderCircleWidget.SetProviderImage // (Final|Native|Private) // @ game+0x894ec0
	void BroadcastOnClickProvider(); // Function NcPlatformSdk.NcShowLoginProviderCircleWidget.BroadcastOnClickProvider // (Final|Native|Private) // @ game+0x894790
};

// Class NcPlatformSdk.NcShowLoginProviderSquareWidget
// Size: 0x490 (Inherited: 0x3e0)
struct UNcShowLoginProviderSquareWidget : UNcWidgetBase {
	struct UTexture2D* NCIcon; // 0x3e0(0x08)
	struct UTexture2D* PhoneIcon; // 0x3e8(0x08)
	struct UTexture2D* GoogleIcon; // 0x3f0(0x08)
	struct UTexture2D* FacebookIcon; // 0x3f8(0x08)
	struct UTexture2D* TwitterIcon; // 0x400(0x08)
	struct UTexture2D* LineIcon; // 0x408(0x08)
	struct UTexture2D* AppleIcon; // 0x410(0x08)
	struct UTexture2D* BeanfunIcon; // 0x418(0x08)
	struct UTexture2D* GameCenterIcon; // 0x420(0x08)
	struct UTexture2D* VKIcon; // 0x428(0x08)
	char pad_430[0x18]; // 0x430(0x18)
	struct UNcButton* LoginButton; // 0x448(0x08)
	struct UNcBorder* ButtonBorder; // 0x450(0x08)
	struct UImage* ProviderIcon; // 0x458(0x08)
	struct UTextBlock* ProviderText; // 0x460(0x08)
	struct USizeBox* MainSizeBox; // 0x468(0x08)
	struct USizeBox* TextSizeBox; // 0x470(0x08)
	struct UHorizontalBox* ProviderIconHorizontalBox; // 0x478(0x08)
	struct USpacer* ProviderIconPuller; // 0x480(0x08)
	char pad_488[0x8]; // 0x488(0x08)

	void SetProviderText(struct FText& InText); // Function NcPlatformSdk.NcShowLoginProviderSquareWidget.SetProviderText // (Final|Native|Private|HasOutParms) // @ game+0x895010
	void RefreshTextLayout(); // Function NcPlatformSdk.NcShowLoginProviderSquareWidget.RefreshTextLayout // (Final|Native|Private) // @ game+0x894ea0
	void BroadcastOnClickProvider(); // Function NcPlatformSdk.NcShowLoginProviderSquareWidget.BroadcastOnClickProvider // (Final|Native|Private) // @ game+0x8947b0
};

// Class NcPlatformSdk.NcShowLoginWidget
// Size: 0x500 (Inherited: 0x3e0)
struct UNcShowLoginWidget : UNcWidgetBase {
	char pad_3E0[0x80]; // 0x3e0(0x80)
	struct UHorizontalBox* CloseHorizontalBox; // 0x460(0x08)
	struct UButton* CloseButton; // 0x468(0x08)
	struct UTextBlock* LoginText; // 0x470(0x08)
	struct UHorizontalBox* SectionHorizontalBox; // 0x478(0x08)
	struct UHorizontalBox* SquareProviderSection; // 0x480(0x08)
	struct UVerticalBox* SquareProviderVerticalBox; // 0x488(0x08)
	struct UVerticalBox* CircleProviderSection; // 0x490(0x08)
	struct UImage* LastCircle; // 0x498(0x08)
	struct UNcBorder* Background; // 0x4a0(0x08)
	struct UOverlay* CountrySelectOverlay; // 0x4a8(0x08)
	struct UHorizontalBox* CountrySelectHorizontalBox; // 0x4b0(0x08)
	struct UHorizontalBox* CountryButtonHorizontalBox; // 0x4b8(0x08)
	struct UImage* CountryImage; // 0x4c0(0x08)
	struct UTextBlock* CountryText; // 0x4c8(0x08)
	struct UButton* CountryButton; // 0x4d0(0x08)
	struct USpacer* LastCircleSpacer; // 0x4d8(0x08)
	struct USpacer* SectionSpacer; // 0x4e0(0x08)
	struct USpacer* RightSpacer; // 0x4e8(0x08)
	struct USpacer* CountryTextSpacer; // 0x4f0(0x08)
	struct USpacer* CountryButtonSpacer; // 0x4f8(0x08)

	void OnUnhoveredCountryButton(); // Function NcPlatformSdk.NcShowLoginWidget.OnUnhoveredCountryButton // (Final|Native|Private) // @ game+0x894e60
	void OnReleasedCountryButton(); // Function NcPlatformSdk.NcShowLoginWidget.OnReleasedCountryButton // (Final|Native|Private) // @ game+0x894e00
	void OnPressedCountryButton(); // Function NcPlatformSdk.NcShowLoginWidget.OnPressedCountryButton // (Final|Native|Private) // @ game+0x894da0
	void OnHoveredCountryButton(); // Function NcPlatformSdk.NcShowLoginWidget.OnHoveredCountryButton // (Final|Native|Private) // @ game+0x894d40
	void OnClickedCountryButton(); // Function NcPlatformSdk.NcShowLoginWidget.OnClickedCountryButton // (Final|Native|Private) // @ game+0x894d00
	void BroadcastOnClickClose(); // Function NcPlatformSdk.NcShowLoginWidget.BroadcastOnClickClose // (Final|Native|Private) // @ game+0x894690
};

// Class NcPlatformSdk.NcSimpleLoginSlotWidget
// Size: 0x570 (Inherited: 0x3e0)
struct UNcSimpleLoginSlotWidget : UNcWidgetBase {
	struct UTexture2D* GuestIcon; // 0x3e0(0x08)
	struct UTexture2D* PlayncIcon; // 0x3e8(0x08)
	struct UTexture2D* PhoneIcon; // 0x3f0(0x08)
	struct UTexture2D* GoogleIcon; // 0x3f8(0x08)
	struct UTexture2D* FacebookIcon; // 0x400(0x08)
	struct UTexture2D* TwitterIcon; // 0x408(0x08)
	struct UTexture2D* LineIcon; // 0x410(0x08)
	struct UTexture2D* AppleidIcon; // 0x418(0x08)
	struct UTexture2D* VKIcon; // 0x420(0x08)
	char pad_428[0x70]; // 0x428(0x70)
	struct UCanvasPanel* SlotFullPanel; // 0x498(0x08)
	struct UNcBorder* ButtonBorder; // 0x4a0(0x08)
	struct UNcButton* SlotButton; // 0x4a8(0x08)
	struct UHorizontalBox* MainHorizontalBox; // 0x4b0(0x08)
	struct UImage* LoginProviderIcon; // 0x4b8(0x08)
	struct UTextBlock* PlayncAccountType; // 0x4c0(0x08)
	struct UTextBlock* Title; // 0x4c8(0x08)
	struct UTextBlock* Subtitle; // 0x4d0(0x08)
	struct UButton* MemoButton; // 0x4d8(0x08)
	struct UImage* MemoIcon; // 0x4e0(0x08)
	struct UButton* DeleteButton; // 0x4e8(0x08)
	struct UTextBlock* OnlineStatus; // 0x4f0(0x08)
	struct UImage* MemoBorder; // 0x4f8(0x08)
	struct USizeBox* InfoSizeBox; // 0x500(0x08)
	struct UVerticalBox* InfoVerticalBox; // 0x508(0x08)
	struct UHorizontalBox* TitleHorizontalBox; // 0x510(0x08)
	struct UHorizontalBox* SubTitleHorizontalBox; // 0x518(0x08)
	struct USpacer* EmptySpacer; // 0x520(0x08)
	struct USpacer* IconSpacer; // 0x528(0x08)
	struct USpacer* TitleSpacer; // 0x530(0x08)
	struct USpacer* OnlineStatusSpacer; // 0x538(0x08)
	struct USpacer* TitleFiller; // 0x540(0x08)
	struct USpacer* SubTitleSpacer; // 0x548(0x08)
	struct USpacer* SubTitleFiller; // 0x550(0x08)
	struct USpacer* MemoBorderSpacer; // 0x558(0x08)
	struct USizeBox* MemoButtonSizeBox; // 0x560(0x08)
	struct USpacer* DeleteButtonSpacer; // 0x568(0x08)

	void OnReleasedMemo(); // Function NcPlatformSdk.NcSimpleLoginSlotWidget.OnReleasedMemo // (Final|Native|Private) // @ game+0x894e40
	void OnPressedMemo(); // Function NcPlatformSdk.NcSimpleLoginSlotWidget.OnPressedMemo // (Final|Native|Private) // @ game+0x894de0
	void BroadcastOnClickSlot(); // Function NcPlatformSdk.NcSimpleLoginSlotWidget.BroadcastOnClickSlot // (Final|Native|Private) // @ game+0x8947d0
	void BroadcastOnClickMemo(); // Function NcPlatformSdk.NcSimpleLoginSlotWidget.BroadcastOnClickMemo // (Final|Native|Private) // @ game+0x894770
	void BroadcastOnClickDelete(); // Function NcPlatformSdk.NcSimpleLoginSlotWidget.BroadcastOnClickDelete // (Final|Native|Private) // @ game+0x894710
};

// Class NcPlatformSdk.NcSimpleLoginWidget
// Size: 0x448 (Inherited: 0x3e0)
struct UNcSimpleLoginWidget : UNcWidgetBase {
	char pad_3E0[0x60]; // 0x3e0(0x60)
	struct UVerticalBox* SlotBox; // 0x440(0x08)
};

// Class NcPlatformSdk.NcStorageAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcStorageAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcToastPopupWidget
// Size: 0x458 (Inherited: 0x448)
struct UNcToastPopupWidget : UNcBaseAnimationDialogWidget {
	float VisibleTime; // 0x448(0x04)
	char pad_44C[0x4]; // 0x44c(0x04)
	struct UTextBlock* MessageText; // 0x450(0x08)
};

// Class NcPlatformSdk.NcUserAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcUserAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcUtilAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcUtilAPI : UBlueprintFunctionLibrary {
};

// Class NcPlatformSdk.NcWebBrowser
// Size: 0x2b8 (Inherited: 0x258)
struct UNcWebBrowser : UUserWidget {
	char pad_258[0x38]; // 0x258(0x38)
	struct UCircularThrobber* LoadingIndicator; // 0x290(0x08)
	char pad_298[0x20]; // 0x298(0x20)

	void OnWebBrowserClosed__DelegateSignature(bool HasError, struct FString ErrorMsg); // DelegateFunction NcPlatformSdk.NcWebBrowser.OnWebBrowserClosed__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	void OnUrlChanged__DelegateSignature(struct FText& Text); // DelegateFunction NcPlatformSdk.NcWebBrowser.OnUrlChanged__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	void OnBeforePopup__DelegateSignature(struct FString URL, struct FString Frame); // DelegateFunction NcPlatformSdk.NcWebBrowser.OnBeforePopup__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	void LoadURL(struct FString InUrl); // Function NcPlatformSdk.NcWebBrowser.LoadURL // (Final|Native|Public) // @ game+0x894c20
	void HandleOnUrlChanged(struct FText& InText); // Function NcPlatformSdk.NcWebBrowser.HandleOnUrlChanged // (Final|Native|Private|HasOutParms) // @ game+0x894b50
	void HandleOnBeforePopup(struct FString InUrl, struct FString Frame); // Function NcPlatformSdk.NcWebBrowser.HandleOnBeforePopup // (Final|Native|Private) // @ game+0x8949e0
	void ExecuteJavascript(struct FString JavascriptExp); // Function NcPlatformSdk.NcWebBrowser.ExecuteJavascript // (Final|Native|Public) // @ game+0x8948e0
	void BroadcastOnWebBrowserClosed(bool HasError, struct FString ErrorMsg); // Function NcPlatformSdk.NcWebBrowser.BroadcastOnWebBrowserClosed // (Final|Native|Private) // @ game+0x8947f0
};

// Class NcPlatformSdk.NcWidget_Template
// Size: 0x5b0 (Inherited: 0x3e0)
struct UNcWidget_Template : UNcWidgetBase {
	struct FNcWidgetStyleOverrideSettings StyleOverrideSettings; // 0x3e0(0x78)
	struct UNcBorder* Background; // 0x458(0x08)
	struct UNcBorder* ContentBackground; // 0x460(0x08)
	struct UNcBorder* WidgetBorder; // 0x468(0x08)
	struct USizeBox* BorderSizeBox; // 0x470(0x08)
	struct UVerticalBox* TitleSection; // 0x478(0x08)
	struct UTextBlock* TitleTextBlock; // 0x480(0x08)
	struct UNamedSlot* ContentSlot; // 0x488(0x08)
	struct UVerticalBox* ContentSection; // 0x490(0x08)
	struct UVerticalBox* ButtonSection; // 0x498(0x08)
	struct UNcButton* CancelButton; // 0x4a0(0x08)
	struct UNcRichTextBlock* CancelButtonText; // 0x4a8(0x08)
	struct UNcButton* ConfirmButton; // 0x4b0(0x08)
	struct UNcRichTextBlock* ConfirmButtonText; // 0x4b8(0x08)
	struct USpacer* ButtonsSpacer; // 0x4c0(0x08)
	struct USizeBox* ButtonVerticalSize; // 0x4c8(0x08)
	struct UHorizontalBox* ButtonHorizontalBox; // 0x4d0(0x08)
	struct USpacer* CloseSpacer; // 0x4d8(0x08)
	struct UHorizontalBox* CloseHorizontalBox; // 0x4e0(0x08)
	struct UButton* CloseButton; // 0x4e8(0x08)
	char pad_4F0[0x68]; // 0x4f0(0x68)
	enum class ENcWidgetStyleType Style; // 0x558(0x01)
	char pad_559[0x57]; // 0x559(0x57)

	void OnClickedCustomButton(); // Function NcPlatformSdk.NcWidget_Template.OnClickedCustomButton // (Final|Native|Private) // @ game+0x894d20
	void OnClickedConfirmButton(); // Function NcPlatformSdk.NcWidget_Template.OnClickedConfirmButton // (Final|Native|Private) // @ game+0x894ce0
	void OnClickedCancelButton(); // Function NcPlatformSdk.NcWidget_Template.OnClickedCancelButton // (Final|Native|Private) // @ game+0x894cc0
};

// Class NcPlatformSdk.NcWidgetCreater
// Size: 0x80 (Inherited: 0x28)
struct UNcWidgetCreater : UObject {
	char pad_28[0x58]; // 0x28(0x58)

	struct APlayerController* GetPlayerController(); // Function NcPlatformSdk.NcWidgetCreater.GetPlayerController // (Final|Native|Private) // @ game+0x894980
};

// Class NcPlatformSdk.SdkDataJsonSaveGame
// Size: 0x38 (Inherited: 0x28)
struct USdkDataJsonSaveGame : USaveGame {
	struct FString Data; // 0x28(0x10)
};

// Class NcPlatformSdk.SDKSaveData
// Size: 0x170 (Inherited: 0x28)
struct USDKSaveData : USaveGame {
	struct FString SaveSlotName; // 0x28(0x10)
	int32_t SaveIndex; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FString GuestAuthnToken; // 0x40(0x10)
	struct FString UUID; // 0x50(0x10)
	struct FString UDID; // 0x60(0x10)
	struct FString PushDeviceToken; // 0x70(0x10)
	struct FString PushProviderCode; // 0x80(0x10)
	struct FString CountryCode; // 0x90(0x10)
	struct FString SessionId; // 0xa0(0x10)
	struct FString SessionSecret; // 0xb0(0x10)
	struct FString LastLoggedInAuthProviderCode; // 0xc0(0x10)
	struct FString ExpectCampaigns; // 0xd0(0x10)
	struct FString OrderDatum; // 0xe0(0x10)
	struct FString NcSecondaryAuth_DeviceId; // 0xf0(0x10)
	struct FString NcSecondaryAuth_InitializationVector; // 0x100(0x10)
	struct FString NcSecondaryAuth_AuthNonce; // 0x110(0x10)
	struct TMap<struct FString, struct FString> CustomData; // 0x120(0x50)
};

// Class NcPlatformSdk.TextBlock_Text1
// Size: 0x2c8 (Inherited: 0x2c8)
struct UTextBlock_Text1 : UTextBlock {
};

// Class NcPlatformSdk.TextBlock_Text2
// Size: 0x2c8 (Inherited: 0x2c8)
struct UTextBlock_Text2 : UTextBlock {
};

// Class NcPlatformSdk.TextBlock_ButtonText1
// Size: 0x2c8 (Inherited: 0x2c8)
struct UTextBlock_ButtonText1 : UTextBlock {
};

// Class NcPlatformSdk.TextBlock_PointText
// Size: 0x2c8 (Inherited: 0x2c8)
struct UTextBlock_PointText : UTextBlock {
};

// Class NcPlatformSdk.TextBlock_TextHovered
// Size: 0x2c8 (Inherited: 0x2c8)
struct UTextBlock_TextHovered : UTextBlock {
};

