// BlueprintGeneratedClass BP_LootingEffect.BP_LootingEffect_C
// Size: 0x280 (Inherited: 0x280)
struct ABP_LootingEffect_C : ALMRLootingEffectActor {
};

