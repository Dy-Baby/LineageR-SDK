// WidgetBlueprintGeneratedClass BP_NcToastPopupWidget.BP_NcToastPopupWidget_C
// Size: 0x470 (Inherited: 0x458)
struct UBP_NcToastPopupWidget_C : UNcToastPopupWidget {
	struct UWidgetAnimation* Toast; // 0x458(0x08)
	struct UImage* LeftImage; // 0x460(0x08)
	struct UImage* RightImage; // 0x468(0x08)
};

