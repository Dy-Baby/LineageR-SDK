// WidgetBlueprintGeneratedClass UI_SignPostNameTag.UI_SignPostNameTag_C
// Size: 0x328 (Inherited: 0x320)
struct UUI_SignPostNameTag_C : ULMRSignPostNameTag {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x320(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_SignPostNameTag.UI_SignPostNameTag_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void Construct(); // Function UI_SignPostNameTag.UI_SignPostNameTag_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_UI_SignPostNameTag(int32_t EntryPoint); // Function UI_SignPostNameTag.UI_SignPostNameTag_C.ExecuteUbergraph_UI_SignPostNameTag // (Final|UbergraphFunction) // @ game+0x2849850
};

