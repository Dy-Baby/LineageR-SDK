// BlueprintGeneratedClass BP_GameModePreLoad.BP_GameModePreLoad_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_GameModePreLoad_C : ABP_PreLoad_C {
};

