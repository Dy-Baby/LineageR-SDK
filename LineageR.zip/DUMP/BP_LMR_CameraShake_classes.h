// BlueprintGeneratedClass BP_LMR_CameraShake.BP_LMR_CameraShake_C
// Size: 0x40 (Inherited: 0x40)
struct UBP_LMR_CameraShake_C : ULMRAnimNotify_CameraShake {
};

