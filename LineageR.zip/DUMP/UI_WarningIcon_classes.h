// WidgetBlueprintGeneratedClass UI_WarningIcon.UI_WarningIcon_C
// Size: 0x468 (Inherited: 0x460)
struct UUI_WarningIcon_C : ULMRWarningIcon {
	struct USafeZone* SafeZone_1; // 0x460(0x08)
};

