// Class GoogleSpeechKit.GoogleSpeechFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UGoogleSpeechFunctionLibrary : UBlueprintFunctionLibrary {

	bool wipeTTSCache(); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.wipeTTSCache // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xcedc40
	void SetUseApiKeyFromEnvironmentVars(bool bUseEnvVariable); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.SetUseApiKeyFromEnvironmentVars // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xcedaf0
	void SetTTSCachingEnabled(bool bEnabled); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.SetTTSCachingEnabled // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xceda70
	void SetTTSCacheRootDirectory(struct FString Path); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.SetTTSCacheRootDirectory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xced9e0
	void SetApiKey(struct FString apiKey); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.SetApiKey // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xced950
	void resetTTSCacheRootDirectory(); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.resetTTSCacheRootDirectory // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xcedc20
	bool isTTSCachingEnabled(); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.isTTSCachingEnabled // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcedbf0
	struct FString getTTSCacheRootDirectory(); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.getTTSCacheRootDirectory // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcedb70
	bool CompareSynthesysParameters(struct FGoogleSpeechSynthesisParams& lhs, struct FGoogleSpeechSynthesisParams& rhs); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.CompareSynthesysParameters // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xced060
	float CompareStrings(struct FString Source, struct FString Target); // Function GoogleSpeechKit.GoogleSpeechFunctionLibrary.CompareStrings // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcecf70
};

// Class GoogleSpeechKit.GoogleSTT
// Size: 0x270 (Inherited: 0x30)
struct UGoogleSTT : UBlueprintAsyncActionBase {
	char pad_30[0x50]; // 0x30(0x50)
	struct FMulticastInlineDelegate Finished; // 0x80(0x10)
	char pad_90[0x1e0]; // 0x90(0x1e0)

	struct UGoogleSTT* GoogleSTT(struct FGoogleSpeechRecognitionParams Params); // Function GoogleSpeechKit.GoogleSTT.GoogleSTT // (Final|Native|Static|Private|BlueprintCallable) // @ game+0xced320
};

// Class GoogleSpeechKit.GoogleSTTVariants
// Size: 0x278 (Inherited: 0x30)
struct UGoogleSTTVariants : UBlueprintAsyncActionBase {
	char pad_30[0x50]; // 0x30(0x50)
	struct FMulticastInlineDelegate Finished; // 0x80(0x10)
	char pad_90[0x1e8]; // 0x90(0x1e8)

	struct UGoogleSTTVariants* GoogleSTTVariants(struct FGoogleSpeechRecognitionParams paramsm, int32_t maxAlternatives); // Function GoogleSpeechKit.GoogleSTTVariants.GoogleSTTVariants // (Final|Native|Static|Private|BlueprintCallable) // @ game+0xced560
};

// Class GoogleSpeechKit.GoogleTTS
// Size: 0x138 (Inherited: 0x30)
struct UGoogleTTS : UBlueprintAsyncActionBase {
	char pad_30[0x40]; // 0x30(0x40)
	struct FMulticastInlineDelegate Finished; // 0x70(0x10)
	char pad_80[0x10]; // 0x80(0x10)
	struct USoundWave* sWave; // 0x90(0x08)
	char pad_98[0xa0]; // 0x98(0xa0)

	struct UGoogleTTS* GoogleTTS(struct FGoogleSpeechSynthesisParams Params); // Function GoogleSpeechKit.GoogleTTS.GoogleTTS // (Final|Native|Static|Private|BlueprintCallable) // @ game+0xced7d0
};

// Class GoogleSpeechKit.MicrophoneCapture
// Size: 0xd8 (Inherited: 0xb0)
struct UMicrophoneCapture : UActorComponent {
	bool bIsCaptureActive; // 0xb0(0x01)
	char pad_B1[0x27]; // 0xb1(0x27)

	void FinishCapture(struct TArray<char>& CaptureData, int32_t& SamplesRecorded); // Function GoogleSpeechKit.MicrophoneCapture.FinishCapture // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xced220
	bool BeginCapture(int32_t SampleRate); // Function GoogleSpeechKit.MicrophoneCapture.BeginCapture // (Final|Native|Public|BlueprintCallable) // @ game+0xcecee0
};

