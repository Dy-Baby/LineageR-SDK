// WidgetBlueprintGeneratedClass UI_InstDungeonTimeout.UI_InstDungeonTimeout_C
// Size: 0x538 (Inherited: 0x530)
struct UUI_InstDungeonTimeout_C : ULMRInstanceDungeonTimeoutWidget {
	struct UWidgetAnimation* ani_LandmarkText; // 0x530(0x08)
};

