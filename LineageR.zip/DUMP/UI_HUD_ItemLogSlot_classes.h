// WidgetBlueprintGeneratedClass UI_HUD_ItemLogSlot.UI_HUD_ItemLogSlot_C
// Size: 0x320 (Inherited: 0x300)
struct UUI_HUD_ItemLogSlot_C : ULMRItemLogSlotWidget {
	struct UWidgetAnimation* ani_Up; // 0x300(0x08)
	struct UHorizontalBox* itemLoot; // 0x308(0x08)
	struct ULMRImage* UIFX_Line; // 0x310(0x08)
	struct ULMRImage* UIFX_Shadow; // 0x318(0x08)
};

