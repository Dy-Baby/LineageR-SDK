// ScriptStruct CommunitySdk.AttachmentInfo
// Size: 0x10 (Inherited: 0x00)
struct FAttachmentInfo {
	struct FString FileUrl; // 0x00(0x10)
};

// ScriptStruct CommunitySdk.BaseEvent
// Size: 0x30 (Inherited: 0x00)
struct FBaseEvent {
	struct FString Guid; // 0x00(0x10)
	struct FString GameCode; // 0x10(0x10)
	struct FString EventType; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.BaseGoogleSTTResponse
// Size: 0x30 (Inherited: 0x00)
struct FBaseGoogleSTTResponse {
	int32_t Error; // 0x00(0x04)
	int32_t Modlue; // 0x04(0x04)
	int32_t Line; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Text; // 0x10(0x10)
	struct FString Defined; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.BaseNotification
// Size: 0x218 (Inherited: 0x00)
struct FBaseNotification {
	struct FString Guid; // 0x00(0x10)
	int32_t Seq; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct FString RoomId; // 0x18(0x10)
	struct FString GameUserId; // 0x28(0x10)
	struct FString PlayNcCharId; // 0x38(0x10)
	struct FString UserName; // 0x48(0x10)
	struct FString ServerId; // 0x58(0x10)
	struct FString ReceiverCharacterId; // 0x68(0x10)
	struct FString ReceiverUserName; // 0x78(0x10)
	struct FString ReceiverServerId; // 0x88(0x10)
	struct FString Alias; // 0x98(0x10)
	struct FString ClassId; // 0xa8(0x10)
	struct FString ClassName; // 0xb8(0x10)
	bool HasCastle; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	int32_t Ranking; // 0xcc(0x04)
	struct FString Gender; // 0xd0(0x10)
	struct FString Type; // 0xe0(0x10)
	struct FString SubType; // 0xf0(0x10)
	struct FString Content; // 0x100(0x10)
	struct FString Attribute; // 0x110(0x10)
	struct FString Optional; // 0x120(0x10)
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x130(0x30)
	struct FString Role; // 0x160(0x10)
	bool IsFromGame; // 0x170(0x01)
	char pad_171[0x7]; // 0x171(0x07)
	struct FString SenderGameCode; // 0x178(0x10)
	int32_t CastleNo; // 0x188(0x04)
	char pad_18C[0x4]; // 0x18c(0x04)
	struct FString GuildId; // 0x190(0x10)
	struct FString ReceiverGameCode; // 0x1a0(0x10)
	bool HasReplacedContent; // 0x1b0(0x01)
	char pad_1B1[0x7]; // 0x1b1(0x07)
	struct TArray<struct FReplacedMessageInfo> ReplacedMessageInfoList; // 0x1b8(0x10)
	struct FString DateCreated; // 0x1c8(0x10)
	struct FString Language; // 0x1d8(0x10)
	struct FString Country; // 0x1e8(0x10)
	struct FString Locale; // 0x1f8(0x10)
	struct FAttachmentInfo AttachmentInfo; // 0x208(0x10)
};

// ScriptStruct CommunitySdk.ReplacedMessageInfo
// Size: 0x30 (Inherited: 0x00)
struct FReplacedMessageInfo {
	struct FOriginal Original; // 0x00(0x10)
	struct FReplaced Replaced; // 0x10(0x10)
	struct FString AdditionalData; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.Replaced
// Size: 0x10 (Inherited: 0x00)
struct FReplaced {
	struct FString Value; // 0x00(0x10)
};

// ScriptStruct CommunitySdk.Original
// Size: 0x10 (Inherited: 0x00)
struct FOriginal {
	struct FString Value; // 0x00(0x10)
};

// ScriptStruct CommunitySdk.GameRoomKeyInfo
// Size: 0x30 (Inherited: 0x00)
struct FGameRoomKeyInfo {
	struct FString Type; // 0x00(0x10)
	struct FString ServerKey; // 0x10(0x10)
	struct FString RoomKey; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.BaseRequest
// Size: 0x28 (Inherited: 0x00)
struct FBaseRequest {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct CommunitySdk.BaseResponse
// Size: 0x30 (Inherited: 0x00)
struct FBaseResponse {
	int32_t Error; // 0x00(0x04)
	int32_t Modlue; // 0x04(0x04)
	int32_t Line; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Text; // 0x10(0x10)
	struct FString Defined; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.BaseResponseSubscriptionInfo
// Size: 0xd0 (Inherited: 0x30)
struct FBaseResponseSubscriptionInfo : FBaseResponse {
	char pad_30[0x10]; // 0x30(0x10)
	struct FString MtalkToken; // 0x40(0x10)
	struct FString CharacterId; // 0x50(0x10)
	struct FSubscriptionInfo SubscriptionInfo; // 0x60(0x60)
	struct TArray<struct FGameRoomInfo> GameRoomInfoList; // 0xc0(0x10)
};

// ScriptStruct CommunitySdk.GameRoomInfo
// Size: 0xa8 (Inherited: 0x00)
struct FGameRoomInfo {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x00(0x30)
	struct FString GameCode; // 0x30(0x10)
	struct FString Name; // 0x40(0x10)
	int32_t MemberCount; // 0x50(0x04)
	int32_t VoiceMemberCount; // 0x54(0x04)
	int32_t MaxMemberCount; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FString LastMessageContent; // 0x60(0x10)
	struct FString DateLastMessagePublished; // 0x70(0x10)
	struct FString LastMessageGuid; // 0x80(0x10)
	struct FString DateCreated; // 0x90(0x10)
	bool Deleted; // 0xa0(0x01)
	char pad_A1[0x7]; // 0xa1(0x07)
};

// ScriptStruct CommunitySdk.SubscriptionInfo
// Size: 0x60 (Inherited: 0x00)
struct FSubscriptionInfo {
	struct FString TopicName; // 0x00(0x10)
	struct FString SubscribeUrl; // 0x10(0x10)
	struct FString Login; // 0x20(0x10)
	struct FString Passcode; // 0x30(0x10)
	struct FString WorldTopic; // 0x40(0x10)
	struct FString ServerAppDest; // 0x50(0x10)
};

// ScriptStruct CommunitySdk.BaseTranslateApiResponse
// Size: 0x20 (Inherited: 0x00)
struct FBaseTranslateApiResponse {
	struct FString raw_data; // 0x00(0x10)
	struct FString tid; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.CharacterStatusInfo
// Size: 0x01 (Inherited: 0x00)
struct FCharacterStatusInfo {
	bool ReceiveOneOnOne; // 0x00(0x01)
};

// ScriptStruct CommunitySdk.CommunityChatError
// Size: 0x20 (Inherited: 0x00)
struct FCommunityChatError {
	bool IsError; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Domain; // 0x04(0x04)
	int32_t Error; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString reason; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.CommunityLiveError
// Size: 0x40 (Inherited: 0x00)
struct FCommunityLiveError {
	bool IsError; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Domain; // 0x08(0x10)
	struct FString Uri; // 0x18(0x10)
	int32_t Error; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FString reason; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.EventInvitation
// Size: 0xe0 (Inherited: 0x30)
struct FEventInvitation : FBaseEvent {
	struct FEventInvitationContent EventContent; // 0x30(0xb0)
};

// ScriptStruct CommunitySdk.EventInvitationContent
// Size: 0xb0 (Inherited: 0x00)
struct FEventInvitationContent {
	struct FGameRoomInvitationInfo InvitationInfo; // 0x00(0xb0)
};

// ScriptStruct CommunitySdk.GameRoomInvitationInfo
// Size: 0xb0 (Inherited: 0x00)
struct FGameRoomInvitationInfo {
	struct FString InvitationId; // 0x00(0x10)
	struct FString ChatGroupId; // 0x10(0x10)
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x20(0x30)
	struct FString RoomName; // 0x50(0x10)
	struct FString InviterGameUserId; // 0x60(0x10)
	struct FString InviterCharacterName; // 0x70(0x10)
	struct FString InviteeGameUserId; // 0x80(0x10)
	struct FString InviteeCharacterName; // 0x90(0x10)
	struct FString DateCreated; // 0xa0(0x10)
};

// ScriptStruct CommunitySdk.EventUpdateRoom
// Size: 0xe8 (Inherited: 0x30)
struct FEventUpdateRoom : FBaseEvent {
	struct FEventUpdateRoomContent EventContent; // 0x30(0xb8)
};

// ScriptStruct CommunitySdk.EventUpdateRoomContent
// Size: 0xb8 (Inherited: 0x00)
struct FEventUpdateRoomContent {
	struct FGameRoomInfo GameRoomInfo; // 0x00(0xa8)
	struct TArray<struct FGameRoomUserInfo> GameRoomUserInfoList; // 0xa8(0x10)
};

// ScriptStruct CommunitySdk.GameRoomUserInfo
// Size: 0x1b8 (Inherited: 0x00)
struct FGameRoomUserInfo {
	struct FString CharacterId; // 0x00(0x10)
	struct FString Role; // 0x10(0x10)
	struct FString DateUserJoined; // 0x20(0x10)
	bool UserLeft; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString DateUserLeft; // 0x38(0x10)
	bool UserBanned; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FString DateUserBanned; // 0x50(0x10)
	bool UserVoiceMuted; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
	struct FString DateUserVoiceMuted; // 0x68(0x10)
	bool UserMicOffed; // 0x78(0x01)
	char pad_79[0x7]; // 0x79(0x07)
	struct FString DateUserMicOffed; // 0x80(0x10)
	bool UserSpeakerOffed; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FString DateUserSpeakerOffed; // 0x98(0x10)
	bool UserVoiceJoined; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FString DateUserVoiceJoined; // 0xb0(0x10)
	struct FGameUserInfo GameUserInfo; // 0xc0(0xf8)
};

// ScriptStruct CommunitySdk.GameUserInfo
// Size: 0xf8 (Inherited: 0x00)
struct FGameUserInfo {
	struct FString CharacterId; // 0x00(0x10)
	struct FString GameCode; // 0x10(0x10)
	struct FString NpGameAccountId; // 0x20(0x10)
	struct FString CharacterName; // 0x30(0x10)
	struct FString ServerName; // 0x40(0x10)
	struct FString GameUserId; // 0x50(0x10)
	struct FString UserThemeColor; // 0x60(0x10)
	struct FString Intro; // 0x70(0x10)
	struct FString ProfileImageUrlSmall; // 0x80(0x10)
	struct FString ProfileImageUrlLarge; // 0x90(0x10)
	struct FString Tag; // 0xa0(0x10)
	struct FString RankName; // 0xb0(0x10)
	struct FString ClassId; // 0xc0(0x10)
	struct FString Gender; // 0xd0(0x10)
	bool HasCastle; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	int32_t Ranking; // 0xe4(0x04)
	struct FString ServerId; // 0xe8(0x10)
};

// ScriptStruct CommunitySdk.GameChatMessageInfo
// Size: 0x30 (Inherited: 0x00)
struct FGameChatMessageInfo {
	struct FString Guid; // 0x00(0x10)
	struct FString Content; // 0x10(0x10)
	struct FString DateCreated; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.GameMessageInfo
// Size: 0x70 (Inherited: 0x00)
struct FGameMessageInfo {
	struct FString UserName; // 0x00(0x10)
	struct FString Type; // 0x10(0x10)
	struct FString SubType; // 0x20(0x10)
	struct FString Content; // 0x30(0x10)
	struct FString Attribute; // 0x40(0x10)
	struct FString Optional; // 0x50(0x10)
	struct FAttachmentInfo AttachmentInfo; // 0x60(0x10)
};

// ScriptStruct CommunitySdk.GamePresetInfo
// Size: 0x48 (Inherited: 0x00)
struct FGamePresetInfo {
	struct FString ID; // 0x00(0x10)
	struct FString GameCode; // 0x10(0x10)
	bool ServerKeyRequired; // 0x20(0x01)
	bool ValidatePlayNcUser; // 0x21(0x01)
	bool ValidateGameKey; // 0x22(0x01)
	bool UseGameData; // 0x23(0x01)
	bool AutoCreateGameUser; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	struct FString DateCreated; // 0x28(0x10)
	struct FString DateLastUpdated; // 0x38(0x10)
};

// ScriptStruct CommunitySdk.GameRoomPresetInfo
// Size: 0x58 (Inherited: 0x00)
struct FGameRoomPresetInfo {
	struct FString ID; // 0x00(0x10)
	struct FString GameCode; // 0x10(0x10)
	struct FString Type; // 0x20(0x10)
	bool Storable; // 0x30(0x01)
	bool AccessNotifiable; // 0x31(0x01)
	bool ReadConfirmable; // 0x32(0x01)
	bool MemberCountable; // 0x33(0x01)
	bool AutoCreatable; // 0x34(0x01)
	bool AutoDeletable; // 0x35(0x01)
	bool ClientUserJoinWhenCreateRoom; // 0x36(0x01)
	bool ErrorWhenCreateRoomExist; // 0x37(0x01)
	struct FString DateCreated; // 0x38(0x10)
	struct FString DateLastUpdated; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.GameRoomSecurityInfo
// Size: 0x18 (Inherited: 0x00)
struct FGameRoomSecurityInfo {
	bool IsPrivate; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FString Password; // 0x08(0x10)
};

// ScriptStruct CommunitySdk.GameRoomUserVoiceInfo
// Size: 0x58 (Inherited: 0x00)
struct FGameRoomUserVoiceInfo {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x00(0x30)
	struct FString GameUserId; // 0x30(0x10)
	bool VoiceJoined; // 0x40(0x01)
	char pad_41[0x7]; // 0x41(0x07)
	struct FString DateUserVoiceJoined; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.GameUserKey
// Size: 0x20 (Inherited: 0x00)
struct FGameUserKey {
	struct FString CharacterId; // 0x00(0x10)
	struct FString ServerKey; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.GoogleJson
// Size: 0xa8 (Inherited: 0x00)
struct FGoogleJson {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString Type; // 0x08(0x10)
	struct FString project_id; // 0x18(0x10)
	struct FString private_key_id; // 0x28(0x10)
	struct FString private_key; // 0x38(0x10)
	struct FString client_email; // 0x48(0x10)
	struct FString client_id; // 0x58(0x10)
	struct FString auth_uri; // 0x68(0x10)
	struct FString token_uri; // 0x78(0x10)
	struct FString auth_provider_x509_cert_url; // 0x88(0x10)
	struct FString client_x509_cert_url; // 0x98(0x10)
};

// ScriptStruct CommunitySdk.GoogleSTTError
// Size: 0x18 (Inherited: 0x00)
struct FGoogleSTTError {
	bool IsError; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t Error; // 0x04(0x04)
	struct FString reason; // 0x08(0x10)
};

// ScriptStruct CommunitySdk.MediaRole
// Size: 0x20 (Inherited: 0x00)
struct FMediaRole {
	struct FString Audio; // 0x00(0x10)
	struct FString Video; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.MediaSignalServer
// Size: 0x20 (Inherited: 0x00)
struct FMediaSignalServer {
	struct FString HttpHost; // 0x00(0x10)
	struct FString WebSocketURL; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.MediaStatus
// Size: 0x20 (Inherited: 0x00)
struct FMediaStatus {
	struct FString Audio; // 0x00(0x10)
	struct FString Video; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.MessageInfo
// Size: 0xd0 (Inherited: 0x00)
struct FMessageInfo {
	struct FString Guid; // 0x00(0x10)
	struct FString GameUserId; // 0x10(0x10)
	struct FString PlayNcCharId; // 0x20(0x10)
	struct FString UserName; // 0x30(0x10)
	struct FString Type; // 0x40(0x10)
	struct FString SubType; // 0x50(0x10)
	struct FString Content; // 0x60(0x10)
	struct FString Attribute; // 0x70(0x10)
	bool Deleted; // 0x80(0x01)
	char pad_81[0x7]; // 0x81(0x07)
	struct FString DateCreated; // 0x88(0x10)
	struct FString UserServerKey; // 0x98(0x10)
	bool HasReplacedContent; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct TArray<struct FReplacedMessageInfo> ReplacedMessageInfoList; // 0xb0(0x10)
	struct FAttachmentInfo AttachmentInfo; // 0xc0(0x10)
};

// ScriptStruct CommunitySdk.NotificationBanChat
// Size: 0x218 (Inherited: 0x218)
struct FNotificationBanChat : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationCloseRoom
// Size: 0x218 (Inherited: 0x218)
struct FNotificationCloseRoom : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationDeportRoom
// Size: 0x218 (Inherited: 0x218)
struct FNotificationDeportRoom : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationEnterRoom
// Size: 0x218 (Inherited: 0x218)
struct FNotificationEnterRoom : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationLeaveRoom
// Size: 0x218 (Inherited: 0x218)
struct FNotificationLeaveRoom : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationReceiveMessage
// Size: 0x218 (Inherited: 0x218)
struct FNotificationReceiveMessage : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationTransferOwnerRoom
// Size: 0x218 (Inherited: 0x218)
struct FNotificationTransferOwnerRoom : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationUpdateUserRole
// Size: 0x218 (Inherited: 0x218)
struct FNotificationUpdateUserRole : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationVoice
// Size: 0x218 (Inherited: 0x218)
struct FNotificationVoice : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationVoiceMic
// Size: 0x218 (Inherited: 0x218)
struct FNotificationVoiceMic : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationVoiceMute
// Size: 0x218 (Inherited: 0x218)
struct FNotificationVoiceMute : FBaseNotification {
};

// ScriptStruct CommunitySdk.NotificationVoiceSpeaker
// Size: 0x218 (Inherited: 0x218)
struct FNotificationVoiceSpeaker : FBaseNotification {
};

// ScriptStruct CommunitySdk.PlayerInfo
// Size: 0xc0 (Inherited: 0x00)
struct FPlayerInfo {
	struct FString ServiceType; // 0x00(0x10)
	struct FString AppGroupCode; // 0x10(0x10)
	struct FString Scope; // 0x20(0x10)
	struct FString RoomId; // 0x30(0x10)
	struct FString PlayerId; // 0x40(0x10)
	struct FString PlayerName; // 0x50(0x10)
	struct FString Role; // 0x60(0x10)
	struct FMediaRole MediaRole; // 0x70(0x20)
	struct FMediaStatus MediaStatus; // 0x90(0x20)
	struct FString CreateTime; // 0xb0(0x10)
};

// ScriptStruct CommunitySdk.RequestAcceptInvitation
// Size: 0x40 (Inherited: 0x28)
struct FRequestAcceptInvitation : FBaseRequest {
	struct FString InvitationId; // 0x28(0x10)
	bool Accept; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct CommunitySdk.RequestBanUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestBanUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestBlockUser
// Size: 0x58 (Inherited: 0x28)
struct FRequestBlockUser : FBaseRequest {
	struct FTargetUserKey TargetUserKey; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.TargetUserKey
// Size: 0x30 (Inherited: 0x00)
struct FTargetUserKey {
	struct FString CharacterId; // 0x00(0x10)
	struct FString CharacterName; // 0x10(0x10)
	struct FString ServerKey; // 0x20(0x10)
};

// ScriptStruct CommunitySdk.RequestChangeReceivingVolume
// Size: 0x80 (Inherited: 0x28)
struct FRequestChangeReceivingVolume : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FGameUserKey GameUserKey; // 0x58(0x20)
	int32_t Volume; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct CommunitySdk.RequestCreateGameReport
// Size: 0xc8 (Inherited: 0x28)
struct FRequestCreateGameReport : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FGameChatMessageInfo GameChatMessageInfo; // 0x58(0x30)
	struct FString GameCode; // 0x88(0x10)
	struct FString CharacterId; // 0x98(0x10)
	struct FString reason; // 0xa8(0x10)
	struct FString ServerKey; // 0xb8(0x10)
};

// ScriptStruct CommunitySdk.RequestCreateOneOnOneRoomWithUser
// Size: 0x48 (Inherited: 0x28)
struct FRequestCreateOneOnOneRoomWithUser : FBaseRequest {
	struct FGameUserKey GameUserKey; // 0x28(0x20)
};

// ScriptStruct CommunitySdk.RequestCreateRoom
// Size: 0x88 (Inherited: 0x28)
struct FRequestCreateRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Name; // 0x58(0x10)
	struct FGameRoomSecurityInfo GameRoomSecurityInfo; // 0x68(0x18)
	int32_t MaxMemberCount; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
};

// ScriptStruct CommunitySdk.RequestDeleteRoom
// Size: 0x58 (Inherited: 0x28)
struct FRequestDeleteRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestDeportUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestDeportUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestFilterContent
// Size: 0x58 (Inherited: 0x28)
struct FRequestFilterContent : FBaseRequest {
	struct FString RuleSetType; // 0x28(0x10)
	struct FString Content; // 0x38(0x10)
	struct FString Masking; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.RequestGameRoomKeyInfo
// Size: 0x50 (Inherited: 0x00)
struct FRequestGameRoomKeyInfo {
	struct TMap<struct FString, struct FString> GameRoomInfo; // 0x00(0x50)
};

// ScriptStruct CommunitySdk.RequestGetBlockUserList
// Size: 0x28 (Inherited: 0x28)
struct FRequestGetBlockUserList : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestGetFileUploadUrl
// Size: 0x28 (Inherited: 0x28)
struct FRequestGetFileUploadUrl : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestGetGamePresetInfo
// Size: 0x28 (Inherited: 0x28)
struct FRequestGetGamePresetInfo : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestGetGameRoomPresetInfo
// Size: 0x38 (Inherited: 0x28)
struct FRequestGetGameRoomPresetInfo : FBaseRequest {
	struct FString Type; // 0x28(0x10)
};

// ScriptStruct CommunitySdk.RequestGetGameRoomPresetList
// Size: 0x28 (Inherited: 0x28)
struct FRequestGetGameRoomPresetList : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestGetInvitationList
// Size: 0x40 (Inherited: 0x28)
struct FRequestGetInvitationList : FBaseRequest {
	struct FString Cursor; // 0x28(0x10)
	int32_t MaxListCount; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct CommunitySdk.RequestGetRoom
// Size: 0x58 (Inherited: 0x28)
struct FRequestGetRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestGetRoomInvitationToken
// Size: 0x58 (Inherited: 0x28)
struct FRequestGetRoomInvitationToken : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestGetRoomVoiceUsers
// Size: 0x70 (Inherited: 0x28)
struct FRequestGetRoomVoiceUsers : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Cursor; // 0x58(0x10)
	int32_t MaxListCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct CommunitySdk.RequestGetSubscriptionInfo
// Size: 0x48 (Inherited: 0x28)
struct FRequestGetSubscriptionInfo : FBaseRequest {
	struct FString CharacterId; // 0x28(0x10)
	struct FString ServerKey; // 0x38(0x10)
};

// ScriptStruct CommunitySdk.RequestGetVoiceRoomList
// Size: 0x28 (Inherited: 0x28)
struct FRequestGetVoiceRoomList : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestGoogleSTTRecognize
// Size: 0x40 (Inherited: 0x00)
struct FRequestGoogleSTTRecognize {
	char pad_0[0x8]; // 0x00(0x08)
	struct FConfig Config; // 0x08(0x28)
	struct FAudio Audio; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.Audio
// Size: 0x10 (Inherited: 0x00)
struct FAudio {
	struct FString Content; // 0x00(0x10)
};

// ScriptStruct CommunitySdk.Config
// Size: 0x28 (Inherited: 0x00)
struct FConfig {
	struct FString languageCode; // 0x00(0x10)
	struct FString encoding; // 0x10(0x10)
	int32_t sampleRateHertz; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct CommunitySdk.RequestInviteUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestInviteUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestJoinedRoomList
// Size: 0x38 (Inherited: 0x28)
struct FRequestJoinedRoomList : FBaseRequest {
	struct FString ServerKey; // 0x28(0x10)
};

// ScriptStruct CommunitySdk.RequestJoinRoom
// Size: 0x80 (Inherited: 0x28)
struct FRequestJoinRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Role; // 0x58(0x10)
	struct FGameRoomSecurityInfo GameRoomSecurityInfo; // 0x68(0x18)
};

// ScriptStruct CommunitySdk.RequestLeaveRoom
// Size: 0x58 (Inherited: 0x28)
struct FRequestLeaveRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestLoginWithToken
// Size: 0xb8 (Inherited: 0x28)
struct FRequestLoginWithToken : FBaseRequest {
	struct FString AuthnToken; // 0x28(0x10)
	struct FString GameCode; // 0x38(0x10)
	struct FString DeviceID; // 0x48(0x10)
	struct FString ClientType; // 0x58(0x10)
	struct FString CharacterId; // 0x68(0x10)
	struct TArray<struct FGameRoomKeyInfo> GameRoomKeyInfoList; // 0x78(0x10)
	struct FString ServerKey; // 0x88(0x10)
	struct FString Locale; // 0x98(0x10)
	struct FString ClientAppId; // 0xa8(0x10)
};

// ScriptStruct CommunitySdk.RequestLogoutWithJwtToken
// Size: 0x28 (Inherited: 0x28)
struct FRequestLogoutWithJwtToken : FBaseRequest {
};

// ScriptStruct CommunitySdk.RequestMessagesBackward
// Size: 0x70 (Inherited: 0x28)
struct FRequestMessagesBackward : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Cursor; // 0x58(0x10)
	int32_t MaxListCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct CommunitySdk.RequestMessagesForward
// Size: 0x70 (Inherited: 0x28)
struct FRequestMessagesForward : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Cursor; // 0x58(0x10)
	int32_t MaxListCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct CommunitySdk.RequestMuteVoiceUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestMuteVoiceUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestRoomList
// Size: 0x50 (Inherited: 0x28)
struct FRequestRoomList : FBaseRequest {
	struct FString Type; // 0x28(0x10)
	struct FString Cursor; // 0x38(0x10)
	int32_t MaxListCount; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
};

// ScriptStruct CommunitySdk.RequestRoomUsers
// Size: 0x70 (Inherited: 0x28)
struct FRequestRoomUsers : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString Cursor; // 0x58(0x10)
	int32_t MaxListCount; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct CommunitySdk.RequestSearchRoom
// Size: 0xc0 (Inherited: 0x28)
struct FRequestSearchRoom : FBaseRequest {
	struct FSearchRoomObject SearchRoomObject; // 0x28(0x98)
};

// ScriptStruct CommunitySdk.SearchRoomObject
// Size: 0x98 (Inherited: 0x00)
struct FSearchRoomObject {
	struct FString SearchType; // 0x00(0x10)
	struct TMap<struct FString, struct FString> SearchCondition; // 0x10(0x50)
	struct FString SortField; // 0x60(0x10)
	struct FString SortOrder; // 0x70(0x10)
	struct FString Cursor; // 0x80(0x10)
	int32_t MaxListCount; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
};

// ScriptStruct CommunitySdk.RequestSendAlert
// Size: 0x98 (Inherited: 0x28)
struct FRequestSendAlert : FBaseRequest {
	struct FGameMessageInfo GameMessageInfo; // 0x28(0x70)
};

// ScriptStruct CommunitySdk.RequestSendMessage
// Size: 0xc8 (Inherited: 0x28)
struct FRequestSendMessage : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FGameMessageInfo GameMessageInfo; // 0x58(0x70)
};

// ScriptStruct CommunitySdk.RequestSendWhisper
// Size: 0xb8 (Inherited: 0x28)
struct FRequestSendWhisper : FBaseRequest {
	struct FGameUserKey GameUserKey; // 0x28(0x20)
	struct FGameMessageInfo GameMessageInfo; // 0x48(0x70)
};

// ScriptStruct CommunitySdk.RequestStartVoiceChat
// Size: 0x58 (Inherited: 0x28)
struct FRequestStartVoiceChat : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestStopVoiceChat
// Size: 0x58 (Inherited: 0x28)
struct FRequestStopVoiceChat : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestTransferOwner
// Size: 0x78 (Inherited: 0x28)
struct FRequestTransferOwner : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestTranslate
// Size: 0x58 (Inherited: 0x00)
struct FRequestTranslate {
	char pad_0[0x8]; // 0x00(0x08)
	struct FString tid; // 0x08(0x10)
	struct FString source_lang; // 0x18(0x10)
	struct FString source_text; // 0x28(0x10)
	struct FString target_lang; // 0x38(0x10)
	struct FString sent_from; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.RequestUnbanUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestUnbanUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestUnblockUser
// Size: 0x58 (Inherited: 0x28)
struct FRequestUnblockUser : FBaseRequest {
	struct FTargetUserKey TargetUserKey; // 0x28(0x30)
};

// ScriptStruct CommunitySdk.RequestUnmuteVoiceUser
// Size: 0x78 (Inherited: 0x28)
struct FRequestUnmuteVoiceUser : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestUpdateCharacterStatus
// Size: 0x30 (Inherited: 0x28)
struct FRequestUpdateCharacterStatus : FBaseRequest {
	struct FCharacterStatusInfo CharacterStatusInfo; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};

// ScriptStruct CommunitySdk.RequestUpdateRoom
// Size: 0x78 (Inherited: 0x28)
struct FRequestUpdateRoom : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString NewPassword; // 0x58(0x10)
	struct FString NewName; // 0x68(0x10)
};

// ScriptStruct CommunitySdk.RequestUpdateUserRole
// Size: 0x88 (Inherited: 0x28)
struct FRequestUpdateUserRole : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	struct FString CharacterId; // 0x58(0x10)
	struct FString ServerKey; // 0x68(0x10)
	struct FString Role; // 0x78(0x10)
};

// ScriptStruct CommunitySdk.RequestUpdateVoiceChatStatus
// Size: 0x60 (Inherited: 0x28)
struct FRequestUpdateVoiceChatStatus : FBaseRequest {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x28(0x30)
	bool MicOffed; // 0x58(0x01)
	bool SpeakerOffed; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)
};

// ScriptStruct CommunitySdk.RequestUploadFile
// Size: 0x48 (Inherited: 0x28)
struct FRequestUploadFile : FBaseRequest {
	struct FString UploadUrl; // 0x28(0x10)
	struct FString FilePath; // 0x38(0x10)
};

// ScriptStruct CommunitySdk.ResponseAcceptInvitation
// Size: 0x190 (Inherited: 0x30)
struct FResponseAcceptInvitation : FBaseResponse {
	struct FGameRoomInvitationInfo InvitationInfo; // 0x30(0xb0)
	struct FGameRoomInfo GameRoomInfo; // 0xe0(0xa8)
	bool Accept; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
};

// ScriptStruct CommunitySdk.ResponseBanUser
// Size: 0x218 (Inherited: 0x30)
struct FResponseBanUser : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseBlockUser
// Size: 0x68 (Inherited: 0x30)
struct FResponseBlockUser : FBaseResponse {
	struct FTargetUserKey TargetUserKey; // 0x30(0x30)
	bool Blocked; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct CommunitySdk.ResponseChangeReceivingVolume
// Size: 0x30 (Inherited: 0x30)
struct FResponseChangeReceivingVolume : FBaseResponse {
};

// ScriptStruct CommunitySdk.ResponseCreateGameReport
// Size: 0x40 (Inherited: 0x30)
struct FResponseCreateGameReport : FBaseResponse {
	struct FString Message; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseCreateOneOnOneRoomWithUser
// Size: 0xd8 (Inherited: 0x30)
struct FResponseCreateOneOnOneRoomWithUser : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseCreateRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseCreateRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseDeleteRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseDeleteRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseDeportUser
// Size: 0x218 (Inherited: 0x30)
struct FResponseDeportUser : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseFilterContent
// Size: 0x50 (Inherited: 0x30)
struct FResponseFilterContent : FBaseResponse {
	struct FString Content; // 0x30(0x10)
	struct FString Result; // 0x40(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetBlockUserList
// Size: 0x40 (Inherited: 0x30)
struct FResponseGetBlockUserList : FBaseResponse {
	struct TArray<struct FTargetUserKey> BlockedUserList; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetFileUploadUrl
// Size: 0x40 (Inherited: 0x30)
struct FResponseGetFileUploadUrl : FBaseResponse {
	struct FString UploadUrl; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetGamePresetInfo
// Size: 0x78 (Inherited: 0x30)
struct FResponseGetGamePresetInfo : FBaseResponse {
	struct FGamePresetInfo GamePresetInfo; // 0x30(0x48)
};

// ScriptStruct CommunitySdk.ResponseGetGameRoomPresetInfo
// Size: 0x88 (Inherited: 0x30)
struct FResponseGetGameRoomPresetInfo : FBaseResponse {
	struct FGameRoomPresetInfo GameRoomPresetInfo; // 0x30(0x58)
};

// ScriptStruct CommunitySdk.ResponseGetGameRoomPresetList
// Size: 0x40 (Inherited: 0x30)
struct FResponseGetGameRoomPresetList : FBaseResponse {
	struct TArray<struct FGameRoomPresetInfo> GameRoomPresetList; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetInvitationList
// Size: 0x58 (Inherited: 0x30)
struct FResponseGetInvitationList : FBaseResponse {
	struct FString Cursor; // 0x30(0x10)
	int32_t Count; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
	struct TArray<struct FGameRoomInvitationInfo> InvitationInfoList; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseGetRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseGetRoomInvitationToken
// Size: 0xf8 (Inherited: 0x30)
struct FResponseGetRoomInvitationToken : FBaseResponse {
	struct FString InvitationToken; // 0x30(0x10)
	struct FString InvitationUrl; // 0x40(0x10)
	struct FGameRoomInfo GameRoomInfo; // 0x50(0xa8)
};

// ScriptStruct CommunitySdk.ResponseGetRoomVoiceUsers
// Size: 0x88 (Inherited: 0x30)
struct FResponseGetRoomVoiceUsers : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct TArray<struct FGameRoomUserInfo> GameRoomUserInfoList; // 0x60(0x10)
	int32_t Count; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FString Cursor; // 0x78(0x10)
};

// ScriptStruct CommunitySdk.ResponseGetSubscriptionInfo
// Size: 0xd0 (Inherited: 0xd0)
struct FResponseGetSubscriptionInfo : FBaseResponseSubscriptionInfo {
};

// ScriptStruct CommunitySdk.ResponseGetVoiceRoomList
// Size: 0x50 (Inherited: 0x30)
struct FResponseGetVoiceRoomList : FBaseResponse {
	struct TArray<struct FGameRoomInfo> GameRoomInfoList; // 0x30(0x10)
	struct TArray<struct FGameRoomUserVoiceInfo> GameRoomUserVoiceInfoList; // 0x40(0x10)
};

// ScriptStruct CommunitySdk.ResponseGoogleSTTRecognize
// Size: 0x50 (Inherited: 0x30)
struct FResponseGoogleSTTRecognize : FBaseGoogleSTTResponse {
	struct TArray<struct FResults> Results; // 0x30(0x10)
	struct FString totalBilledTime; // 0x40(0x10)
};

// ScriptStruct CommunitySdk.Results
// Size: 0x10 (Inherited: 0x00)
struct FResults {
	struct TArray<struct FAlternatives> Alternatives; // 0x00(0x10)
};

// ScriptStruct CommunitySdk.Alternatives
// Size: 0x20 (Inherited: 0x00)
struct FAlternatives {
	struct FString Confidence; // 0x00(0x10)
	struct FString transcript; // 0x10(0x10)
};

// ScriptStruct CommunitySdk.ResponseGoogleSTTUpload
// Size: 0x40 (Inherited: 0x30)
struct FResponseGoogleSTTUpload : FBaseGoogleSTTResponse {
	struct FString tempText; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseInviteUser
// Size: 0xe0 (Inherited: 0x30)
struct FResponseInviteUser : FBaseResponse {
	struct FGameRoomInvitationInfo InvitationInfo; // 0x30(0xb0)
};

// ScriptStruct CommunitySdk.ResponseJoinedRoomList
// Size: 0x40 (Inherited: 0x30)
struct FResponseJoinedRoomList : FBaseResponse {
	struct TArray<struct FGameRoomInfo> GameRoomInfoList; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseJoinRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseJoinRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseLeaveRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseLeaveRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseLoginWithToken
// Size: 0xd0 (Inherited: 0xd0)
struct FResponseLoginWithToken : FBaseResponseSubscriptionInfo {
};

// ScriptStruct CommunitySdk.ResponseLogoutWithJwtToken
// Size: 0x30 (Inherited: 0x30)
struct FResponseLogoutWithJwtToken : FBaseResponse {
};

// ScriptStruct CommunitySdk.ResponseMessagesBackward
// Size: 0xa8 (Inherited: 0x30)
struct FResponseMessagesBackward : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FString DateBucketStart; // 0x60(0x10)
	struct TArray<struct FMessageInfo> MessageInfoList; // 0x70(0x10)
	int32_t MessageCount; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FString BackwardCursor; // 0x88(0x10)
	struct FString ForwardCursor; // 0x98(0x10)
};

// ScriptStruct CommunitySdk.ResponseMessagesForward
// Size: 0xa8 (Inherited: 0x30)
struct FResponseMessagesForward : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FString DateBucketStart; // 0x60(0x10)
	struct TArray<struct FMessageInfo> MessageInfoList; // 0x70(0x10)
	int32_t MessageCount; // 0x80(0x04)
	char pad_84[0x4]; // 0x84(0x04)
	struct FString BackwardCursor; // 0x88(0x10)
	struct FString ForwardCursor; // 0x98(0x10)
};

// ScriptStruct CommunitySdk.ResponseMuteVoiceUser
// Size: 0x218 (Inherited: 0x30)
struct FResponseMuteVoiceUser : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseRoomList
// Size: 0x68 (Inherited: 0x30)
struct FResponseRoomList : FBaseResponse {
	struct FString Type; // 0x30(0x10)
	struct FString Cursor; // 0x40(0x10)
	int32_t Count; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
	struct TArray<struct FGameRoomInfo> GameRoomInfoList; // 0x58(0x10)
};

// ScriptStruct CommunitySdk.ResponseRoomUsers
// Size: 0x88 (Inherited: 0x30)
struct FResponseRoomUsers : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct TArray<struct FGameRoomUserInfo> GameRoomUserInfoList; // 0x60(0x10)
	int32_t Count; // 0x70(0x04)
	char pad_74[0x4]; // 0x74(0x04)
	struct FString Cursor; // 0x78(0x10)
};

// ScriptStruct CommunitySdk.ResponseSearchRoom
// Size: 0x48 (Inherited: 0x30)
struct FResponseSearchRoom : FBaseResponse {
	int32_t Count; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TArray<struct FGameRoomInfo> GameRoomInfoList; // 0x38(0x10)
};

// ScriptStruct CommunitySdk.ResponseSendAlert
// Size: 0x40 (Inherited: 0x30)
struct FResponseSendAlert : FBaseResponse {
	struct FString Guid; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseSendMessage
// Size: 0x40 (Inherited: 0x30)
struct FResponseSendMessage : FBaseResponse {
	struct FString Guid; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseSendWhisper
// Size: 0x40 (Inherited: 0x30)
struct FResponseSendWhisper : FBaseResponse {
	struct FString Guid; // 0x30(0x10)
};

// ScriptStruct CommunitySdk.ResponseStartVoiceChat
// Size: 0x140 (Inherited: 0x30)
struct FResponseStartVoiceChat : FBaseResponse {
	struct FString tid; // 0x30(0x10)
	struct FString authKey; // 0x40(0x10)
	struct FPlayerInfo Player; // 0x50(0xc0)
	struct FMediaSignalServer MediaSignalServer; // 0x110(0x20)
	struct FString KeepAliveInterval; // 0x130(0x10)
};

// ScriptStruct CommunitySdk.ResponseStopVoiceChat
// Size: 0x50 (Inherited: 0x30)
struct FResponseStopVoiceChat : FBaseResponse {
	struct FString tid; // 0x30(0x10)
	struct FString Action; // 0x40(0x10)
};

// ScriptStruct CommunitySdk.ResponseTransferOwner
// Size: 0x3d0 (Inherited: 0x30)
struct FResponseTransferOwner : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo PredecessorUserInfo; // 0x60(0x1b8)
	struct FGameRoomUserInfo SuccessorUserInfo; // 0x218(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseTranslate
// Size: 0x80 (Inherited: 0x20)
struct FResponseTranslate : FBaseTranslateApiResponse {
	struct FString source_lang; // 0x20(0x10)
	struct FString source_text; // 0x30(0x10)
	struct FString target_lang; // 0x40(0x10)
	struct FString target_text; // 0x50(0x10)
	struct FString game_code; // 0x60(0x10)
	struct FString sent_from; // 0x70(0x10)
};

// ScriptStruct CommunitySdk.ResponseUnbanUser
// Size: 0x218 (Inherited: 0x30)
struct FResponseUnbanUser : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseUnblockUser
// Size: 0x68 (Inherited: 0x30)
struct FResponseUnblockUser : FBaseResponse {
	struct FTargetUserKey TargetUserKey; // 0x30(0x30)
	bool Blocked; // 0x60(0x01)
	char pad_61[0x7]; // 0x61(0x07)
};

// ScriptStruct CommunitySdk.ResponseUnmuteVoiceUser
// Size: 0x218 (Inherited: 0x30)
struct FResponseUnmuteVoiceUser : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseUpdateCharacterStatus
// Size: 0x38 (Inherited: 0x30)
struct FResponseUpdateCharacterStatus : FBaseResponse {
	struct FCharacterStatusInfo CharacterStatusInfo; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct CommunitySdk.ResponseUpdateRoom
// Size: 0xd8 (Inherited: 0x30)
struct FResponseUpdateRoom : FBaseResponse {
	struct FGameRoomInfo GameRoomInfo; // 0x30(0xa8)
};

// ScriptStruct CommunitySdk.ResponseUpdateUserRole
// Size: 0x218 (Inherited: 0x30)
struct FResponseUpdateUserRole : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseUpdateVoiceChatStatus
// Size: 0x218 (Inherited: 0x30)
struct FResponseUpdateVoiceChatStatus : FBaseResponse {
	struct FGameRoomKeyInfo GameRoomKeyInfo; // 0x30(0x30)
	struct FGameRoomUserInfo GameRoomUserInfo; // 0x60(0x1b8)
};

// ScriptStruct CommunitySdk.ResponseUploadFile
// Size: 0x58 (Inherited: 0x00)
struct FResponseUploadFile {
	int32_t status; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString Error; // 0x08(0x10)
	struct FString Message; // 0x18(0x10)
	char pad_28[0x10]; // 0x28(0x10)
	struct FString auth_type; // 0x38(0x10)
	struct TArray<struct FUploadResult> upload_result_list; // 0x48(0x10)
};

// ScriptStruct CommunitySdk.UploadResult
// Size: 0x60 (Inherited: 0x00)
struct FUploadResult {
	struct FString download_url; // 0x00(0x10)
	struct FString view_url; // 0x10(0x10)
	struct FString thumbnail_url; // 0x20(0x10)
	struct FString extension; // 0x30(0x10)
	struct FUploadFileMetaData MetaData; // 0x40(0x0c)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct FString expire_at; // 0x50(0x10)
};

// ScriptStruct CommunitySdk.UploadFileMetaData
// Size: 0x0c (Inherited: 0x00)
struct FUploadFileMetaData {
	int32_t Width; // 0x00(0x04)
	int32_t Height; // 0x04(0x04)
	int32_t rotate_orientation; // 0x08(0x04)
};

