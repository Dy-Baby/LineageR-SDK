// WidgetBlueprintGeneratedClass UI_HUD_DeathPenalty_ToolTip.UI_HUD_DeathPenalty_ToolTip_C
// Size: 0x2e0 (Inherited: 0x2c8)
struct UUI_HUD_DeathPenalty_ToolTip_C : ULMRDeathPenaltyTooltipWidget {
	struct UTextBlock* TextBlock_1; // 0x2c8(0x08)
	struct UTextBlock* TextBlock_3; // 0x2d0(0x08)
	struct UTextBlock* TextBlock_4; // 0x2d8(0x08)
};

