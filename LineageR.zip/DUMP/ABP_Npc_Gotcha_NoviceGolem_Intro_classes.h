// AnimBlueprintGeneratedClass ABP_Npc_Gotcha_NoviceGolem_Intro.ABP_Npc_Gotcha_NoviceGolem_Intro_C
// Size: 0xa48 (Inherited: 0xa48)
struct UABP_Npc_Gotcha_NoviceGolem_Intro_C : UABP_Npc_Master_C {
};

