// Enum LineageR.ELMRActionSchedule
enum class ELMRActionSchedule : uint8 {
	Idle = 0,
	Attack = 1,
	NontargetAttack = 2,
	Cast = 3,
	Move = 4,
	Loot = 5,
	Cancel = 6,
	ELMRActionSchedule_MAX = 7
};

// Enum LineageR.ELMRAlignmentTyp
enum class ELMRAlignmentTyp : uint8 {
	Alignment_None = 0,
	Alignment_Lawful = 1,
	Alignment_Neutral = 2,
	Alignment_Chaotic = 3,
	Alignment_MaxLawful = 11,
	Alignment_MaxChaotic = 12,
	Alignment_MAX = 13
};

// Enum LineageR.ELMRRecognitionType
enum class ELMRRecognitionType : uint8 {
	RecognitionType_None = 0,
	RecognitionType_Exclamation = 1,
	RecognitionType_Question = 2,
	RecognitionType_MAX = 3
};

// Enum LineageR.EHitNotifyType
enum class EHitNotifyType : uint8 {
	Sub = 0,
	Main = 1,
	EHitNotifyType_MAX = 2
};

// Enum LineageR.ELMRItemBlessType
enum class ELMRItemBlessType : uint8 {
	None = 0,
	Normal = 1,
	Blessed = 2,
	Cursed = 3,
	ELMRItemBlessType_MAX = 4
};

// Enum LineageR.ELMRDisplayAttackType
enum class ELMRDisplayAttackType : int32 {
	None = -2,
	All = -1,
	Common = 0,
	ShortRange = 1,
	TwoGrid = 2,
	LongRange = 3,
	CastSpeed = 4,
	Heal = 5,
	MoveSpeed = 6,
	MagicDoll = 99,
	ELMRDisplayAttackType_MAX = 100
};

// Enum LineageR.ELMRSocketStoneType
enum class ELMRSocketStoneType : uint8 {
	None = 0,
	Eva = 1,
	Paagrio = 2,
	Sayha = 3,
	Maphr = 4,
	Shilen = 5,
	ELMRSocketStoneType_MAX = 6
};

// Enum LineageR.ELMRShopCartStatusType
enum class ELMRShopCartStatusType : uint8 {
	Default = 0,
	Available = 1,
	Full = 2,
	ELMRShopCartStatusType_MAX = 3
};

// Enum LineageR.ELMRShopWeightStatusType
enum class ELMRShopWeightStatusType : uint8 {
	Default = 0,
	NoPenalty = 1,
	CantIdleRecovery = 2,
	CantAction = 3,
	ELMRShopWeightStatusType_MAX = 4
};

// Enum LineageR.ELMRBodyStatusEffectType
enum class ELMRBodyStatusEffectType : uint8 {
	Default = 0,
	Stun = 1,
	Stone = 2,
	Poison = 3,
	Blind = 4,
	LowHp = 5,
	Transparent = 6,
	FireDebuff = 7,
	WaterDebuff = 8,
	WindDebuff = 9,
	EarthDebuff = 10,
	FrozenDebuff = 11,
	Charred = 12,
	ELMRBodyStatusEffectType_MAX = 13
};

// Enum LineageR.ELMRSpecialScreenStatusEffectType
enum class ELMRSpecialScreenStatusEffectType : uint8 {
	None = 0,
	FireFrame = 1,
	BlackAndWhite = 2,
	PotionOfCourage = 3,
	BlackAndWhiteOnOff = 4,
	BlueLight = 5,
	BlackAndWhite_2 = 6,
	BlackAndWhite_3 = 7,
	ELMRSpecialScreenStatusEffectType_MAX = 8
};

// Enum LineageR.ELMRScreenStatusEffectType
enum class ELMRScreenStatusEffectType : uint8 {
	None = 0,
	Stun = 1,
	Stone = 2,
	Poison = 3,
	Blind = 4,
	LowHp = 5,
	Transparent = 6,
	Death = 7,
	ELMRScreenStatusEffectType_MAX = 8
};

// Enum LineageR.ELMRWorldMapBookMarkColor
enum class ELMRWorldMapBookMarkColor : uint8 {
	Default = 0,
	Personal = 1,
	Clan = 2,
	Party = 3,
	Target = 4,
	ELMRWorldMapBookMarkColor_MAX = 5
};

// Enum LineageR.ELMRItemCraftAmountColor
enum class ELMRItemCraftAmountColor : uint8 {
	Enough = 0,
	NotEnough = 1,
	Max = 2
};

// Enum LineageR.ELMRTextColor
enum class ELMRTextColor : uint8 {
	Default = 0,
	SlotAmount = 1,
	SlotAmountMax = 2,
	SlotEnchant = 3,
	SlotEnchantSafe = 4,
	SlotEnchantUnsafe = 5,
	SlotLevelLimit = 6,
	EnoughCost = 7,
	NotEnoughCost = 8,
	Temporary_Default = 9,
	Temporary_Warning = 10,
	Illus_StatEnable = 11,
	Illus_StatValueEnable = 12,
	Illus_StatDisable = 13,
	SelectedText = 14,
	Illus_NotEnoughCost = 15,
	Illus_EnoughCost = 16,
	Illus_CompletedCost = 17,
	Learned_Spell = 18,
	ItemCraft_EnoughCost = 19,
	Gem_NotEnoughCost = 20,
	DefaultTextStyle = 21,
	ELMRTextColor_MAX = 22
};

// Enum LineageR.ELMRItemTooltipColor
enum class ELMRItemTooltipColor : uint8 {
	Default = 0,
	Enchant = 1,
	Spell = 2,
	New = 3,
	Exclude = 4,
	Increase = 5,
	Decrease = 6,
	Emphasis = 7,
	Bless = 8,
	Temporary = 9,
	NpcRaceType = 10,
	DefaultOption = 11,
	ELMRItemTooltipColor_MAX = 12
};

// Enum LineageR.ELMRBuffCardClassType
enum class ELMRBuffCardClassType : uint8 {
	All = 0,
	ShortDistance = 1,
	Spear = 2,
	LongDistance = 3,
	Magic = 4,
	Move = 5,
	ELMRBuffCardClassType_MAX = 6
};

// Enum LineageR.ELMRSlotNameColor
enum class ELMRSlotNameColor : uint8 {
	Item_None = 0,
	Item_Grade1 = 1,
	Item_Grade2 = 2,
	Item_Grade3 = 3,
	Item_Grade4 = 4,
	Item_Grade5 = 5,
	Item_Grade6 = 6,
	Item_GradeBM = 7,
	Spell_Normal = 8,
	MAX = 9
};

// Enum LineageR.ELMRObjectMaterialSwapAutoType
enum class ELMRObjectMaterialSwapAutoType : uint8 {
	Invalid = 0,
	Appear = 1,
	Dissolve = 2,
	ELMRObjectMaterialSwapAutoType_MAX = 3
};

// Enum LineageR.EAutoPlayAnimType
enum class EAutoPlayAnimType : uint8 {
	Intro = 0,
	Breath = 1,
	Outro = 2,
	Off = 3,
	EAutoPlayAnimType_MAX = 4
};

// Enum LineageR.ELMRBaseGestureType
enum class ELMRBaseGestureType : uint8 {
	None = 0,
	Click = 1,
	UnhandledClick = 2,
	DoubleClick = 3,
	Touch = 4,
	Press = 5,
	CapturedPress = 6,
	UnhandledTouch = 7,
	LongPressOnce = 8,
	LongPressRepeat = 9,
	VerticalSwipeOnce = 10,
	HorizontalSwipeOnce = 11,
	VerticalSwipeRepeat = 12,
	HorizontalSwipeRepeat = 13,
	SwipeOnce = 14,
	Joystick = 15,
	ConsumeSwipeGesture = 16,
	ConsumeLongPress = 17,
	Max = 18
};

// Enum LineageR.ELMRSelectControlType
enum class ELMRSelectControlType : uint8 {
	None = 0,
	MoveSelectControl = 1,
	ContinuousMoveControl = 2,
	BattleFieldControl = 3,
	PartyCommandTagControl = 4,
	BattleFieldHudControl = 5,
	IllustratedBookControl = 6,
	TargetOrbisControl = 7,
	ELMRSelectControlType_MAX = 8
};

// Enum LineageR.ELMRWidgetAnimationEvent
enum class ELMRWidgetAnimationEvent : uint8 {
	Started = 0,
	Finished = 1,
	StartedOnce = 2,
	FinishedOnce = 3,
	ELMRWidgetAnimationEvent_MAX = 4
};

// Enum LineageR.ELMRBookPageType
enum class ELMRBookPageType : uint8 {
	Full = 0,
	Vertical = 1,
	Horizontal = 2,
	ELMRBookPageType_MAX = 3
};

// Enum LineageR.ELMRBuffCardAutoScrollDirection
enum class ELMRBuffCardAutoScrollDirection : uint8 {
	Type_None = 0,
	Type_Forward = 1,
	Type_Backward = 2,
	Type_MAX = 3
};

// Enum LineageR.EBuffCardIndexDirectionType
enum class EBuffCardIndexDirectionType : uint8 {
	Type_Same = 0,
	Type_Before = 1,
	Type_Next = 2,
	Type_MAX = 3
};

// Enum LineageR.EBuffCardLoadType
enum class EBuffCardLoadType : uint8 {
	Type_None = 0,
	Type_IncludeLevelSequence = 1,
	Type_IncludeLevelSequenceAndAutoPlay = 2,
	Type_ExceptLevelSequence = 3,
	Type_MAX = 4
};

// Enum LineageR.ELMRBuffCardFxGrade
enum class ELMRBuffCardFxGrade : uint8 {
	Item_None = 0,
	Item_Grade1 = 1,
	Item_Grade2 = 2,
	Item_Grade3 = 3,
	Item_Grade4 = 4,
	Item_Grade5 = 5,
	Item_Grade6 = 6,
	MAX = 7
};

// Enum LineageR.EBuffCardSlotType
enum class EBuffCardSlotType : uint8 {
	Base = 0,
	Main = 1,
	Use = 2,
	Book = 3,
	Custom = 4,
	Collection = 5,
	EBuffCardSlotType_MAX = 6
};

// Enum LineageR.ELMRMacroEmoType
enum class ELMRMacroEmoType : uint8 {
	Invalid = 0,
	Emoticon = 1,
	MacroText = 2,
	PartyPin = 3,
	BattleFieldCommand = 4,
	ELMRMacroEmoType_MAX = 5
};

// Enum LineageR.ELMRCinemaDirectorResourceType
enum class ELMRCinemaDirectorResourceType : uint8 {
	Invalid = 0,
	WaitLoading = 1,
	LoadingComplte = 2,
	ELMRCinemaDirectorResourceType_MAX = 3
};

// Enum LineageR.ELMRCinemaDirectorStateType
enum class ELMRCinemaDirectorStateType : uint8 {
	Invalid = 0,
	Action = 1,
	Pause = 2,
	ELMRCinemaDirectorStateType_MAX = 3
};

// Enum LineageR.ELMRClanCheckConditionType
enum class ELMRClanCheckConditionType : uint8 {
	CCC_HasRequestEnterMember = 0,
	CCC_HasRequestAlliance = 1,
	CCC_MAX = 2
};

// Enum LineageR.ELMRImportanceColorType
enum class ELMRImportanceColorType : uint8 {
	ICT_Emphasis = 0,
	ICT_Assistant = 1,
	ICT_Important = 2,
	ICT_Normal = 3,
	ICT_Unimportant = 4,
	ICT_MAX = 5
};

// Enum LineageR.ELMREasingExpression
enum class ELMREasingExpression : uint8 {
	InQuad = 0,
	OutQuad = 1,
	InOutQuad = 2,
	InCubic = 3,
	OutCubic = 4,
	InOutCubic = 5,
	InQuart = 6,
	OutQuart = 7,
	InOutQuart = 8,
	InQuint = 9,
	OutQuint = 10,
	InOutQuint = 11,
	InSine = 12,
	OutSine = 13,
	InOutSine = 14,
	InExpo = 15,
	OutExpo = 16,
	InOutExpo = 17,
	InCirc = 18,
	OutCirc = 19,
	InOutCirc = 20,
	Linear = 21,
	Spring = 22,
	InBounce = 23,
	OutBounce = 24,
	InOutBounce = 25,
	InBack = 26,
	OutBack = 27,
	InOutBack = 28,
	InElastic = 29,
	OutElastic = 30,
	InOutElastic = 31,
	Count = 32,
	ELMREasingExpression_MAX = 33
};

// Enum LineageR.ELMRMultiEnchantStateType
enum class ELMRMultiEnchantStateType : uint8 {
	Idle = 0,
	Enchant = 1,
	ELMRMultiEnchantStateType_MAX = 2
};

// Enum LineageR.EManagedButtonType
enum class EManagedButtonType : uint8 {
	Accept = 0,
	Cancel = 1,
	Reject = 2,
	Party = 3,
	Whisper = 4,
	Max = 5
};

// Enum LineageR.ELMRFriendType
enum class ELMRFriendType : uint8 {
	Invalid = 0,
	Friend = 1,
	Send = 2,
	Inbox = 3,
	Watch = 4,
	ELMRFriendType_MAX = 5
};

// Enum LineageR.ELMRFriendTabIndex
enum class ELMRFriendTabIndex : uint8 {
	FTI_Friend = 0,
	FTI_Request = 1,
	FTI_Alert = 2,
	FTI_MAX = 3
};

// Enum LineageR.EDebugDrawType
enum class EDebugDrawType : uint8 {
	StateDebug = 0,
	PathDebug = 1,
	DamageEffectDebug = 2,
	DebugWidgetLog = 3,
	ActionHandler = 4,
	PathDetailDebug = 5,
	StatusEffectDebug = 6,
	LUIDDebug = 7,
	ZombieDebug = 8,
	DamageDebug = 9,
	BuffDebug = 10,
	ActionSchedulerDebug = 11,
	BossMonsterClosestHitDebug = 12,
	AutoPlaySearchTargetRange = 13,
	BGMPlayerDebug = 14,
	CameraDebug = 15,
	MDollPathDebug = 16,
	AmbientSoundDebug = 17,
	WorldBossTimeDebug = 18,
	SoundStateDebug = 19,
	UISoundDebug = 20,
	BattleFieldDebug = 21,
	TaxWagonDebug = 22,
	LocalPathDebug = 23,
	FootstepDebug = 24,
	WorldConditionDebug = 25,
	InteractiveObjectDebug = 26,
	ServerTimeDebug = 27,
	HideableStaticMeshActorDebug = 28,
	BTNameDebug = 29,
	AIPathDebug = 30,
	AITerritoryDebug = 31,
	ActorHidden = 32,
	MoveDecalHidden = 33,
	RagDollDirection = 34,
	CutsceneStateDebug = 35,
	NotFoundFloorDebug = 36,
	CutsceneCameraDebug = 37,
	AutoPlayTargetInvalidDebug = 38,
	PlayerSightDistance = 39,
	PlayerSightGridDistance = 40,
	EnchantCutsceneRate = 41,
	EnchantCutscene = 42,
	Insight = 43,
	SpellObjectDebug = 44,
	SpellDebug = 45,
	FootstepSoundDebug = 46,
	NoBlackScreenDebug = 47,
	ProjectileDebug = 48,
	CutsceneQuailityDebug = 49,
	NoCutscene = 50,
	CameraResolutionDebug = 51,
	Count = 52,
	EDebugDrawType_MAX = 53
};

// Enum LineageR.EGameModeType
enum class EGameModeType : uint8 {
	EmptyState = 0,
	LogoState = 1,
	IntroState = 2,
	LobbyState = 3,
	CharacterSelectionState = 4,
	LayoutTesterState = 5,
	MainState = 6,
	TestState = 7,
	PatchState = 8,
	EGameModeType_MAX = 9
};

// Enum LineageR.ELMRGameServiceState
enum class ELMRGameServiceState : uint8 {
	Type_Construct = 0,
	Type_Initialize = 1,
	Type_InitializeGame = 2,
	Type_Tick = 3,
	Type_ShutdownGame = 4,
	Type_Shutdown = 5,
	Type_Invalid = 6,
	Type_MAX = 7
};

// Enum LineageR.ELMRGameStateType
enum class ELMRGameStateType : uint8 {
	None = 0,
	Patch = 1,
	Intro = 2,
	Lobby = 3,
	Field = 4,
	Reconnect = 5,
	TutorialField = 6,
	ConnectInterServer = 7,
	Standalone_BuffCard = 8,
	Standalone_BuffCardMergeResult = 9,
	Standalone_BuffCardSwap = 10,
	Standalone_SpiridLocomotion = 11,
	ELMRGameStateType_MAX = 12
};

// Enum LineageR.ELMRLocalizationDataType
enum class ELMRLocalizationDataType : uint8 {
	Type_Asset = 0,
	Type_NonAsset = 1,
	Type_MAX = 2
};

// Enum LineageR.ELMRLogType
enum class ELMRLogType : uint8 {
	GameStart = 0,
	AgreeStart = 1,
	AgreeEnd = 2,
	LoginStart = 3,
	LoginEnd = 4,
	PatchStart = 5,
	PatchEnd = 6,
	NicknameStart = 7,
	NicknameEnd = 8,
	Purchase = 9,
	LevelUp = 10,
	TutorialComplete = 11,
	ELMRLogType_MAX = 12
};

// Enum LineageR.ELMRManagedWidgetStatus
enum class ELMRManagedWidgetStatus : uint8 {
	Opening = 0,
	Closing = 1,
	Opened = 2,
	Closed = 3,
	ELMRManagedWidgetStatus_MAX = 4
};

// Enum LineageR.EBackButtonBehaviorType
enum class EBackButtonBehaviorType : uint8 {
	CloseThis = 0,
	CloseAndNext = 1,
	Hold = 2,
	Skip = 3,
	EBackButtonBehaviorType_MAX = 4
};

// Enum LineageR.ELMRNPNetCode
enum class ELMRNPNetCode : uint8 {
	SB = 0,
	OP = 1,
	RC = 2,
	Live = 3,
	ELMRNPNetCode_MAX = 4
};

// Enum LineageR.EPacketErrorMessageOutputType
enum class EPacketErrorMessageOutputType : uint8 {
	Default = 0,
	SkipErrorMessage = 1,
	EPacketErrorMessageOutputType_MAX = 2
};

// Enum LineageR.EHandlePacketPriority
enum class EHandlePacketPriority : uint8 {
	Pre = 0,
	Post = 1,
	MAX = 2
};

// Enum LineageR.EClientServerType
enum class EClientServerType : uint8 {
	None = 0,
	LobbyServer = 1,
	GameServer = 2,
	EClientServerType_MAX = 3
};

// Enum LineageR.ELMRPackagingTargetType
enum class ELMRPackagingTargetType : uint8 {
	Type_None = 0,
	Type_Blueprint = 1,
	Type_Fx = 2,
	Type_Widget = 3,
	Type_Texture = 4,
	Type_Montage = 5,
	Type_DataTable = 6,
	Type_DataAsset = 7,
	Type_Sequencer = 8,
	Type_AkAudio = 9,
	Type_StaticMesh = 10,
	Type_MaterialInstance = 11,
	Type_CineMedia = 12,
	Type_MediaSource = 13,
	Type_Object = 14,
	Type_MAX = 15
};

// Enum LineageR.ELMRPartyOptionWidgetMode
enum class ELMRPartyOptionWidgetMode : uint8 {
	Invalid = 0,
	Option = 1,
	Invite = 2,
	ELMRPartyOptionWidgetMode_MAX = 3
};

// Enum LineageR.ELMRMountType
enum class ELMRMountType : uint8 {
	Type_All = 0,
	Type_Start = 1,
	Type_MAX = 2
};

// Enum LineageR.EPercentagePopupType
enum class EPercentagePopupType : uint8 {
	None = 0,
	Craft = 1,
	LuckyBag = 2,
	Socket = 3,
	EPercentagePopupType_MAX = 4
};

// Enum LineageR.EPercentageTooltipType
enum class EPercentageTooltipType : uint8 {
	PTT_None = 0,
	PTT_BuffCardMerge = 1,
	PTT_Enchant = 2,
	PTT_EnchantRestore = 3,
	PTT_MAX = 4
};

// Enum LineageR.EPortraitState
enum class EPortraitState : uint8 {
	None = 0,
	WeightPenaltyLevel2 = 1,
	FullInventory = 2,
	UnderVibrationHPRatio = 3,
	PvPKill = 4,
	EnchantSuccess = 5,
	EnchantFail = 6,
	ItemCraftGreatSuccess = 7,
	ItemCraftFail = 8,
	GetBuff = 9,
	Heal = 10,
	EPortraitState_MAX = 11
};

// Enum LineageR.ELMRQuestTrackerType
enum class ELMRQuestTrackerType : uint8 {
	Invalid = 0,
	MainQuest = 1,
	LocalQuest = 2,
	Mission = 3,
	Achievement = 4,
	Stamp = 5,
	SubContractedBounty = 6,
	WantedBounty = 7,
	WorldCondition = 8,
	ELMRQuestTrackerType_MAX = 9
};

// Enum LineageR.ELMRFilterType
enum class ELMRFilterType : uint8 {
	Invalid = 0,
	Highest = 1,
	Clan = 2,
	Friend = 3,
	ELMRFilterType_MAX = 4
};

// Enum LineageR.ELMRScreenWidgetTargetType
enum class ELMRScreenWidgetTargetType : uint8 {
	Default = 0,
	Head = 1,
	Feet = 2,
	Top = 3,
	ELMRScreenWidgetTargetType_MAX = 4
};

// Enum LineageR.ELMRHorizontalAlign
enum class ELMRHorizontalAlign : uint8 {
	Fill = 0,
	Left = 1,
	Center = 2,
	Right = 3,
	ELMRHorizontalAlign_MAX = 4
};

// Enum LineageR.ELMRVerticalAlign
enum class ELMRVerticalAlign : uint8 {
	Fill = 0,
	Top = 1,
	Center = 2,
	Bottom = 3,
	ELMRVerticalAlign_MAX = 4
};

// Enum LineageR.LMRSlotBackgroundType
enum class LMRSlotBackgroundType : uint8 {
	None = 0,
	Normal = 1,
	QuickSlot = 2,
	Paint = 3,
	Grade = 4,
	LMRSlotBackgroundType_MAX = 5
};

// Enum LineageR.ELMRNotificationAudioEventType2
enum class ELMRNotificationAudioEventType2 : uint8 {
	Voice1 = 0,
	Voice2 = 1,
	Voice3 = 2,
	Count = 3,
	ELMRNotificationAudioEventType2_MAX = 4
};

// Enum LineageR.ELMRNotificationAudioEventType1
enum class ELMRNotificationAudioEventType1 : uint8 {
	Alarm1 = 0,
	Alarm2 = 1,
	Voice1 = 2,
	Voice2 = 3,
	Count = 4,
	ELMRNotificationAudioEventType1_MAX = 5
};

// Enum LineageR.ELMRScreenEffectAudioEventType
enum class ELMRScreenEffectAudioEventType : uint8 {
	None = 0,
	Stun = 1,
	Stone = 2,
	Poison = 3,
	Blind = 4,
	LowHp = 5,
	FireFrame = 6,
	BlackAndWhite = 7,
	PotionOfCourage = 8,
	BlackAndWhiteOnOff = 9,
	BlueLight = 10,
	BlackAndWhite_2 = 11,
	BlackAndWhite_3 = 12,
	Death = 13,
	Count = 14,
	ELMRScreenEffectAudioEventType_MAX = 15
};

// Enum LineageR.ELMRTargetActionType
enum class ELMRTargetActionType : uint8 {
	None = 0,
	Loot = 1,
	Attack = 2,
	Interact = 3,
	ELMRTargetActionType_MAX = 4
};

// Enum LineageR.HeadTurnCheckType
enum class HeadTurnCheckType : uint8 {
	Pass = 0,
	Checked = 1,
	Capture = 2,
	HeadTurnCheckType_MAX = 3
};

// Enum LineageR.ELMRMannerModeType
enum class ELMRMannerModeType : uint8 {
	None = 0,
	All = 1,
	ExceptPartyAndClan = 2,
	ELMRMannerModeType_MAX = 3
};

// Enum LineageR.ELMRObjectStateType
enum class ELMRObjectStateType : uint8 {
	Idle = 0,
	Attack = 1,
	Move = 2,
	Hit = 3,
	ELMRObjectStateType_MAX = 4
};

// Enum LineageR.EObjectType
enum class EObjectType : uint8 {
	NONE = 0,
	MY_PLAYER = 1,
	OTHER_PLAYER = 2,
	MONSTER = 3,
	NPC = 4,
	CLIENT_NPC = 5,
	ITEM = 6,
	DEVSIGN = 7,
	MAGIC_DOLL = 8,
	INTERACTIVE_DOOR = 9,
	INTERACTIVE_SWITCH = 10,
	ILLUSBOOK_MODEL = 11,
	OTHER_MAGIC_DOLL = 12,
	SPELL_OBJECT = 13,
	EObjectType_MAX = 14
};

// Enum LineageR.ETabControlEventOccurType
enum class ETabControlEventOccurType : uint8 {
	ChangeValue = 0,
	Always = 1,
	ETabControlEventOccurType_MAX = 2
};

// Enum LineageR.ETargetFollowState
enum class ETargetFollowState : uint8 {
	TargetFollowStop = 0,
	TargetFollowHold = 1,
	TargetFollowMove = 2,
	TargetFollowPortal = 3,
	TargetFollowReStart = 4,
	ETargetFollowState_MAX = 5
};

// Enum LineageR.ELMRTileViewItemAlignment
enum class ELMRTileViewItemAlignment : uint8 {
	Manual = 0,
	EvenlyDistributed = 1,
	EvenlySize = 2,
	EvenlyWide = 3,
	Fill = 4,
	ELMRTileViewItemAlignment_MAX = 5
};

// Enum LineageR.ELMRClassGroupType
enum class ELMRClassGroupType : uint8 {
	Melee = 0,
	Ranged = 1,
	Magic = 2,
	ELMRClassGroupType_MAX = 3
};

// Enum LineageR.ELMRWeaponType
enum class ELMRWeaponType : uint8 {
	WeaponType_None = 0,
	WeaponType_OneHandSword = 1,
	WeaponType_Axe = 2,
	WeaponType_Bow = 3,
	WeaponType_Spear = 4,
	WeaponType_Staff = 5,
	WeaponType_Dagger = 6,
	WeaponType_LargeSword = 7,
	WeaponType_DoubleSword = 8,
	WeaponType_Claw = 9,
	WeaponType_Gauntlet = 10,
	WeaponType_ChainSword = 11,
	WeaponType_DoubleAxe = 12,
	WeaponType_SpellStaff = 13,
	WeaponType_Count = 14,
	WeaponType_MAX = 15
};

// Enum LineageR.EAlignmentTypeEnum
enum class EAlignmentTypeEnum : uint8 {
	AlignmentType_Lawful = 1,
	AlignmentType_Neutral = 2,
	AlignmentType_Chaotic = 3,
	AlignmentType_MaxLawful = 11,
	AlignmentType_MaxChaotic = 12,
	AlignmentType_MAX = 13
};

// Enum LineageR.ECharacterFeeling
enum class ECharacterFeeling : uint8 {
	Happy = 0,
	Sad = 1,
	Angry = 2,
	None = 3,
	ECharacterFeeling_MAX = 4
};

// Enum LineageR.ELMRSubMenuType
enum class ELMRSubMenuType : uint8 {
	Craft = 1,
	Exchange = 2,
	Polymorph = 3,
	MagicDoll = 4,
	IllustractedBook = 5,
	Dungeon = 6,
	Siege = 7,
	Attendance = 8,
	Ranking = 9,
	Clan = 10,
	Friend = 11,
	Memory = 12,
	Community = 13,
	PvpBook = 14,
	Mail = 15,
	Quest = 16,
	ELMRSubMenuType_MAX = 17
};

// Enum LineageR.ELMRPartyTargetType
enum class ELMRPartyTargetType : uint8 {
	PT_ForPartyLeader = 0,
	PT_ForPartyMember = 1,
	PT_MAX = 2
};

// Enum LineageR.ELMRClanMemberRankType
enum class ELMRClanMemberRankType : uint8 {
	None = 0,
	MemberRank1 = 1,
	MemberRank2 = 2,
	MemberRank3 = 3,
	MemberRank4 = 4,
	MemberRank5 = 5,
	ELMRClanMemberRankType_MAX = 6
};

// Enum LineageR.ELMRCharacterStatType
enum class ELMRCharacterStatType : uint8 {
	None = 0,
	Str = 1,
	Dex = 2,
	Int = 3,
	Con = 4,
	Wis = 5,
	Cha = 6,
	ELMRCharacterStatType_MAX = 7
};

// Enum LineageR.ELMRClassGenderType
enum class ELMRClassGenderType : uint8 {
	None = 0,
	Male = 1,
	Female = 2,
	ELMRClassGenderType_MAX = 3
};

// Enum LineageR.ELMRClassType
enum class ELMRClassType : uint8 {
	None = 0,
	Knight = 1,
	Elf = 2,
	Magician = 3,
	DarkElf = 4,
	Prince = 8,
	Common = 99,
	ELMRClassType_MAX = 100
};

// Enum LineageR.ELMRGradeType
enum class ELMRGradeType : uint8 {
	None = 0,
	Grade1 = 1,
	Grade2 = 2,
	Grade3 = 3,
	Grade4 = 4,
	Grade5 = 5,
	Grade6 = 6,
	ELMRGradeType_MAX = 7
};

// Enum LineageR.ELMRManagedWidgetTag
enum class ELMRManagedWidgetTag : uint8 {
	FullScreen = 0,
	FullScreenBlur = 1,
	VisibleClanPoint = 2,
	GameInfoInputDisable = 3,
	Hide3DUI = 4,
	IllusDetailBanner = 5,
	CommonTeleportPopup = 6,
	InfoPopup = 7,
	RightUI = 8,
	CollectionSummary = 9,
	PlayerSheet = 10,
	QuickPolymorphWrapper = 11,
	DisableKeyboardInput = 12,
	StopPlayerAction = 13,
	PowerSaveing = 14,
	OpenSubMenu = 15,
	AllInputDisable = 16,
	SetPlayerUnControllable = 17,
	LeftUI = 18,
	PersonalTradeRequest = 19,
	PersonalTrade = 20,
	DoNotCloseWhilePersonalTrading = 21,
	Chat = 22,
	RecoveryDeath = 23,
	DisableKeyMapping = 24,
	Polymorph = 25,
	OtherCurrency = 26,
	PlayerStatus = 27,
	Patch = 28,
	CardInfoPopup = 29,
	AdvanceReserve = 30,
	ELMRManagedWidgetTag_MAX = 31
};

// Enum LineageR.ELMRLayerType
enum class ELMRLayerType : uint8 {
	Invalid = 0,
	Screen = 1,
	Default = 2,
	Popup = 3,
	Top = 4,
	Guide = 5,
	PowerSavingMode = 6,
	Disconnect = 7,
	System = 8,
	LongPress = 9,
	NameTag = 10,
	TouchEffect = 11,
	MAX_COUNT = 12,
	ELMRLayerType_MAX = 13
};

// Enum LineageR.ELMRChatSubType
enum class ELMRChatSubType : uint8 {
	None = 0,
	Announce = 1,
	Tip = 2,
	Log = 3,
	Admin = 4,
	Leader = 5,
	ELMRChatSubType_MAX = 6
};

// Enum LineageR.ELMRChatType
enum class ELMRChatType : uint8 {
	None = 0,
	Normal = 1,
	World = 2,
	WorldGroup = 3,
	System = 4,
	Party = 5,
	Clan = 6,
	Whisper = 7,
	WhisperSend = 8,
	Group_2 = 9,
	Group_3 = 10,
	Group_4 = 11,
	Group_5 = 12,
	Group_6 = 13,
	ELMRChatType_MAX = 14
};

// Enum LineageR.EPlayerType
enum class EPlayerType : uint8 {
	NONE = 0,
	MY_PLAYER = 1,
	OTHER_PLAYER = 2,
	MONSTER = 3,
	NPC = 4,
	AI = 5,
	EPlayerType_MAX = 6
};

// Enum LineageR.ELMRGridZoneType
enum class ELMRGridZoneType : uint8 {
	Normal = 0,
	Safe = 1,
	Combat = 2,
	Water = 4,
	InvalidZoneType = 255,
	ELMRGridZoneType_MAX = 256
};

// Enum LineageR.ELMRGridEdgeAttr
enum class ELMRGridEdgeAttr : uint8 {
	None = 0,
	CantGo = 1,
	CantAttack = 2,
	CanAttack = 4,
	ELMRGridEdgeAttr_MAX = 5
};

// Enum LineageR.EAttributeType
enum class EAttributeType : uint8 {
	Path = 0,
	HighWall = 1,
	LowWall = 2,
	Portal = 4,
	AttackableWall = 5,
	EAttributeType_MAX = 6
};

// Enum LineageR.EActionType
enum class EActionType : uint8 {
	ACT_WALK = 0,
	ACT_ATTACK = 1,
	ACT_DAMAGE = 2,
	ACT_BREATH = 3,
	ACT_WALK_SWORD = 4,
	ACT_ATTACK_SWORD = 5,
	ACT_DAMAGE_SWORD = 6,
	ACT_BREATH_SWORD = 7,
	ACT_DEATH = 8,
	ACT_BLINK = 9,
	ACT_SPLASH = 10,
	ACT_UP_DOWN = 10,
	ACT_WALK_AXE = 11,
	ACT_ATTACK_AXE = 12,
	ACT_DAMAGE_AXE = 13,
	ACT_BREATH_AXE = 14,
	ACT_GET = 15,
	ACT_THROW = 16,
	ACT_ZAP_WAND = 17,
	ACT_SPELL_DIR = 18,
	ACT_SPELL_NODIR = 19,
	ACT_WALK_BOW = 20,
	ACT_ATTACK_BOW = 21,
	ACT_DAMAGE_BOW = 22,
	ACT_BREATH_BOW = 23,
	ACT_WALK_SPEAR = 24,
	ACT_ATTACK_SPEAR = 25,
	ACT_DAMAGE_SPEAR = 26,
	ACT_BREATH_SPEAR = 27,
	ACT_ALT_ATTACK = 30,
	ACT_ALT_SPELL_DIR = 31,
	ACT_WALK_STAFF = 40,
	ACT_ATTACK_STAFF = 41,
	ACT_DAMAGE_STAFF = 42,
	ACT_BREATH_STAFF = 43,
	ACT_MOVE_UP = 44,
	ACT_MOVE_DOWN = 45,
	ACT_WALK_DAGGER = 46,
	ACT_ATTACK_DAGGER = 47,
	ACT_DAMAGE_DAGGER = 48,
	ACT_BREATH_DAGGER = 49,
	ACT_WALK_TWO_HANDED_SWORD = 50,
	ACT_ATTACK_TWO_HANDED_SWORD = 51,
	ACT_DAMAGE_TWO_HANDED_SWORD = 52,
	ACT_BREATH_TWO_HANDED_SWORD = 53,
	ACT_WALK_TWIN_SWORD = 54,
	ACT_ATTACK_TWIN_SWORD = 55,
	ACT_DAMAGE_TWIN_SWORD = 56,
	ACT_BREATH_TWIN_SWORD = 57,
	ACT_WALK_CLAW = 58,
	ACT_ATTACK_CLAW = 59,
	ACT_DAMAGE_CLAW = 60,
	ACT_BREATH_CLAW = 61,
	ACT_WALK_THROWING_WEAPON = 62,
	ACT_ATTACK_THROWING_WEAPON = 63,
	ACT_DAMAGE_THROWING_WEAPON = 64,
	ACT_BREATH_THROWING_WEAPON = 65,
	ACT_SIT_SELF = 66,
	ACT_DUEL = 67,
	ACT_BOW = 68,
	ACT_CHEER = 69,
	ACT_SIT = 70,
	ACT_FISHING = 71,
	ACT_SPACIAL_ATTACK = 72,
	ACT_SPACIAL_ATTACK_SWORD = 73,
	ACT_SPACIAL_ATTACK_AXE = 74,
	ACT_SPACIAL_ATTACK_BOW = 75,
	ACT_SPACIAL_ATTACK_SPEAR = 76,
	ACT_SPACIAL_ATTACK_STAFF = 77,
	ACT_SPACIAL_ATTACK_DAGGER = 78,
	ACT_SPACIAL_ATTACK_TWO_HAND_SWORD = 79,
	ACT_SPACIAL_ATTACK_TWIN_SWORD = 80,
	ACT_SPACIAL_ATTACK_CLAW = 81,
	ACT_SPACIAL_ATTACK_THROWING_WEAPON = 82,
	ACT_WALK_CHAINSWORD = 83,
	ACT_ATTACK_CHAINSWORD = 84,
	ACT_DAMAGE_CHAINSWORD = 85,
	ACT_BREATH_CHAINSWORD = 86,
	ACT_SPACIAL_ATTACK_CHAIN_SWORD = 87,
	ACT_WALK_DOUBLE_AXE = 88,
	ACT_ATTACK_DOUBLE_AXE = 89,
	ACT_DAMAGE_DOUBLE_AXE = 90,
	ACT_BREATH_DOUBLE_AXE = 91,
	ACT_SPECIAL_ATTACK_DOUBLE_AXE = 92,
	ACT_EXTRA_ATTACK_DOUBLE_AXE = 93,
	ACT_EXTRA_ATTACK_AXE = 94,
	ACT_APPEAR = 95,
	ACT_DISAPPEAR = 96,
	ACT_FAIL = 97,
	ACT_THREAT = 98,
	ACT_SHRINK = 99,
	ACT_MAX = 100,
	ACT_NO_SHOW_ACTION = 119,
	ACT_DEFAULT = 120
};

// Enum LineageR.EClass
enum class EClass : uint8 {
	CL_PRINCE = 0,
	CL_KNIGHT = 1,
	CL_ELF = 2,
	CL_MAGICIAN = 3,
	CL_DARKELF = 4,
	CL_DRAGON_KNIGHT = 5,
	CL_ILLUSIONIST = 6,
	CL_WARRIOR = 7,
	CL_MAX = 8,
	CL_BANNED = 16,
	CL_DELETED = 32,
	CL_PETBALLIFING = 64,
	CL_PETBALLIFIED = 128,
	CL_PETBALLCLOSE = 192
};

// Enum LineageR.ECharacterState
enum class ECharacterState : uint8 {
	NONE = 0,
	IDLE = 1,
	SPAWN = 2,
	DEATH = 3,
	DAMAGE = 4,
	RUN = 5,
	REVIVE = 6,
	CASTING = 7,
	ABNORMAL = 8,
	PLAYING_ANY_MONTAGE = 9,
	ECharacterState_MAX = 10
};

// Enum LineageR.ELUIDType
enum class ELUIDType : uint8 {
	LUID_Type_Account = 1,
	LUID_Type_Character = 2,
	LUID_Type_Item = 3,
	LUID_Type_Clan = 4,
	LUID_Type_LandObject = 5,
	LUID_Type_Monster = 6,
	LUID_Type_TransactionKey = 10,
	LUID_Type_ClientObject = 16,
	LUID_Type_MagicDollObject = 17,
	LUID_Type_Goods = 20,
	LUID_Type_IntangibleItem = 21,
	LUID_Type_Npc = 22,
	LUID_Type_Bookmark = 23,
	LUID_Type_Party = 24,
	LUID_Type_LostExperience = 25,
	LUID_Type_DevSign = 26,
	LUID_Type_MAX = 27
};

// Enum LineageR.EObjectContainerType
enum class EObjectContainerType : uint8 {
	Begin = 0,
	Normal = 0,
	Effects = 1,
	MapObjects = 2,
	End = 3,
	EObjectContainerType_MAX = 4
};

// Enum LineageR.ELMRAccountStorageItemListContentType
enum class ELMRAccountStorageItemListContentType : uint8 {
	Common = 0,
	Detail = 1,
	AutoDepositConfig = 2,
	ELMRAccountStorageItemListContentType_MAX = 3
};

// Enum LineageR.ELMRAccountStorageContainerFilterType
enum class ELMRAccountStorageContainerFilterType : uint8 {
	All = 0,
	Equipment = 1,
	Misc = 2,
	AutoDepositConfig = 3,
	ELMRAccountStorageContainerFilterType_MAX = 4
};

// Enum LineageR.ELMRAccountStorageItemListType
enum class ELMRAccountStorageItemListType : uint8 {
	PickUpDeposit = 0,
	AutoConfig = 1,
	ELMRAccountStorageItemListType_MAX = 2
};

// Enum LineageR.ELMRAccountStorageMode
enum class ELMRAccountStorageMode : uint8 {
	None = 0,
	PickUp = 1,
	Deposit = 2,
	AutoDepositConfig = 3,
	ELMRAccountStorageMode_MAX = 4
};

// Enum LineageR.ELMRAIRepeatType
enum class ELMRAIRepeatType : uint8 {
	None = 0,
	Once = 1,
	OnceNoAchieve = 2,
	OnceDay = 3,
	OnceDayNoAchieve = 4,
	Achieve = 5,
	ELMRAIRepeatType_MAX = 6
};

// Enum LineageR.ELMRAISaveDataType
enum class ELMRAISaveDataType : uint8 {
	None = 0,
	PlayerKill = 1,
	PlayerDeathByMonster = 2,
	PlayerLevelUp = 3,
	RestoreExp = 4,
	RestoreItem = 5,
	DirectionstoSilverKnightVillage = 6,
	EnterSilverKnightVillage = 7,
	EnterCockatriceFeedlot = 8,
	DirectionsToWoodbeckVillage = 9,
	EnterWoodbeckVillage = 10,
	Mold = 11,
	AnoblemanInRecreation = 12,
	DirectionsToWizardLab = 13,
	EnterFairyForestVillage = 14,
	ChangedChaotic = 15,
	ChangedNeutral = 16,
	BrokenItem = 17,
	NoEinhasad = 18,
	LessThan200Einhasad = 19,
	LevelRankUp = 20,
	PvpRankUp = 21,
	RevisitSilverKnightVillage_2 = 22,
	RevisitSilverKnightVillage_3 = 23,
	RevisitSilverKnightVillage_4 = 24,
	RevisitWoodbeckVillage_2 = 25,
	RevisitWoodbeckVillage_3 = 26,
	RevisitWoodbeckVillage_4 = 27,
	RevisitToWizardLab_2 = 28,
	RevisitToWizardLab_3 = 29,
	RevisitToWizardLab_4 = 30,
	RevisitGludinVillage_2 = 31,
	RevisitGludinVillage_3 = 32,
	RevisitGludinVillage_4 = 33,
	RevisitTalkingIsland_2 = 34,
	RevisitTalkingIsland_3 = 35,
	RevisitTalkingIsland_4 = 36,
	EquippedErodeItem = 37,
	InventoryOverWeight = 38,
	InventoryOverWeightMsg = 39,
	IslandOfDream_Earth = 40,
	IslandOfDream_Wind = 41,
	IslandOfDream_Fire = 42,
	IslandOfDream_Water = 43,
	ELMRAISaveDataType_MAX = 44
};

// Enum LineageR.ELMRErodedWeaponState
enum class ELMRErodedWeaponState : uint8 {
	InVaild = 0,
	CharacterFirst = 1,
	AccountFirst = 2,
	NotFirst = 3,
	ELMRErodedWeaponState_MAX = 4
};

// Enum LineageR.ELMRTerrtoryFirstInState
enum class ELMRTerrtoryFirstInState : uint8 {
	InVaild = 0,
	CharacterFirst = 1,
	AccountFirst = 2,
	NotFirst = 3,
	ELMRTerrtoryFirstInState_MAX = 4
};

// Enum LineageR.ELMRAICharacterType
enum class ELMRAICharacterType : uint8 {
	Invalid = 0,
	Magicdoll = 1,
	ClientAI = 2,
	Player = 3,
	ELMRAICharacterType_MAX = 4
};

// Enum LineageR.ELMRRespawnType
enum class ELMRRespawnType : uint8 {
	Teleport = 0,
	Portal = 1,
	Distance = 2,
	Restart = 3,
	ELMRRespawnType_MAX = 4
};

// Enum LineageR.ELMRAIAlarmType
enum class ELMRAIAlarmType : uint8 {
	Invalid = 0,
	FriendAddAccept = 1,
	Attendance = 2,
	AttendanceClan = 3,
	ClanAccept = 4,
	ClanAgitRental = 5,
	ReceiveMail = 6,
	ExpireMail = 7,
	TradeSell = 8,
	TradeSellExpired = 9,
	TradeItemDivisionRegister = 10,
	TradeItemDivisionCancel = 11,
	BMShopNewGoods = 12,
	PvpBookKillUser = 13,
	PvpBookDie = 14,
	StatNew = 15,
	DungeonNewOpen = 16,
	WorldBoss = 17,
	IllustratedBookRegister = 18,
	IllustratedBookReward = 19,
	RankRefresh = 20,
	TaxCarriage = 21,
	DeleteItem = 22,
	WorldMapClanBookMark = 23,
	WorldMapPartyBookMark = 24,
	WorldMapTargetBookMark = 25,
	Polymorph = 26,
	Magicdoll = 27,
	ELMRAIAlarmType_MAX = 28
};

// Enum LineageR.ELMRAIDeathPenaltyType
enum class ELMRAIDeathPenaltyType : uint8 {
	Exp = 0,
	Item = 1,
	ELMRAIDeathPenaltyType_MAX = 2
};

// Enum LineageR.ELMRAIItemGradeType
enum class ELMRAIItemGradeType : uint8 {
	Grade_None = 0,
	Grade_Grade1 = 1,
	Grade_Grade2 = 2,
	Grade_Grade3 = 3,
	Grade_Grade4 = 4,
	Grade_Grade5 = 5,
	Grade_Grade6 = 32,
	Grade_BM = 42,
	Grade_MAX = 43
};

// Enum LineageR.ELMRAIDataStoreTextType
enum class ELMRAIDataStoreTextType : uint8 {
	Invalid = 0,
	LootItemName = 1,
	SelectedMonsterName = 2,
	FirstAcquiredBuffCardPolymorphName = 3,
	FirstAcquiredBuffCardMagicdollName = 4,
	ConsumeItemName = 5,
	PcRaceType = 6,
	SelectNpcRaceType = 7,
	ELMRAIDataStoreTextType_MAX = 8
};

// Enum LineageR.ELMRAIDataStoreType
enum class ELMRAIDataStoreType : uint8 {
	Invalid = 0,
	FirstInExploration = 1,
	LootItemInfo = 2,
	ChangedLevelInfo = 3,
	ChangedChaoticValue = 4,
	ChangedEinhasadLevel = 5,
	EinhasadPercent = 6,
	LootItemName = 7,
	SelectedMonsterName = 8,
	FirstAcquiredBuffCardPolymorph = 9,
	FirstAcquiredBuffCardMagicdoll = 10,
	ConsumeItem = 11,
	PvpInfo = 12,
	PveInfo = 13,
	PvpRevengeSuccessInfo = 14,
	PlayerTeleport = 15,
	PlayerPortal = 16,
	PlayerRestartGame = 17,
	SelectNpcRaceType = 18,
	RecognitionByNpcRace = 19,
	DeleteItem = 20,
	PlayerStat = 21,
	UseGreenPotion = 22,
	EquipmentCanBeWorn = 23,
	EquippedErodeItem = 24,
	ELMRAIDataStoreType_MAX = 25
};

// Enum LineageR.ELMRAIDialogStatusType
enum class ELMRAIDialogStatusType : uint8 {
	NONE = 0,
	ACCOUNTFIRST = 1,
	CHARACTER_FIRST = 2,
	NOT_FIRST = 3,
	ELMRAIDialogStatusType_MAX = 4
};

// Enum LineageR.ELMRAIMoveCheckType
enum class ELMRAIMoveCheckType : uint8 {
	CheckObject = 0,
	IgnoreObject = 1,
	ELMRAIMoveCheckType_MAX = 2
};

// Enum LineageR.ELMRAITarget
enum class ELMRAITarget : uint8 {
	MINE = 0,
	PLAYER = 1,
	OTHER_AI = 2,
	ELMRAITarget_MAX = 3
};

// Enum LineageR.ELMRAIQuestStatus
enum class ELMRAIQuestStatus : uint8 {
	Invalid = 0,
	BeforeStart = 1,
	Ongoing = 11,
	WaitingForReward = 98,
	Completed = 99,
	ELMRAIQuestStatus_MAX = 100
};

// Enum LineageR.ELMRAIGameClassEnum
enum class ELMRAIGameClassEnum : uint8 {
	Class_None = 0,
	Class_knight = 1,
	Class_elf = 2,
	Class_magician = 3,
	Class_darkelf = 4,
	Class_dragonknight = 5,
	Class_illusionist = 6,
	Class_warrior = 7,
	Class_prince = 8,
	Class_op_w = 17,
	Class_common = 99,
	Class_MAX = 100
};

// Enum LineageR.ELMRDollDelayType
enum class ELMRDollDelayType : uint8 {
	Invalid = 0,
	ChatDelay = 1,
	ChangedEinhasadLevel = 2,
	ELMRDollDelayType_MAX = 3
};

// Enum LineageR.ELMRAIEinhasadLevelStateType
enum class ELMRAIEinhasadLevelStateType : uint8 {
	None = 0,
	Low = 1,
	Normal = 2,
	ELMRAIEinhasadLevelStateType_MAX = 3
};

// Enum LineageR.ELMRAIHealthStateType
enum class ELMRAIHealthStateType : uint8 {
	Dead = 0,
	Low = 1,
	Medium = 2,
	High = 3,
	ELMRAIHealthStateType_MAX = 4
};

// Enum LineageR.ELMRAIMoveType
enum class ELMRAIMoveType : uint8 {
	AIM_MovetypeFollow = 0,
	AIM_MovetypeMasterForward = 1,
	AIM_MovetypeRandom = 2,
	AIM_MovetypeMax = 3,
	AIM_MAX = 4
};

// Enum LineageR.ELMRAIState
enum class ELMRAIState : uint8 {
	AI_Breath = 0,
	AI_Idle = 1,
	AI_ForceAnimation = 2,
	AI_Moving = 3,
	AI_Attacking = 4,
	AI_Action1 = 5,
	AI_Action2 = 6,
	AI_Action3 = 7,
	AI_Say = 8,
	AI_StateMax = 9,
	AI_MAX = 10
};

// Enum LineageR.EAttendanceType
enum class EAttendanceType : uint8 {
	DailyAttendance = 0,
	ContinuousAttendance = 1,
	SeasonAttendance = 2,
	ClanAttendance = 3,
	EAttendanceType_MAX = 4
};

// Enum LineageR.ELMRAttendanceRewardState
enum class ELMRAttendanceRewardState : uint8 {
	BEFORE = 0,
	ENABLE = 1,
	AFTER = 2,
	ELMRAttendanceRewardState_MAX = 3
};

// Enum LineageR.BannerType
enum class BannerType : uint8 {
	None = 0,
	LevelUp = 1,
	CardCollection = 2,
	ItemCollection = 3,
	Spell = 4,
	Item = 5,
	Quest = 6,
	IllustratedBook = 7,
	Clan = 8,
	Ranking = 9,
	WorldBoss = 10,
	WorldMap = 11,
	Prerequisite = 12,
	Enchant = 13,
	Bounty = 14,
	Favor = 15,
	CashShopPurchase = 16,
	BannerType_MAX = 17
};

// Enum LineageR.ELMRBannerIconType
enum class ELMRBannerIconType : uint8 {
	None = 0,
	LevelUp = 1,
	PolymorphCardCollection = 2,
	MagicDollCollection = 3,
	QuestMain = 4,
	QuestSub = 5,
	QuestEvent = 6,
	QuestMission = 7,
	QuestAchievement = 8,
	Mail = 9,
	ClanDonation = 10,
	IllustratedBook = 11,
	SpellLearned = 12,
	Attendance = 13,
	RankingBenefit = 14,
	ItemDrop = 15,
	WorldBoss = 16,
	WorldMapExploration = 17,
	FavorShop = 18,
	EnchantSuccess = 19,
	EnchantFail = 20,
	ItemRestore = 21,
	Bounty = 22,
	ItemCollection = 23,
	ClanInsigniaGrowthUp = 24,
	ClanGrowthUp = 25,
	SpellLearnedAbilityUp = 26,
	CashShopPurchaseResult = 27,
	ELMRBannerIconType_MAX = 28
};

// Enum LineageR.ELMRBannerType
enum class ELMRBannerType : uint8 {
	QuestStart = 0,
	QuestEnd = 1,
	TutorialStart = 2,
	TutorialEnd = 3,
	MonsterIllustratedBookUnlock = 4,
	ELMRBannerType_MAX = 5
};

// Enum LineageR.ELMRBattleFieldCommandStateType
enum class ELMRBattleFieldCommandStateType : uint8 {
	Invalid = 0,
	SelectTarget = 1,
	SelectPosition = 2,
	EditSlot = 3,
	ELMRBattleFieldCommandStateType_MAX = 4
};

// Enum LineageR.ELMRBattleFieldNameTagType
enum class ELMRBattleFieldNameTagType : uint8 {
	Myteam = 0,
	Enemy = 1,
	Alliance = 2,
	Neutral = 3,
	Npc = 4,
	Player = 5,
	Nothing = 6,
	ELMRBattleFieldNameTagType_MAX = 7
};

// Enum LineageR.ELMRBattleFieldCommandType
enum class ELMRBattleFieldCommandType : uint8 {
	Invalid = 0,
	Attack = 1,
	Stay = 2,
	Retreat = 3,
	Gather = 4,
	Attention = 5,
	Begin = 1,
	End = 5,
	Ready = 6,
	Complete = 7,
	FailOrder = 8,
	SpellTarget = 10,
	ELMRBattleFieldCommandType_MAX = 11
};

// Enum LineageR.ELMRBuffIconVisibleType
enum class ELMRBuffIconVisibleType : uint8 {
	None = 0,
	CharacterInfoOrHudVisible = 1,
	CharacterInfoOrHudExpandVisible = 2,
	CharacterInfoVisible = 3,
	DisableBuffIcon = 4,
	ELMRBuffIconVisibleType_MAX = 5
};

// Enum LineageR.ELMRBuffGageType
enum class ELMRBuffGageType : uint8 {
	Buff = 0,
	Debuff = 1,
	DisableBuff = 2,
	ELMRBuffGageType_MAX = 3
};

// Enum LineageR.ELMRBuffCardOwnerType
enum class ELMRBuffCardOwnerType : uint8 {
	Type_None = 0,
	Type_Polymorph = 1,
	Type_PolymorphSelected = 2,
	Type_Merge = 3,
	Type_MergeTarget = 4,
	Type_MergeResult = 5,
	Type_Swap = 6,
	Type_Gacha = 7,
	Type_Style = 8,
	Type_StyleSelected = 9,
	Type_MAX = 10
};

// Enum LineageR.ELMRCardCompositeCharacterType
enum class ELMRCardCompositeCharacterType : uint8 {
	Invalid = 0,
	Attacker = 1,
	Defender = 2,
	ELMRCardCompositeCharacterType_MAX = 3
};

// Enum LineageR.ELMRBuffCardGachaActorAnimState
enum class ELMRBuffCardGachaActorAnimState : uint8 {
	Idle = 0,
	Spawn = 1,
	TransformIntoBuffCard = 2,
	ChessmenHit = 3,
	ChessmenHitEnd = 4,
	Hide = 5,
	ELMRBuffCardGachaActorAnimState_MAX = 6
};

// Enum LineageR.FLMRCameraModePriority
enum class FLMRCameraModePriority : uint8 {
	Priority_Hud = 0,
	Priority_LandAttribute = 1,
	Priority_Blend = 2,
	Priority_AI = 3,
	Priority_Dialog = 4,
	Priority_Recovery = 5,
	Priority_ViewFriendlyUI = 6,
	Priority_UI = 7,
	Priority_Cutscene = 8,
	Priority_MAX = 9
};

// Enum LineageR.ELMRCameraActorType
enum class ELMRCameraActorType : uint8 {
	Type_None = 0,
	Type_Spell = 1,
	Type_DialogUI = 2,
	Type_UI = 3,
	Type_CutScene = 4,
	Type_Max = 5
};

// Enum LineageR.ELMRBlendViewTargetType
enum class ELMRBlendViewTargetType : uint8 {
	ELMRBlendViewTargetType_None = 0,
	ELMRBlendViewTargetType_Npc = 1,
	ELMRBlendViewTargetType_Monster = 2,
	ELMRBlendViewTargetType_LocalPlayer = 3,
	ELMRBlendViewTargetType_Locations = 4,
	ELMRBlendViewTargetType_UnrealCoordinate = 5,
	ELMRBlendViewTargetType_AppointedTarget = 6,
	ELMRBlendViewTargetType_ClientNpc = 7,
	ELMRBlendViewTargetType_MAX = 8
};

// Enum LineageR.ELMRChatReportReason
enum class ELMRChatReportReason : uint8 {
	None = 0,
	Obscene = 1,
	Insult = 2,
	Plaster = 3,
	Advertise = 4,
	ELMRChatReportReason_MAX = 5
};

// Enum LineageR.ELMRSTTState
enum class ELMRSTTState : uint8 {
	None = 0,
	WaitWhisperTarget = 1,
	Recording = 2,
	Recognizing = 3,
	Complete = 4,
	ELMRSTTState_MAX = 5
};

// Enum LineageR.ELMRTextTranslationState
enum class ELMRTextTranslationState : uint8 {
	Request = 0,
	Translating = 1,
	Complete = 2,
	ELMRTextTranslationState_MAX = 3
};

// Enum LineageR.ELMRUIChatOptionFilterType
enum class ELMRUIChatOptionFilterType : uint8 {
	None = 0,
	Normal = 1,
	Entire = 2,
	Whisper = 3,
	Party = 4,
	Clan = 5,
	ClanNotice = 6,
	System = 7,
	SystemNotice = 8,
	SystemTip = 9,
	SystemLog = 10,
	GroupAll = 11,
	Group_2 = 12,
	Group_3 = 13,
	Group_4 = 14,
	Group_5 = 15,
	Group_6 = 16,
	End = 17,
	ELMRUIChatOptionFilterType_MAX = 18
};

// Enum LineageR.ELMRUIChatInputFilterType
enum class ELMRUIChatInputFilterType : uint8 {
	None = 0,
	Normal = 1,
	World = 2,
	WorldGroup = 3,
	Party = 4,
	Whisper = 5,
	Clan = 6,
	System = 7,
	Group = 8,
	Group_2 = 9,
	Group_3 = 10,
	Group_4 = 11,
	Group_5 = 12,
	Group_6 = 13,
	Back = 14,
	ELMRUIChatInputFilterType_MAX = 15
};

// Enum LineageR.ELMRChatViewFilterType
enum class ELMRChatViewFilterType : uint8 {
	None = 0,
	All = 1,
	Normal = 2,
	World = 3,
	WorldGroup = 4,
	Party = 5,
	Whisper = 6,
	Clan = 7,
	System = 8,
	Group = 9,
	ELMRChatViewFilterType_MAX = 10
};

// Enum LineageR.ELMRChatCommandType
enum class ELMRChatCommandType : uint8 {
	None = 0,
	SelectChatChannel = 1,
	PartyInvite = 2,
	PartyLeave = 3,
	PartyKick = 4,
	PartyCreate = 5,
	ELMRChatCommandType_MAX = 6
};

// Enum LineageR.ELMRCinemaWidgetType
enum class ELMRCinemaWidgetType : uint8 {
	Invalid = 0,
	EnchantSkip = 1,
	EnchantResult = 2,
	EnchantExit = 3,
	EnchantBack = 4,
	CardCompositeSkip = 5,
	ELMRCinemaWidgetType_MAX = 6
};

// Enum LineageR.ELMRInnStateType
enum class ELMRInnStateType : uint8 {
	Lobby = 0,
	RentAgit = 1,
	Entrace = 2,
	ChangeContract = 3,
	ELMRInnStateType_MAX = 4
};

// Enum LineageR.ELMRClanMasteryProceedType
enum class ELMRClanMasteryProceedType : uint8 {
	Normal = 0,
	Proceeding = 1,
	Complete = 2,
	ELMRClanMasteryProceedType_MAX = 3
};

// Enum LineageR.ELMRClanMasteryType
enum class ELMRClanMasteryType : uint8 {
	None = 0,
	ClanGrowth = 1,
	InsigniaGrowth_Select = 2,
	InsigniaGrowth_Offensive = 3,
	InsigniaGrowth_Defensive = 4,
	InsigniaGrowth_Experience = 5,
	ELMRClanMasteryType_MAX = 6
};

// Enum LineageR.ELMRClanDiplomacyType
enum class ELMRClanDiplomacyType : uint8 {
	None = 0,
	Enemy = 1,
	Alliance = 2,
	Same = 3,
	Other = 4,
	ELMRClanDiplomacyType_MAX = 5
};

// Enum LineageR.ContextMenuIconType
enum class ContextMenuIconType : uint8 {
	Friend_Add = 0,
	Friend_Remove = 1,
	Party_Invite = 2,
	Whisper = 3,
	Mail = 4,
	ClanInfo = 5,
	ActivityFigure = 6,
	PlayLog = 7,
	Authority = 8,
	KickOut = 9,
	Report = 10,
	Block = 11,
	UnBlock = 12,
	Authority_Add = 13,
	Friend_Req_Confirm = 14,
	Watch = 15,
	ContextMenuIconType_MAX = 16
};

// Enum LineageR.ContextMenuType
enum class ContextMenuType : uint8 {
	Friend = 0,
	Party = 1,
	Whisper = 2,
	Mail = 3,
	ClanInfo = 4,
	ActivityFigure = 5,
	PlayLog = 6,
	Authority = 7,
	KickOut = 8,
	Report = 9,
	BlockChat = 10,
	ChatGroupKick = 11,
	ChatGroupStaff = 12,
	UnionAuthority = 13,
	UnionKickOut = 14,
	FriendRequest_Confirm = 15,
	FriendRequest_Reject = 16,
	Watch = 17,
	Max = 18
};

// Enum LineageR.ELMRClientNpcSpawnType
enum class ELMRClientNpcSpawnType : uint8 {
	ClientNpcSpawnType_Fixed = 0,
	ClientNpcSpawnType_PlayerNearby = 1,
	ClientNpcSpawnType_AI = 2,
	ClientNpcSpawnType_None = 3,
	ClientNpcSpawnType_MAX = 4
};

// Enum LineageR.ELMRCheckDistanceToCharType
enum class ELMRCheckDistanceToCharType : uint8 {
	CharType_None = 0,
	CharType_NPC = 1,
	CharType_EarthObject = 2,
	CharType_MAX = 3
};

// Enum LineageR.ELMRPatchRootFolderType
enum class ELMRPatchRootFolderType : uint8 {
	Type_None = 0,
	Type_ContentDownloadDir = 1,
	Type_MAX = 2
};

// Enum LineageR.ELMRAssetCategory
enum class ELMRAssetCategory : uint8 {
	Type_None = 0,
	Type_All_Base = 1,
	Type_Android = 2,
	Type_IOS = 3,
	Type_Purple_Full = 4,
	Type_Purple_Install = 5,
	Type_Window_Test = 6,
	Type_MAX = 7
};

// Enum LineageR.ELMRPrimaryAssetType
enum class ELMRPrimaryAssetType : uint8 {
	Type_None = 0,
	Type_Map = 1,
	Type_AssetLabel = 2,
	Type_GlobalAsyncAssets_DataTable = 3,
	Type_GlobalAsyncAssets_DataAsset = 4,
	Type_LobbySyncAssets_LevelSequence = 5,
	Type_UI = 6,
	Type_MAX = 7
};

// Enum LineageR.ELMRControlType
enum class ELMRControlType : uint8 {
	None = 0,
	MoveUp = 1,
	MoveLeft = 2,
	MoveRight = 3,
	MoveDown = 4,
	Immobilize = 5,
	CameraZoomIn = 6,
	CameraZoomOut = 7,
	CameraPromotionZoomIn = 8,
	CameraPromotionZoomOut = 9,
	CameraPromotionMoveUp = 10,
	CameraPromotionMoveDown = 11,
	CameraPromotionMoveLeft = 12,
	CameraPromotionMoveRight = 13,
	CameraPromotionRotationLeft = 14,
	CameraPromotionRotationRight = 15,
	Attack = 16,
	AutoBattle = 17,
	Counterattack = 18,
	Interaction = 19,
	PartyAssist = 20,
	Target = 21,
	DragTargeting = 22,
	OrbisTargeting = 23,
	NameTagChange = 24,
	TargetList1 = 25,
	TargetList2 = 26,
	TargetList3 = 27,
	TargetList4 = 28,
	TargetList5 = 29,
	TargetList6 = 30,
	PartyTarget1 = 31,
	PartyTarget2 = 32,
	PartyTarget3 = 33,
	AssistSpellPartyTarget1 = 34,
	AssistSpellPartyTarget2 = 35,
	AssistSpellPartyTarget3 = 36,
	AssistSpellTarget = 37,
	PartyCmdAttack = 38,
	PartyCmdRetreat = 39,
	PartyCmdDefense = 40,
	PartyCmdCaution = 41,
	CommandModeAttack = 42,
	CommandModeDefense = 43,
	CommandModeAssemble = 44,
	CommandModeCaution = 45,
	Chat = 46,
	MemoryPopUp = 47,
	RegisterMemory = 48,
	RightQuickSlot1 = 49,
	RightQuickSlot2 = 50,
	RightQuickSlot3 = 51,
	RightQuickSlot4 = 52,
	RightQuickSlot1AutoUse = 53,
	RightQuickSlot2AutoUse = 54,
	RightQuickSlot3AutoUse = 55,
	RightQuickSlot4AutoUse = 56,
	LeftQuickSlot1 = 57,
	LeftQuickSlot2 = 58,
	LeftQuickSlot3 = 59,
	LeftQuickSlot4 = 60,
	LeftQuickSlot1AutoUse = 61,
	LeftQuickSlot2AutoUse = 62,
	LeftQuickSlot3AutoUse = 63,
	LeftQuickSlot4AutoUse = 64,
	RightQuickSlotPageUp = 65,
	RightQuickSlotPageDown = 66,
	LeftQuickSlotPageUp = 67,
	LeftQuickSlotPageDown = 68,
	QuickSlotExpand = 69,
	QuickSlotHide = 70,
	HudTrackerUpDown = 71,
	QuestConversationNext = 72,
	QuestConversationSkip = 73,
	QuickSettings = 74,
	Inventory = 75,
	Spell = 76,
	Character = 77,
	BmShop = 78,
	Alarm = 79,
	BuffCard = 80,
	MagicDoll = 81,
	IllustratedBook = 82,
	Attendance = 83,
	Quest = 84,
	Craft = 85,
	TradeMarket = 86,
	Clan = 87,
	Friend = 88,
	PvpBook = 89,
	Community = 90,
	Mail = 91,
	Rank = 92,
	CastleManage = 93,
	Settings = 94,
	WorldMap = 95,
	ChangeCameraMode = 96,
	Max = 97
};

// Enum LineageR.ELMRMappingType
enum class ELMRMappingType : uint8 {
	Action = 0,
	Axis = 1,
	Speech = 2,
	ELMRMappingType_MAX = 3
};

// Enum LineageR.ELMRKeyMappingSubcategory
enum class ELMRKeyMappingSubcategory : uint8 {
	Movement = 0,
	Camera = 1,
	Battle = 2,
	Targeting = 3,
	PartyOperation = 4,
	Etc = 5,
	RightQuickSlot = 6,
	LeftQuickSlot = 7,
	QuickSlotPageUpDown = 8,
	Convenience = 9,
	Menu = 10,
	Max = 11
};

// Enum LineageR.ELMRKeyMappingCategory
enum class ELMRKeyMappingCategory : uint8 {
	Basic = 0,
	QuickSlot = 1,
	Convenience = 2,
	Menu = 3,
	Siege = 4,
	Max = 5
};

// Enum LineageR.ELMRKeyMappingItemType
enum class ELMRKeyMappingItemType : uint8 {
	Subcategory = 0,
	KeyMapping = 1,
	Line = 2,
	ELMRKeyMappingItemType_MAX = 3
};

// Enum LineageR.EIllusProgressState
enum class EIllusProgressState : uint8 {
	EIllusProgressState_NotGoAhead = 0,
	EIllusProgressState_Proceeding = 1,
	EIllusProgressState_Completed = 2,
	EIllusProgressState_Rewarded = 3,
	EIllusProgressState_MAX = 4
};

// Enum LineageR.EDynamicTransformType
enum class EDynamicTransformType : uint8 {
	None = 0,
	Start = 1,
	Playing = 2,
	End = 3,
	EDynamicTransformType_MAX = 4
};

// Enum LineageR.ELMRCutsceneType
enum class ELMRCutsceneType : uint8 {
	None = 0,
	Cinema = 1,
	Preview = 2,
	ELMRCutsceneType_MAX = 3
};

// Enum LineageR.ELMRDevSignStatus
enum class ELMRDevSignStatus : uint8 {
	EDSS_Open = 0,
	EDSS_InProgress = 1,
	EDSS_Review = 2,
	EDSS_Complete = 3,
	EDSS_MAX = 4
};

// Enum LineageR.ELMRDevSignCategory
enum class ELMRDevSignCategory : uint8 {
	EDSC_Invalid = 0,
	EDSC_Concept_B = 1,
	EDSC_Concept_C = 2,
	EDSC_BG = 3,
	EDSC_Character = 4,
	EDSC_FX = 5,
	EDSC_UI = 6,
	EDSC_TA = 7,
	EDSC_Animation = 8,
	EDSC_Client = 20,
	EDSC_Server = 21,
	EDSC_Design_C = 30,
	EDSC_Design_S = 31,
	EDSC_Sound = 40,
	EDSC_Memo = 99,
	EDSC_MAX = 100
};

// Enum LineageR.ELMRFXReleaseOptionType
enum class ELMRFXReleaseOptionType : uint8 {
	Invalid = 0,
	Deactivate = 1,
	Kill = 2,
	ELMRFXReleaseOptionType_MAX = 3
};

// Enum LineageR.ELMRFXSoundType
enum class ELMRFXSoundType : uint8 {
	Invalid = 0,
	User1P = 1,
	User3P = 2,
	NPCMonster = 3,
	BOSS = 4,
	ELMRFXSoundType_MAX = 5
};

// Enum LineageR.ELMREnchantSlotType
enum class ELMREnchantSlotType : uint8 {
	Invalid = 0,
	Safe = 1,
	NotSafe = 2,
	Selected = 3,
	ELMREnchantSlotType_MAX = 4
};

// Enum LineageR.ELMREnchantObjecType
enum class ELMREnchantObjecType : uint8 {
	Invalid = 0,
	Scroll = 1,
	Touch = 2,
	Target = 3,
	Camera = 4,
	MaxCount = 4,
	ELMREnchantObjecType_MAX = 5
};

// Enum LineageR.ELMRTimeOfDayType
enum class ELMRTimeOfDayType : uint8 {
	Invalid = 0,
	Day = 1,
	Night = 2,
	AllDay = 3,
	ELMRTimeOfDayType_MAX = 4
};

// Enum LineageR.ELMRPostProcessEffectVolumeType
enum class ELMRPostProcessEffectVolumeType : uint8 {
	SandStorm = 0,
	Poision = 1,
	UnderWater = 2,
	ELMRPostProcessEffectVolumeType_MAX = 3
};

// Enum LineageR.ELMRPostProcessEffectTriggerType
enum class ELMRPostProcessEffectTriggerType : uint8 {
	StatusEffect = 0,
	Weather = 1,
	TriggerVolume = 2,
	Count = 3,
	ELMRPostProcessEffectTriggerType_MAX = 4
};

// Enum LineageR.ELMRPostProcessEffectType
enum class ELMRPostProcessEffectType : uint8 {
	SandStorm = 0,
	Poision = 1,
	UnderWater = 2,
	Frost = 3,
	Burn = 4,
	FireFrame = 5,
	BlackAndWhite = 6,
	PotionOfCourage = 7,
	BlackAndWhiteOnOff = 8,
	BlueLight = 9,
	BlackAndWhite_2 = 10,
	BlackAndWhite_3 = 11,
	Count = 12,
	ELMRPostProcessEffectType_MAX = 13
};

// Enum LineageR.ELMRWeatherType
enum class ELMRWeatherType : uint8 {
	None = 0,
	Sunny = 1,
	Rain = 2,
	Snow = 3,
	HeavyRain = 4,
	HeavySnow = 5,
	SandStorm = 6,
	ELMRWeatherType_MAX = 7
};

// Enum LineageR.ELMRNameTagViewType
enum class ELMRNameTagViewType : uint8 {
	Detail = 0,
	Default = 1,
	ELMRNameTagViewType_MAX = 2
};

// Enum LineageR.ELMRLetterType
enum class ELMRLetterType : uint8 {
	None = 0,
	Number = 1,
	English = 2,
	Korean = 3,
	Latin = 4,
	Hiragana = 5,
	Katakana = 6,
	KatakanaHalfWidth = 7,
	Chinese = 8,
	Cyrillic = 9,
	Arabic = 10,
	Thai = 11,
	ELMRLetterType_MAX = 12
};

// Enum LineageR.ELMRLanguageType
enum class ELMRLanguageType : uint8 {
	None = 0,
	Korean = 1,
	English = 2,
	Japanese = 3,
	Vietnam = 5,
	Russian = 6,
	Thai = 7,
	Indonesian = 8,
	Taiwanese = 21,
	Arabic = 22,
	ELMRLanguageType_MAX = 23
};

// Enum LineageR.ELMRAutoBuffType
enum class ELMRAutoBuffType : uint8 {
	OffInSafetyZone = 0,
	Always = 1,
	MotionDetectInSafetyZone = 2,
	ELMRAutoBuffType_MAX = 3
};

// Enum LineageR.ELMRGameOptionType
enum class ELMRGameOptionType : int32 {
	None = 0,
	AllQuality = 1,
	ShadowQuality = 2,
	PostProcessQuality = 3,
	MaterialQuality = 4,
	TextureQuality = 5,
	FoliageQuality = 6,
	EffectQuality = 7,
	ViewDistanceQuality = 8,
	MeleeAttackAlignment = 9,
	HitImpactAnimNotify = 10,
	HighPerformanceSpec = 11,
	HighQualityTraceHit = 12,
	ShowSpeechBubble = 13,
	BloodHitEffect = 15,
	AttackerGuideEffect = 16,
	SpellActionCameraChange = 17,
	DeadActionRagDoll = 18,
	HeadTurnAction = 19,
	PlayerEffectNoOptimization = 20,
	PartyOrClanEffectNoOptimization = 21,
	GammaEnable = 50,
	Gamma = 51,
	ResolutionQuality = 52,
	FPS = 53,
	AnimationLOD = 54,
	QuestFilterOptionComplete = 202,
	BountyFilterOptionGather = 210,
	BountyFilterOptionStamp = 211,
	BountyFilterOptionWanted = 212,
	SoundPreset = 300,
	SoundEffectEnabled = 301,
	SoundEffectVolume = 302,
	SoundNotiEnabled = 309,
	SoundNotiVolume = 310,
	SoundBgmEnabled = 311,
	SoundBgmVolume = 312,
	SoundAmbienceEnabled = 313,
	SoundAmbienceVolume = 314,
	SoundMasterEnabled = 315,
	SoundMasterVolume = 316,
	SoundUIEnabled = 317,
	SoundUIVolume = 318,
	SoundDialogEnabled = 319,
	SoundDialogVolume = 320,
	SoundDetail = 321,
	SoundMyVolume = 322,
	SoundOtherPCVolume = 323,
	SoundMonsterVolume = 324,
	SoundBattleEQ = 326,
	SoundDynamicRange = 327,
	SoundBattleAutoVolumeEnabled = 328,
	BattleLogDeath = 401,
	BattleLogChainSpell = 402,
	CameraControlEnable = 501,
	TargetLineMode = 502,
	TouchMoveControlEnable = 601,
	AutoItemLooting = 603,
	ImmediateTargetMode = 604,
	orbisSize = 605,
	CancelAttackButton = 606,
	EnableOrbisTargeting = 607,
	EnableDirectionTargeting = 608,
	UIScale = 700,
	Anonymous = 801,
	BossNoti = 802,
	Push_DayTime = 811,
	Push_NightTime = 812,
	OnlineNoti_Friend = 821,
	OnlineNoti_Watch = 822,
	OnlineNoti_ClanMember = 823,
	Language = 901,
	AudioCulture = 910,
	TimeStampType = 920,
	ChatFilterPanelVisible = 950,
	ChatAutoTranslate = 951,
	ChatShowTimeStamp = 952,
	MinimapMode = 1001,
	MinimapOpacityEnable = 1002,
	MinimapOpacity = 1003,
	MinimapSize = 1004,
	InteractiveObjectFxEnable = 2001,
	AutoPowerSavingMode = 3001,
	CameraJoystickSensitivity = 10001,
	KeepTargetSelection = 10003,
	ShowOptionalInfoButton = 10004,
	WorldMapChangingDirecting = 10005,
	ShowMoveArrowDecal = 10006,
	TargetOrbisPC = 10101,
	TargetOrbisMonster = 10102,
	TargetOrbisEtc = 10103,
	EnableVirtualPad = 10203,
	KeepVitualPadMoveTime = 10204,
	TargetOrbisAttackerPC = 11002,
	TargetOrbisWatchPC = 11003,
	TargetOrbisEnemyClanPC = 11004,
	TargetOrbisPartyPC = 11005,
	TargetOrbisMyClanPC = 11006,
	TargetOrbisAllianceClanPC = 11007,
	TargetOrbisAllForPC = 11008,
	TargetOrbisAttackerMonster = 11009,
	TargetOrbisQuestMonster = 11010,
	TargetOrbisFirstAttackMonster = 11011,
	TargetOrbisAllMonster = 11012,
	TargetOrbisItem = 11013,
	TargetOrbisQuestTarget = 11014,
	TargetOrbisStore = 11015,
	TargetOrbisPortal = 11016,
	SingleTargetAttackerPC = 11300,
	SingleTargetWatchPC = 11301,
	SingleTargetEnemyClanPC = 11302,
	SingleTargetAttackerMonster = 11303,
	SingleTargetQuestMonster = 11304,
	SingleTargetFirstAttackMonster = 11305,
	SingleTargetAllMonster = 11306,
	SingleTargetPC = 11307,
	SingleTargetMonster = 11308,
	MagicDollPartsOption_NONE = 12000,
	AutoHunt_SEARCH_RANGE = 12001,
	AutoHunt_MANNER_MODE = 12002,
	AutoHunt_Priority = 12100,
	AutoHunt_Priority_ATTACKING_NPC = 12101,
	AutoHunt_Priority_QUEST_NPC = 12102,
	AutoHunt_Priority_AGGRESSIVE_NPC = 12103,
	ItemLoot_WEIGHT = 12201,
	ItemLoot_FIRST = 12202,
	ItemLoot_EQUIP = 12203,
	ItemLoot_ETC = 12210,
	ItemLoot_ETC_CONSUME = 12211,
	ItemLoot_ETC_SCROLL = 12212,
	ItemLoot_ETC_OTHER = 12213,
	ItemLoot_ETC_MATERIAL = 12214,
	AutoUse_ENABLE_HP_POTION_CONSUME = 12301,
	AutoUse_HP_POTION_CONSUME_PERCENT = 12302,
	AutoUse_ENABLE_HP_POTION_100PERCENT_PVP = 12303,
	AutoUse_HP_POTION_CONSUME_SELECT = 12304,
	AutoUse_ENABLE_MP_LIMIT = 12311,
	AutoUse_MP_LIMIT_PERCENT = 12312,
	AutoUse_ENABLE_BUFF_SPELL_IGNORE_MP_LIMIT = 12313,
	AutoUse_ENABLE_ALWAYS_AUTO_USE_BUFF_SPELL = 12314,
	NotiBattle_PVPAttacked_SoundEnable = 13001,
	NotiBattle_PVPAttacked_SoundType = 13002,
	NotiBattle_PVPAttacked_Vibration = 13003,
	NotiBattle_PVPAttacked_Frequency = 13004,
	NotiBattle_HPPotion_SoundEnable = 13101,
	NotiBattle_HPPotion_SoundType = 13102,
	NotiBattle_HPPotion_Vibration = 13103,
	NotiBattle_HPPotion_Condition = 13104,
	NotiBattle_HPPotion_Frequency = 13105,
	NotiBattle_HPWarning_SoundEnable = 13201,
	NotiBattle_HPWarning_SoundType = 13202,
	NotiBattle_HPWarning_Vibration = 13203,
	NotiBattle_HPWarning_Condition = 13204,
	NotiBattle_HPWarning_Frequency = 13205,
	NotiBattle_OverWeight_SoundEnable = 13301,
	NotiBattle_OverWeight_SoundType = 13302,
	NotiBattle_OverWeight_Vibration = 13303,
	NotiBattle_OverWeight_Condition = 13304,
	NotiBattle_OverWeight_Frequency = 13305,
	NotiBattle_PVPKnA_SoundEnable = 13401,
	NotiBattle_PVPKnA_SoundType = 13402,
	NotiBattle_PVPKnA_Vibration = 13403,
	Hide_PlayerInfo = 13500,
	PartyInvite_Off = 13501,
	PersonalTradeEnable = 13502,
	Naming_Display_Rule = 13600,
	Naming_Display_Rule_Enemy = 13601,
	Naming_Display_Rule_Ally = 13602,
	Naming_Display_Rule_Ect = 13603,
	Naming_Display_Rule_Enable_Fast_Change = 13604,
	CameraShake = 13700,
	KeyConfig = 20001,
	ELMRGameOptionType_MAX = 20002
};

// Enum LineageR.ELMRGameOptionMainTabType
enum class ELMRGameOptionMainTabType : uint8 {
	Control = 0,
	Infomation = 1,
	Notice = 2,
	Environment = 3,
	LanguageAndTime = 4,
	Account = 5,
	ELMRGameOptionMainTabType_MAX = 6
};

// Enum LineageR.ELMRInventorySoundType
enum class ELMRInventorySoundType : uint8 {
	NONE = 0,
	SELECT = 1,
	MOVE = 2,
	USE = 3,
	EQUIP = 4,
	UNEQUIP = 5,
	ELMRInventorySoundType_MAX = 6
};

// Enum LineageR.EItemCategory
enum class EItemCategory : uint8 {
	None = 0,
	Weapon = 1,
	Armor = 2,
	Potion = 3,
	Scroll = 4,
	ScrollTeleport = 5,
	ScrollIdentify = 6,
	Arrow = 8,
	StackableItem = 10,
	CoreMagicDollParts = 11,
	SpellBook = 17,
	Accessory = 43,
	ScrollEnchant = 52,
	LuckyBag = 78,
	EinasadRecharager = 79,
	Whetstone = 82,
	BuffCardDrawer = 83,
	IntangibleItemRecharger = 84,
	ScrollTradeUnlock = 85,
	BonusStatRecharger = 87,
	SlotIncreaseItem = 88,
	StatInitializerMeterial = 89,
	SummonStick = 90,
	Resurrection = 111,
	GrangKainCoin = 121,
	Currency = 122,
	ScrollBless = 151,
	ConpriceOfEinasad = 161,
	LinMarketProduct = 171,
	DungeonTicketRecharger = 181,
	LandTimeRecharger = 182,
	Crown = 183,
	TeleportAmulet = 192,
	ChallengePotion = 200,
	Stick = 203,
	ScrollSpell = 213,
	Sting = 223,
	SocketStone = 224,
	FishingSet = 225,
	ForSmithingItem = 226,
	Dissolution = 227,
	EItemCategory_MAX = 228
};

// Enum LineageR.EItemWeaponType
enum class EItemWeaponType : uint8 {
	None = 0,
	OneHandSword = 1,
	Axe = 2,
	Bow = 3,
	Spear = 4,
	Staff = 5,
	Dagger = 6,
	LargeSword = 7,
	DoubleSword = 8,
	Claw = 9,
	Gauntlet = 10,
	ChainSword = 11,
	DoubleAxe = 12,
	SpellStaff = 13,
	EItemWeaponType_MAX = 14
};

// Enum LineageR.EItemMaterial
enum class EItemMaterial : uint8 {
	None = 0,
	Liquid = 1,
	Wax = 2,
	Vegetable = 3,
	Meat = 4,
	Paper = 5,
	Cloth = 6,
	Leather = 7,
	Wood = 8,
	Bone = 9,
	DragonScale = 10,
	Iron = 11,
	Metal = 12,
	Copper = 13,
	Silver = 14,
	Gold = 15,
	Platinum = 16,
	Mithril = 17,
	Plastic = 18,
	Glass = 19,
	Gemstone = 20,
	Mineral = 21,
	Oriharukon = 22,
	BlackMithril = 27,
	Ore = 41,
	Gold_3 = 62,
	EItemMaterial_MAX = 63
};

// Enum LineageR.EEquipSlotTypeForSound
enum class EEquipSlotTypeForSound : int32 {
	None = -1,
	Head = 0,
	Torso = 1,
	Shirt = 2,
	Cloak = 3,
	Leg = 4,
	Foot = 5,
	Hand = 6,
	Weapon = 7,
	Finger = 8,
	Neck = 10,
	Waist = 11,
	Ear = 12,
	Shield = 13,
	Rune = 14,
	Quiver = 15,
	Badge = 16,
	ClanBadge = 17,
	MAX = 18
};

// Enum LineageR.EEquipSlotType
enum class EEquipSlotType : uint8 {
	EEST_Head = 0,
	EEST_Torso = 1,
	EEST_Shirt = 2,
	EEST_Cloak = 3,
	EEST_Leg = 4,
	EEST_Foot = 5,
	EEST_Hand = 6,
	EEST_WeaponHold = 7,
	EEST_Finger_1 = 8,
	EEST_Finger_2 = 9,
	EEST_Neck = 10,
	EEST_Waist = 11,
	EEST_Ear = 12,
	EEST_ShieldHold = 13,
	EEST_Rune = 14,
	EEST_Quiver = 15,
	EEST_Badge = 16,
	EEST_ClanBadge = 17,
	EEST_MAX = 18
};

// Enum LineageR.ELMRItemCollectionSubCategory
enum class ELMRItemCollectionSubCategory : uint8 {
	All = 0,
	Nomal = 1,
	High = 2,
	Rare = 3,
	Hero = 4,
	Max = 5
};

// Enum LineageR.ELMRItemInfoTabType
enum class ELMRItemInfoTabType : uint8 {
	Craft = 0,
	Favor = 1,
	Smithy = 2,
	Monster = 3,
	BM_Shop = 4,
	ELMRItemInfoTabType_MAX = 5
};

// Enum LineageR.EItemTradeSearchSortOrderType
enum class EItemTradeSearchSortOrderType : uint8 {
	ASC = 0,
	DESC = 1,
	EItemTradeSearchSortOrderType_MAX = 2
};

// Enum LineageR.EItemTradeSearchSortType
enum class EItemTradeSearchSortType : uint8 {
	SalePrice = 0,
	EffectiveTo = 1,
	EItemTradeSearchSortType_MAX = 2
};

// Enum LineageR.EItemTradeSearchConditionType
enum class EItemTradeSearchConditionType : uint8 {
	EnchantLevel = 0,
	BlessCode = 1,
	EItemTradeSearchConditionType_MAX = 2
};

// Enum LineageR.ELMRServerComplexityColor
enum class ELMRServerComplexityColor : uint8 {
	None = 0,
	Good = 1,
	Normal = 2,
	Bad = 3,
	Underconstruct = 4,
	ELMRServerComplexityColor_MAX = 5
};

// Enum LineageR.ELobbyUIState
enum class ELobbyUIState : uint8 {
	None = 0,
	TitleIntro = 1,
	TitleMenu = 2,
	SelectServer = 3,
	SelectCharacter = 4,
	CreateCharacter = 5,
	CreatingSelectedCharacter = 6,
	FindWholeCharacter = 7,
	RequestCharacterSelect = 8,
	ClassCreateToServerSelect = 9,
	CharacterInfoToCharacterCreate = 10,
	SelectCharacterToServerSelect = 11,
	DisconnectServer = 12,
	CharacterSelectToCharacterCreate = 13,
	CharacterCreateToCharacterSelect = 14,
	EnterIngame = 15,
	CharacterInfoToCharacterSelect = 16,
	ChangeCover = 17,
	ELobbyUIState_MAX = 18
};

// Enum LineageR.SPIN_PHASE
enum class SPIN_PHASE : uint8 {
	SPIN_PHASE_START = 0,
	SPIN_PHASE_SLOW = 1,
	SPIN_PHASE_ENDING_CYCLE = 2,
	SPIN_PHASE_UPGRADE = 3,
	SPIN_PHASE_GET_ITEM = 4,
	SPIN_PHASE_MAX = 5
};

// Enum LineageR.ELMRMailListType
enum class ELMRMailListType : uint8 {
	RecvSystemMail = 0,
	RecvUserMail = 1,
	RecvClanMail = 2,
	SentUserMail = 3,
	SentClanMail = 4,
	RecvShopFavorMail = 5,
	Max = 6
};

// Enum LineageR.ELMRObjectMaterialSwapType
enum class ELMRObjectMaterialSwapType : uint8 {
	Invalid = 0,
	Dissolve = 1,
	EnterPortal = 2,
	ConditionalObjectDissolve = 3,
	ConditionalObjectSculpt = 4,
	ConditionalObjectDecay = 5,
	PolymorphDissolve = 6,
	Phase = 7,
	Dynamic = 8,
	ELMRObjectMaterialSwapType_MAX = 9
};

// Enum LineageR.ELMRPartyCommandTagType
enum class ELMRPartyCommandTagType : uint8 {
	Invalid = 0,
	Attack = 1,
	Retreat = 2,
	Stay = 3,
	Attention = 4,
	ELMRPartyCommandTagType_MAX = 5
};

// Enum LineageR.ELMRPatchProcessType
enum class ELMRPatchProcessType : uint8 {
	Type_None = 0,
	Type_Web = 1,
	Type_NcUpdater = 2,
	Type_MAX = 3
};

// Enum LineageR.ELMRAuthProviderCode
enum class ELMRAuthProviderCode : uint8 {
	Purple = 0,
	Guest = 1,
	PlayNc = 2,
	Google = 3,
	Facebook = 4,
	Apple = 5,
	Twitter = 6,
	Line = 7,
	Appleid = 8,
	PSN = 9,
	NPEmail = 10,
	NPPhone = 11,
	VK = 12,
	NCJ = 13,
	NCT = 14,
	DEV = 201,
	DEV_PreLogin = 202,
	ShowLogin = 203,
	None = 255,
	ELMRAuthProviderCode_MAX = 256
};

// Enum LineageR.ELMRPriorityTaskType
enum class ELMRPriorityTaskType : uint8 {
	CloseAllWidget = 0,
	Media = 1,
	Cutscene = 2,
	CinemaMedia = 3,
	Banner = 4,
	Dialog = 5,
	FullPageGuide = 6,
	MiniPortrait = 7,
	UIControl = 8,
	UIGuideOpen = 9,
	UIGuideAction = 10,
	UIState = 11,
	QuestStartPopup = 12,
	PlayEffect = 13,
	PlayEffectAtLocation = 14,
	PlayAnimation = 15,
	StopAnimation = 16,
	CameraBlend = 17,
	CameraBlendToLocalPlayer = 18,
	DisableInput = 19,
	EnableInput = 20,
	FullScreenFade = 21,
	UpdateQuestSequence = 22,
	WaitForSecond = 23,
	AddSystemMessage = 24,
	ChangeViewTarget = 25,
	OpenStat = 26,
	DialogBannerCenter = 27,
	DialogBannerSide = 28,
	MagicDollSpeechBubble = 29,
	BlackScreen = 30,
	SelectGender = 31,
	PostLevelUp = 32,
	InteractiveGuideOrbis = 33,
	InteractiveGuideQuestTracker = 34,
	ELMRPriorityTaskType_MAX = 35
};

// Enum LineageR.ELMRAdditionalCurrency
enum class ELMRAdditionalCurrency : uint8 {
	Invalid = 0,
	Adena = 1,
	Gem = 4,
	ELMRAdditionalCurrency_MAX = 5
};

// Enum LineageR.ELMRPvpAdditionalAction
enum class ELMRPvpAdditionalAction : uint8 {
	All = 0,
	Kill = 1,
	Assist = 2,
	Die = 3,
	End = 4,
	ELMRPvpAdditionalAction_MAX = 5
};

// Enum LineageR.EDeathPenaltyCurrencyType
enum class EDeathPenaltyCurrencyType : uint8 {
	EDPC_GEM = 0,
	EDPC_ADENA = 1,
	EDPC_MAX = 2
};

// Enum LineageR.EDeathPenaltyRestoreType
enum class EDeathPenaltyRestoreType : uint8 {
	EDPR_EXP = 0,
	EDPR_ITEM = 1,
	EDPR_MAX = 2
};

// Enum LineageR.ELMRRenderTargetType
enum class ELMRRenderTargetType : uint8 {
	Invalid = 0,
	BuffCard = 1,
	Ranker1 = 2,
	Ranker2 = 3,
	Ranker3 = 4,
	Luckybag = 5,
	Preview = 6,
	Illustrated = 7,
	ELMRRenderTargetType_MAX = 8
};

// Enum LineageR.ELMRScreenEffectTriggerType
enum class ELMRScreenEffectTriggerType : uint8 {
	Invalid = 0,
	BattleField = 1,
	TargetFocus = 2,
	ELMRScreenEffectTriggerType_MAX = 3
};

// Enum LineageR.ELMRSearchHistoryType
enum class ELMRSearchHistoryType : uint8 {
	None = 0,
	ItemTrade = 1,
	ItemCraft = 2,
	Polymorph = 3,
	PolymorphDoll = 4,
	ELMRSearchHistoryType_MAX = 5
};

// Enum LineageR.ELMRItemLockReasonType
enum class ELMRItemLockReasonType : uint8 {
	ItemLock_GoodsGrade = 0,
	ItemLock_ClanGrowthLevel = 1,
	ItemLock_ClanMemeberRank = 2,
	ItemLock_ClanPoint = 3,
	ItemLock_SiegeTime = 4,
	ItemLock_MAX = 5
};

// Enum LineageR.ELMRItemListType
enum class ELMRItemListType : uint8 {
	ItemTouch = 0,
	ItemLock = 1,
	ItemSoldout = 2,
	ItemAddConfig = 3,
	ELMRItemListType_MAX = 4
};

// Enum LineageR.ELMRNPCShopItemListContentType
enum class ELMRNPCShopItemListContentType : uint8 {
	Common = 0,
	Detail = 1,
	AutoBuyConfig = 2,
	AutoSellConfig = 3,
	AutoSellDelConfig = 4,
	Exchange = 5,
	ELMRNPCShopItemListContentType_MAX = 6
};

// Enum LineageR.ELMRNPCShopAutoConfigTabIndex
enum class ELMRNPCShopAutoConfigTabIndex : uint8 {
	AutoBuy = 0,
	AutoSell = 1,
	ELMRNPCShopAutoConfigTabIndex_MAX = 2
};

// Enum LineageR.ELMRNPCShopGoodsFilterType
enum class ELMRNPCShopGoodsFilterType : uint8 {
	All = 0,
	Custom1 = 1,
	Custom2 = 2,
	Potion = 3,
	Misc = 4,
	AutoSell = 5,
	Custom = 6,
	ELMRNPCShopGoodsFilterType_MAX = 7
};

// Enum LineageR.ELMRNPCShopGoodsListType
enum class ELMRNPCShopGoodsListType : uint8 {
	BuySell = 0,
	AutoConfig = 1,
	ELMRNPCShopGoodsListType_MAX = 2
};

// Enum LineageR.ELMRNPCShopMode
enum class ELMRNPCShopMode : uint8 {
	None = 0,
	Buy = 1,
	Sell = 2,
	AutoBuyConfig = 3,
	AutoSellConfig = 4,
	Exchange = 5,
	ELMRNPCShopMode_MAX = 6
};

// Enum LineageR.ELMRNPCShopGrade
enum class ELMRNPCShopGrade : uint8 {
	Common = 0,
	Uncommon = 1,
	Rare = 2,
	Unique = 3,
	Legend = 4,
	Epic = 5,
	ELMRNPCShopGrade_MAX = 6
};

// Enum LineageR.ELMRSocketlTextStateType
enum class ELMRSocketlTextStateType : uint8 {
	Unactive = 0,
	Disappear = 1,
	Active = 2,
	Open = 3,
	ELMRSocketlTextStateType_MAX = 4
};

// Enum LineageR.ELMRMusicPriority
enum class ELMRMusicPriority : uint8 {
	Default = 0,
	ELMRMusicPriority_MAX = 1
};

// Enum LineageR.ELMRAudioCultureType
enum class ELMRAudioCultureType : uint8 {
	English_US_ = 0,
	Korean = 1,
	Japanese = 2,
	Chinese = 3,
	Max = 4,
	Default = 0
};

// Enum LineageR.ELMRSoundFilterBits
enum class ELMRSoundFilterBits : uint8 {
	Ragdoll = 1,
	ELMRSoundFilterBits_MAX = 2
};

// Enum LineageR.ELMRInfravisionState
enum class ELMRInfravisionState : uint8 {
	NONE = 0,
	BEFORE = 1,
	PLAYING = 2,
	END = 3,
	ELMRInfravisionState_MAX = 4
};

// Enum LineageR.ELMRInfravisionSelectType
enum class ELMRInfravisionSelectType : uint8 {
	Normal = 0,
	SelectingArea = 1,
	Targeting = 2,
	AttackDeclaration = 3,
	ELMRInfravisionSelectType_MAX = 4
};

// Enum LineageR.ELMRInfravisionTargetType
enum class ELMRInfravisionTargetType : uint8 {
	Player = 0,
	Alliance = 1,
	SpecialAlliance = 2,
	Enemy = 3,
	SpecialEnemy = 4,
	Neutral = 5,
	AttackerNeutral = 6,
	ELMRInfravisionTargetType_MAX = 7
};

// Enum LineageR.ELMRBattleLogAttackIconType
enum class ELMRBattleLogAttackIconType : uint8 {
	Invalid = 0,
	None = 1,
	Melee = 2,
	Range = 3,
	ELMRBattleLogAttackIconType_MAX = 4
};

// Enum LineageR.ESpellPageType
enum class ESpellPageType : uint8 {
	CommonSpell = 0,
	SpecialSpell = 1,
	Count = 2,
	ESpellPageType_MAX = 3
};

// Enum LineageR.ELMRChangeableSpellGroup
enum class ELMRChangeableSpellGroup : uint8 {
	ECSG_Normal = 0,
	ECSG_Fire = 1,
	ECSG_Water = 2,
	ECSG_Wind = 3,
	ECSG_Earth = 4,
	ECSG_Count = 5,
	ECSG_MAX = 6
};

// Enum LineageR.ELMRStatType
enum class ELMRStatType : int32 {
	Min = 11143,
	Str = 11143,
	Dex = 11144,
	Int = 11145,
	Con = 11146,
	Wis = 11147,
	Cha = 11148,
	PureStr = 11149,
	PureDex = 11150,
	PureInt = 11151,
	PureCon = 11152,
	PureWis = 11153,
	PureCha = 11154,
	EarthResist = 11155,
	FireResist = 11156,
	WaterResist = 11157,
	AirResist = 11158,
	StunResist = 11159,
	LapidificationResist = 11160,
	SleepResist = 11161,
	PosionResist = 11162,
	IceResist = 11163,
	SilenceResist = 11164,
	BleedResist = 11165,
	StunHitProbability = 11166,
	LapidificationHitProbability = 11167,
	SleepHitProbability = 11168,
	PosionHitProbability = 11169,
	IceHitProbability = 11170,
	SilenceHitProbability = 11171,
	BleedHitProbability = 11172,
	EvasionRate = 11173,
	ArmorClass = 11174,
	HpRegen_Min = 11175,
	HpRegen_Max = 11176,
	HpPotionRegen = 11177,
	MpPotionRegen = 11178,
	MeleeDamageIncrease = 11179,
	RangeDamageIncrease = 11180,
	MagicDamageIncrease = 11181,
	ArmorClassIncrease = 11182,
	levelupHPIncrease_Min = 11183,
	levelupHPIncrease_Max = 11184,
	levelupMPIncrease_Min = 11185,
	levelupMPIncrease_Max = 11186,
	BonusStatCount = 11187,
	ElixirCount = 11188,
	CompleteStatCount = 11189,
	MagicLevel = 11190,
	MagicCastingDelay = 11191,
	HittedDelay = 11192,
	Stat_None = 11193,
	Max = 11193
};

// Enum LineageR.ELMRPositionType
enum class ELMRPositionType : uint8 {
	LEFT = 0,
	RIGHT = 1,
	CENTER = 2,
	ELMRPositionType_MAX = 3
};

// Enum LineageR.ERootWidgetType
enum class ERootWidgetType : uint8 {
	None = 0,
	MobileLandscape = 1,
	MobilePortrait = 2,
	ERootWidgetType_MAX = 3
};

// Enum LineageR.ELMRWorldMapDebugPointType
enum class ELMRWorldMapDebugPointType : uint8 {
	None = 0,
	NearbyMovablePos = 1,
	ELMRWorldMapDebugPointType_MAX = 2
};

// Enum LineageR.ELMRLandMovingState
enum class ELMRLandMovingState : uint8 {
	Prepare = 0,
	PreLoad = 1,
	StartPostLoad = 2,
	FinishPostLoad = 3,
	PlayerEntered = 4,
	PlayerReady = 5,
	LeaveWorld = 6,
	Idle = 7,
	ELMRLandMovingState_MAX = 8
};

// Enum LineageR.ELMRLandLoadingConditionType
enum class ELMRLandLoadingConditionType : uint8 {
	SelectedGender = 0,
	IsEverWorldEntered = 1,
	ELMRLandLoadingConditionType_MAX = 2
};

// Enum LineageR.ELMRLandType
enum class ELMRLandType : uint8 {
	Invalid = 0,
	Field = 1,
	Dungeon = 2,
	ELMRLandType_MAX = 3
};

// Enum LineageR.ELMRLevelStreamingFilterFlag
enum class ELMRLevelStreamingFilterFlag : uint8 {
	Invalid = 0,
	Presentation = 1,
	ELMRLevelStreamingFilterFlag_MAX = 2
};

// Enum LineageR.ELMRWorldConditionState
enum class ELMRWorldConditionState : uint8 {
	None = 0,
	Deactivate = 1,
	Activate = 2,
	ELMRWorldConditionState_MAX = 3
};

// Enum LineageR.ELMRWorldConditionDisplayType
enum class ELMRWorldConditionDisplayType : uint8 {
	None = 0,
	Building = 1,
	NPC = 2,
	ELMRWorldConditionDisplayType_MAX = 3
};

// Enum LineageR.ELMRWorldConditionType
enum class ELMRWorldConditionType : uint8 {
	Visibility = 0,
	Switch = 1,
	Timelapse = 2,
	ELMRWorldConditionType_MAX = 3
};

// Enum LineageR.ELMRHyperLinkType
enum class ELMRHyperLinkType : uint8 {
	None = 0,
	Item = 1,
	OwnedItem = 2,
	Spell = 3,
	NPC = 4,
	Monster = 5,
	MapBase = 6,
	MapCastle = 7,
	MapDungeon = 8,
	MapField = 9,
	MapLand = 10,
	MapVillage = 11,
	Clan = 12,
	Card = 13,
	MagicDoll = 14,
	StyleCard = 15,
	StyleMagicDoll = 16,
	Invite = 17,
	ELMRHyperLinkType_MAX = 18
};

// Enum LineageR.ELMRWarningType
enum class ELMRWarningType : uint8 {
	None = 0,
	Wifi = 1,
	Battery = 2,
	All = 3,
	ELMRWarningType_MAX = 4
};

// Enum LineageR.ELMRMapLoadType
enum class ELMRMapLoadType : uint8 {
	None = 0,
	Enter = 1,
	Portal = 2,
	Teleport = 3,
	ELMRMapLoadType_MAX = 4
};

// Enum LineageR.EHorizontalOrderType
enum class EHorizontalOrderType : uint8 {
	LeftToRight = 0,
	RightToLeft = 1,
	EHorizontalOrderType_MAX = 2
};

// Enum LineageR.EVerticalOrderType
enum class EVerticalOrderType : uint8 {
	TopToBottom = 0,
	BottomToTop = 1,
	EVerticalOrderType_MAX = 2
};

// ScriptStruct LineageR.GFAttributemapData
// Size: 0x40 (Inherited: 0x00)
struct FGFAttributemapData {
	struct TArray<struct FGridData> GridData; // 0x00(0x10)
	struct FVector coordnatieOrigin; // 0x10(0x0c)
	float TileSize; // 0x1c(0x04)
	int32_t SegmentWidth; // 0x20(0x04)
	int32_t SegmentHeight; // 0x24(0x04)
	struct FString SegmentName; // 0x28(0x10)
	struct FIntPoint SegmentPoint; // 0x38(0x08)
};

// ScriptStruct LineageR.GridData
// Size: 0x08 (Inherited: 0x00)
struct FGridData {
	int32_t Data; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
};

// ScriptStruct LineageR.GridEdgeData
// Size: 0x0c (Inherited: 0x00)
struct FGridEdgeData {
	int32_t From; // 0x00(0x04)
	int32_t To; // 0x04(0x04)
	float cost; // 0x08(0x04)
};

// ScriptStruct LineageR.LMRMusicTable
// Size: 0x58 (Inherited: 0x08)
struct FLMRMusicTable : FTableRowBase {
	struct TSoftClassPtr<UObject> UIClass; // 0x08(0x28)
	struct TSoftObjectPtr<ULMRMusic> MusicAsset; // 0x30(0x28)
};

// ScriptStruct LineageR.LMCheckActivateWorldCondition
// Size: 0x10 (Inherited: 0x00)
struct FLMCheckActivateWorldCondition {
	struct TArray<int32_t> ConditionStateList; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRAIServerDataStoreTable
// Size: 0x18 (Inherited: 0x08)
struct FLMRAIServerDataStoreTable : FTableRowBase {
	int32_t Actionid; // 0x08(0x04)
	struct FName Desc; // 0x0c(0x08)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.SequenceInfo
// Size: 0x10 (Inherited: 0x00)
struct FSequenceInfo {
	struct UAnimSequenceBase* Sequence; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRParticleParamData
// Size: 0x10 (Inherited: 0x00)
struct FLMRParticleParamData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FName ParamName; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRMaterialParticleParamData
// Size: 0x18 (Inherited: 0x10)
struct FLMRMaterialParticleParamData : FLMRParticleParamData {
	struct UMaterialInterface* Param; // 0x10(0x08)
};

// ScriptStruct LineageR.LMRVectorRandParticleParamData
// Size: 0x28 (Inherited: 0x10)
struct FLMRVectorRandParticleParamData : FLMRParticleParamData {
	struct FVector Param; // 0x10(0x0c)
	struct FVector LowParam; // 0x1c(0x0c)
};

// ScriptStruct LineageR.LMRVectorParticleParamData
// Size: 0x20 (Inherited: 0x10)
struct FLMRVectorParticleParamData : FLMRParticleParamData {
	struct FVector Param; // 0x10(0x0c)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct LineageR.LMRFloatRandParticleParamData
// Size: 0x18 (Inherited: 0x10)
struct FLMRFloatRandParticleParamData : FLMRParticleParamData {
	float Param; // 0x10(0x04)
	float LowParam; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRFloatParticleParamData
// Size: 0x18 (Inherited: 0x10)
struct FLMRFloatParticleParamData : FLMRParticleParamData {
	float Param; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRColorParticleParamData
// Size: 0x20 (Inherited: 0x10)
struct FLMRColorParticleParamData : FLMRParticleParamData {
	struct FLinearColor Param; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRSplineCurveInfo
// Size: 0x18 (Inherited: 0x00)
struct FLMRSplineCurveInfo {
	struct UCurveFloat* SplineCurve; // 0x00(0x08)
	struct FName SplineMeshName; // 0x08(0x08)
	struct FName SplineMaterialName; // 0x10(0x08)
};

// ScriptStruct LineageR.LMRItemBlessInfo
// Size: 0x38 (Inherited: 0x00)
struct FLMRItemBlessInfo {
	struct FLinearColor BlessColor; // 0x00(0x10)
	struct TSoftObjectPtr<UMaterialInstance> BlessFX; // 0x10(0x28)
};

// ScriptStruct LineageR.LMRMoveSpeedEffectInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRMoveSpeedEffectInfo {
	struct FName strMemo; // 0x00(0x08)
	int32_t MinMoveSpeed; // 0x08(0x04)
	int32_t MaxMoveSpeed; // 0x0c(0x04)
	struct TArray<struct FName> MoveSpeedEffectList; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRPlayerStat
// Size: 0x60 (Inherited: 0x00)
struct FLMRPlayerStat {
	struct FLinearColor StatTextNormal; // 0x00(0x10)
	struct FLinearColor StatTextChanged; // 0x10(0x10)
	struct FLinearColor StatTextMax; // 0x20(0x10)
	struct FLinearColor StatProgressBarNormal; // 0x30(0x10)
	struct FLinearColor StatProgressBarChanged; // 0x40(0x10)
	struct FLinearColor StatProgressBarMax; // 0x50(0x10)
};

// ScriptStruct LineageR.LMRObjectMaterialSwapParameterValueSpec
// Size: 0xd8 (Inherited: 0x00)
struct FLMRObjectMaterialSwapParameterValueSpec {
	struct FName ParamName; // 0x00(0x08)
	float Duration; // 0x08(0x04)
	float ReverseDuration; // 0x0c(0x04)
	float BlendInScalar; // 0x10(0x04)
	float BlendOutScalar; // 0x14(0x04)
	struct TMap<enum class ELMRObjectMaterialSwapType, float> DependencyInitValueMap; // 0x18(0x50)
	struct TMap<enum class ELMRObjectMaterialSwapType, float> DependencyReversedInitValueMap; // 0x68(0x50)
	struct TArray<struct FName> DependencyMaterialVectorParam; // 0xb8(0x10)
	struct TArray<struct FName> DependencyMaterialValueParam; // 0xc8(0x10)
};

// ScriptStruct LineageR.LMRDissolveParameters
// Size: 0x0c (Inherited: 0x00)
struct FLMRDissolveParameters {
	struct FName PhaseParamName; // 0x00(0x08)
	float PhaseDuration; // 0x08(0x04)
};

// ScriptStruct LineageR.LMRDisplayAttackData
// Size: 0x30 (Inherited: 0x00)
struct FLMRDisplayAttackData {
	int32_t DescID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UTexture2D> Image; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRBuffCardName
// Size: 0x98 (Inherited: 0x00)
struct FLMRBuffCardName {
	struct FLinearColor ActivateTextColor; // 0x00(0x10)
	struct FLinearColor DeactivateTextColor; // 0x10(0x10)
	struct TSoftObjectPtr<UTexture2D> ActivateImage; // 0x20(0x28)
	struct TSoftObjectPtr<UTexture2D> DeactivateImage; // 0x48(0x28)
	struct TSoftObjectPtr<UMaterialInstance> CardFx; // 0x70(0x28)
};

// ScriptStruct LineageR.LMRStatusEffectBody
// Size: 0x30 (Inherited: 0x00)
struct FLMRStatusEffectBody {
	struct FLinearColor Color; // 0x00(0x10)
	float AlwaysOn; // 0x10(0x04)
	float Speed; // 0x14(0x04)
	struct UMaterialInstance* EffectMaterial; // 0x18(0x08)
	struct FLMRStatusAttributeEffectBody AttributeInfo; // 0x20(0x0c)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct LineageR.LMRStatusAttributeEffectBody
// Size: 0x0c (Inherited: 0x00)
struct FLMRStatusAttributeEffectBody {
	bool AbnormalStatus_Used; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t AbnormalStatus_TexIndex; // 0x04(0x04)
	bool AbnormalStatus_PlayRate; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct LineageR.LMRStatusEffectScreenSpecial
// Size: 0x08 (Inherited: 0x00)
struct FLMRStatusEffectScreenSpecial {
	struct UMaterialInterface* PostprocessMaterial; // 0x00(0x08)
};

// ScriptStruct LineageR.LMRStatusEffectScreen
// Size: 0x10 (Inherited: 0x00)
struct FLMRStatusEffectScreen {
	struct FLinearColor Color; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRPreloadAssetTypeInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRPreloadAssetTypeInfo {
	struct TArray<struct FDirectoryPath> Directories; // 0x00(0x10)
	struct TArray<struct FLMRPreloadAssetTypePath> SpecificAssets; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRPreloadAssetTypePath
// Size: 0x18 (Inherited: 0x00)
struct FLMRPreloadAssetTypePath {
	struct FSoftObjectPath Path; // 0x00(0x18)
};

// ScriptStruct LineageR.StoneInfo
// Size: 0x0c (Inherited: 0x00)
struct FStoneInfo {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct LineageR.ModuleParticleData
// Size: 0x58 (Inherited: 0x00)
struct FModuleParticleData {
	enum class EAutoPlayAnimType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<struct FString, struct FString> particles_; // 0x08(0x50)
};

// ScriptStruct LineageR.StoneParticleData
// Size: 0x58 (Inherited: 0x00)
struct FStoneParticleData {
	enum class EAutoPlayAnimType Type; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TMap<int32_t, struct FString> particles_; // 0x08(0x50)
};

// ScriptStruct LineageR.AutoPlayAnimData
// Size: 0x50 (Inherited: 0x00)
struct FAutoPlayAnimData {
	struct TMap<enum class EAutoPlayAnimType, struct UAnimationAsset*> anims_; // 0x00(0x50)
};

// ScriptStruct LineageR.BannerSound
// Size: 0x50 (Inherited: 0x00)
struct FBannerSound {
	struct TMap<enum class BannerType, struct UAkAudioEvent*> Sounds; // 0x00(0x50)
};

// ScriptStruct LineageR.LMRBloodEffectTable
// Size: 0x80 (Inherited: 0x08)
struct FLMRBloodEffectTable : FTableRowBase {
	float NormalDamagedBlowoutProb; // 0x08(0x04)
	float SmashDamage; // 0x0c(0x04)
	float BlowoutCorrectionAngle; // 0x10(0x04)
	int32_t Blowout_1Score; // 0x14(0x04)
	int32_t Blowout_1ScoreMaxLimit; // 0x18(0x04)
	int32_t Blowout_2Score; // 0x1c(0x04)
	int32_t Blowout_2ScoreMaxLimit; // 0x20(0x04)
	int32_t Blowout_3Score; // 0x24(0x04)
	int32_t Blowout_3ScoreMaxLimit; // 0x28(0x04)
	struct FName Blowout_NormalFX; // 0x2c(0x08)
	struct FName Blowout_CriticalFX; // 0x34(0x08)
	struct FName Blowout_GreatFX; // 0x3c(0x08)
	float BloodMaxDuration; // 0x44(0x04)
	int32_t MessMinimumScore; // 0x48(0x04)
	float MessMinimumDisplayRate; // 0x4c(0x04)
	float MessMinimumDisplayAlpha; // 0x50(0x04)
	int32_t MessMaximumScore; // 0x54(0x04)
	float MessMaximumDisplayRate; // 0x58(0x04)
	float MessMaximumDisplayAlpha; // 0x5c(0x04)
	struct FLinearColor MessColor; // 0x60(0x10)
	int32_t BloodstainScore; // 0x70(0x04)
	float BloodDistance; // 0x74(0x04)
	float BloodstainDuration; // 0x78(0x04)
	char pad_7C[0x4]; // 0x7c(0x04)
};

// ScriptStruct LineageR.LMRBuffCardDollSynthetic
// Size: 0x120 (Inherited: 0x00)
struct FLMRBuffCardDollSynthetic {
	struct FString SyntheticCameraName; // 0x00(0x10)
	int32_t SyntheticStartSequencerID; // 0x10(0x04)
	int32_t SyntheticEndSequencerID; // 0x14(0x04)
	int32_t ModelIndex; // 0x18(0x04)
	struct FVector SpawnLocation; // 0x1c(0x0c)
	struct FRotator SpawnRot; // 0x28(0x0c)
	struct FVector SpawnScale; // 0x34(0x0c)
	float GoalIntervalPer; // 0x40(0x04)
	float GoalInterval3D; // 0x44(0x04)
	struct FVector SpawnResultLocation; // 0x48(0x0c)
	struct FVector SpawnResultScale; // 0x54(0x0c)
	struct FName MagicMachineTreeLoop; // 0x60(0x08)
	struct FName MagicMachineTreeEnd; // 0x68(0x08)
	struct FName MagicMachineTreeEndLoop; // 0x70(0x08)
	struct TMap<enum class ELMRBuffCardFxGrade, struct FName> MapMagicMachineLightningGrade; // 0x78(0x50)
	struct FVector LineSizeMin; // 0xc8(0x0c)
	struct FVector LineSizeMax; // 0xd4(0x0c)
	struct FVector ParticleLocationMin; // 0xe0(0x0c)
	struct FVector ParticleLocationMax; // 0xec(0x0c)
	float AuraSizeMin; // 0xf8(0x04)
	float AuraSizeMax; // 0xfc(0x04)
	float GlowColorMin; // 0x100(0x04)
	float GlowColorMax; // 0x104(0x04)
	float LightColorMin; // 0x108(0x04)
	float LightColorMax; // 0x10c(0x04)
	float ParticleInMin; // 0x110(0x04)
	float ParticleInMax; // 0x114(0x04)
	float ParticleSpawnMin; // 0x118(0x04)
	float ParticleSpawnMax; // 0x11c(0x04)
};

// ScriptStruct LineageR.LMRBuffCardMergeTargetInfo
// Size: 0x110 (Inherited: 0x00)
struct FLMRBuffCardMergeTargetInfo {
	struct FTransform Transform[0x4]; // 0x00(0xc0)
	struct FName FloorFxName[0x4]; // 0xc0(0x20)
	struct FName CanRegistMergeTargetFxName[0x4]; // 0xe0(0x20)
	char pad_100[0x10]; // 0x100(0x10)
};

// ScriptStruct LineageR.LMRBuffCardEffect
// Size: 0x18 (Inherited: 0x00)
struct FLMRBuffCardEffect {
	struct FName ParticleName; // 0x00(0x08)
	struct TArray<struct UCurveVector*> SplineAsset; // 0x08(0x10)
};

// ScriptStruct LineageR.LMRBuffCardDataDesignTable
// Size: 0x18 (Inherited: 0x08)
struct FLMRBuffCardDataDesignTable : FTableRowBase {
	float ModelSizeScale; // 0x08(0x04)
	float ModelRotateAngle; // 0x0c(0x04)
	float ModelOffsetHeight; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRBuffCardDataEffectTable
// Size: 0x88 (Inherited: 0x08)
struct FLMRBuffCardDataEffectTable : FTableRowBase {
	struct FSoftObjectPath PortraitPath; // 0x08(0x18)
	struct FSoftObjectPath StylePortraitPath; // 0x20(0x18)
	struct FSoftObjectPath CircularThumbnail; // 0x38(0x18)
	struct FSoftObjectPath CompareThumbnail; // 0x50(0x18)
	struct TArray<struct FSoftObjectPath> LevelSequence; // 0x68(0x10)
	struct FLMRGameBuffCardSequenceInfo LevelSequenceLoopInfo; // 0x78(0x10)
};

// ScriptStruct LineageR.LMRGameBuffCardSequenceInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRGameBuffCardSequenceInfo {
	struct TArray<int32_t> LevelSequenceIndex; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRBuffCardGachaGradeFxInfo
// Size: 0x0c (Inherited: 0x00)
struct FLMRBuffCardGachaGradeFxInfo {
	int32_t Grade; // 0x00(0x04)
	struct FName FxName; // 0x04(0x08)
};

// ScriptStruct LineageR.LMRBuffCardGachaChessboardData
// Size: 0x10 (Inherited: 0x00)
struct FLMRBuffCardGachaChessboardData {
	struct TArray<struct UMaterialInstance*> Materials; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRBuffCardGachaTimePhaseData
// Size: 0x0c (Inherited: 0x00)
struct FLMRBuffCardGachaTimePhaseData {
	float TimePhase1; // 0x00(0x04)
	float TimePhase2; // 0x04(0x04)
	float TimePhase3; // 0x08(0x04)
};

// ScriptStruct LineageR.LMRBuffCardGachaChessmenData
// Size: 0x20 (Inherited: 0x00)
struct FLMRBuffCardGachaChessmenData {
	struct ALMRBuffCardGachaChessmen* ActorBp; // 0x00(0x08)
	struct TArray<struct UMaterialInstance*> Materials; // 0x08(0x10)
	int32_t SpawnRatio; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct LineageR.LMRBuffCardCameraRestoreSetting
// Size: 0x550 (Inherited: 0x00)
struct FLMRBuffCardCameraRestoreSetting {
	char pad_0[0x550]; // 0x00(0x550)
};

// ScriptStruct LineageR.LMRBuffCardMergeResultGradeFxInfo
// Size: 0x0c (Inherited: 0x00)
struct FLMRBuffCardMergeResultGradeFxInfo {
	int32_t Grade; // 0x00(0x04)
	struct FName FxName; // 0x04(0x08)
};

// ScriptStruct LineageR.LMRBuffCardMergeResultTargetInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRBuffCardMergeResultTargetInfo {
	struct TArray<struct FTransform> Transforms; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRSlotGradeData
// Size: 0x50 (Inherited: 0x00)
struct FLMRSlotGradeData {
	struct TSoftObjectPtr<UTexture2D> SlotBg; // 0x00(0x28)
	struct TSoftObjectPtr<UTexture2D> IconBg; // 0x28(0x28)
};

// ScriptStruct LineageR.LMRBuffCardSwapCurveInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRBuffCardSwapCurveInfo {
	struct UCurveFloat* PositionCurve; // 0x00(0x08)
	struct UCurveFloat* RotateCurve; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRCameraShakeTableRow
// Size: 0x30 (Inherited: 0x08)
struct FLMRCameraShakeTableRow : FTableRowBase {
	struct UCameraShake* CameraShakeClass; // 0x08(0x08)
	float Scale; // 0x10(0x04)
	enum class ECameraAnimPlaySpace PlaySpace; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FRotator UserPlaySpaceRot; // 0x18(0x0c)
	struct FName Comment; // 0x24(0x08)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct LineageR.orceMoveParameter
// Size: 0x20 (Inherited: 0x00)
struct ForceMoveParameter {
	char pad_0[0x20]; // 0x00(0x20)
};

// ScriptStruct LineageR.LMRChatCommandTable
// Size: 0x30 (Inherited: 0x08)
struct FLMRChatCommandTable : FTableRowBase {
	enum class ELMRChatCommandType ChatCommandType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FString ChatCommandString; // 0x10(0x10)
	struct FString ChatCommandParameters; // 0x20(0x10)
};

// ScriptStruct LineageR.LMRChatFilterInfo
// Size: 0x14 (Inherited: 0x00)
struct FLMRChatFilterInfo {
	struct FLinearColor ChatColor; // 0x00(0x10)
	int32_t FilterUITextID; // 0x10(0x04)
};

// ScriptStruct LineageR.LMRCheatMacroTable
// Size: 0x30 (Inherited: 0x08)
struct FLMRCheatMacroTable : FTableRowBase {
	struct FString Command; // 0x08(0x10)
	struct FString Message; // 0x18(0x10)
	float Interval; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

// ScriptStruct LineageR.LMRCameraLookatTrackingSettings
// Size: 0x50 (Inherited: 0x00)
struct FLMRCameraLookatTrackingSettings {
	char bEnableLookAtTracking : 1; // 0x00(0x01)
	char bDrawDebugLookAtTrackingPosition : 1; // 0x00(0x01)
	char pad_0_2 : 6; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float LookAtTrackingInterpSpeed; // 0x04(0x04)
	char pad_8[0x10]; // 0x08(0x10)
	struct TSoftObjectPtr<AActor> ActorToTrack; // 0x18(0x28)
	struct FVector RelativeOffset; // 0x40(0x0c)
	char bAllowRoll : 1; // 0x4c(0x01)
	char pad_4C_1 : 7; // 0x4c(0x01)
	char pad_4D[0x3]; // 0x4d(0x03)
};

// ScriptStruct LineageR.LMRDialogSoundDataTable
// Size: 0x170 (Inherited: 0x08)
struct FLMRDialogSoundDataTable : FTableRowBase {
	struct TSoftObjectPtr<UAkAudioEvent> DialogSound; // 0x08(0x28)
	struct TMap<int32_t, float> Duration_Android; // 0x30(0x50)
	struct TMap<int32_t, float> Duration_IOS; // 0x80(0x50)
	struct TMap<int32_t, float> Duration_Mac; // 0xd0(0x50)
	struct TMap<int32_t, float> Duration_Windows; // 0x120(0x50)
};

// ScriptStruct LineageR.LMRDialogueContextSelection
// Size: 0x10 (Inherited: 0x00)
struct FLMRDialogueContextSelection {
	struct TArray<struct FLMRDialogueContext> Contexts; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRDialogueContext
// Size: 0x30 (Inherited: 0x00)
struct FLMRDialogueContext {
	struct FName SpeakerName; // 0x00(0x08)
	LazyObjectProperty Speaker; // 0x08(0x1c)
	char pad_24[0x4]; // 0x24(0x04)
	struct UAkAudioEvent* PlayVoice; // 0x28(0x08)
};

// ScriptStruct LineageR.LMRDungeonEnvDataTable
// Size: 0x20 (Inherited: 0x08)
struct FLMRDungeonEnvDataTable : FTableRowBase {
	bool IsOverride_PlayerPointLight; // 0x08(0x01)
	bool EnablePlayerPointLight; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FString Comment; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRDynamicWidgetConfigData
// Size: 0x18 (Inherited: 0x00)
struct FLMRDynamicWidgetConfigData {
	struct FSoftClassPath WidgetPath; // 0x00(0x18)
};

// ScriptStruct LineageR.LMREffectSystemDataTable
// Size: 0x148 (Inherited: 0x08)
struct FLMREffectSystemDataTable : FTableRowBase {
	struct TSoftObjectPtr<UParticleSystem> ParticleSystem; // 0x08(0x28)
	struct TSoftClassPtr<UObject> AnimFX; // 0x30(0x28)
	struct FName SocketName; // 0x58(0x08)
	bool UseOnBattleCommand; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	struct FVector LocationOffset; // 0x64(0x0c)
	struct FRotator RotationOffset; // 0x70(0x0c)
	bool IgnoreRotation; // 0x7c(0x01)
	bool IsAttached; // 0x7d(0x01)
	bool UseHitImpactTransform; // 0x7e(0x01)
	char pad_7F[0x1]; // 0x7f(0x01)
	float HitImpactDistance; // 0x80(0x04)
	bool ForceToGroundForBossHit; // 0x84(0x01)
	enum class EAttachLocation LocationRule; // 0x85(0x01)
	bool EnableAsyncLoading; // 0x86(0x01)
	char pad_87[0x1]; // 0x87(0x01)
	float Scale; // 0x88(0x04)
	bool UseRelativeScale; // 0x8c(0x01)
	enum class ELMRFXReleaseOptionType ReleaseOptionType; // 0x8d(0x01)
	char pad_8E[0x2]; // 0x8e(0x02)
	struct FString Memo; // 0x90(0x10)
	struct TSoftObjectPtr<UAkAudioEvent> SoundEvent1P; // 0xa0(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> SoundEvent3P; // 0xc8(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> SoundEventNPC; // 0xf0(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> SoundEventBOSS; // 0x118(0x28)
	bool IsApplyGroundPhysicalSurfaceForSound; // 0x140(0x01)
	char pad_141[0x7]; // 0x141(0x07)
};

// ScriptStruct LineageR.LMREnchantFxEventDataTable
// Size: 0xd0 (Inherited: 0x08)
struct FLMREnchantFxEventDataTable : FTableRowBase {
	int32_t EnchantGroupId; // 0x08(0x04)
	float StartRate; // 0x0c(0x04)
	float EndRate; // 0x10(0x04)
	float TotalTime; // 0x14(0x04)
	float FxLifeTime; // 0x18(0x04)
	int32_t SpawnProbability; // 0x1c(0x04)
	enum class ELMREnchantObjecType SourceType; // 0x20(0x01)
	enum class ELMREnchantObjecType TargetType; // 0x21(0x01)
	char pad_22[0x2]; // 0x22(0x02)
	struct FName ParticleName; // 0x24(0x08)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct UCurveVector* SplineAsset; // 0x30(0x08)
	struct TSoftObjectPtr<UStaticMesh> SplineMeshAsset; // 0x38(0x28)
	struct TSoftObjectPtr<UMaterialInterface> SplineMeshMaterialAsset; // 0x60(0x28)
	struct FName SourceSocketName; // 0x88(0x08)
	struct FName TargetSocketName; // 0x90(0x08)
	struct FVector SourceOffsetPosition; // 0x98(0x0c)
	struct FVector TargetOffsetPosition; // 0xa4(0x0c)
	bool FollowTouchDirection; // 0xb0(0x01)
	bool Loop; // 0xb1(0x01)
	bool PlayOnce; // 0xb2(0x01)
	enum class ELMREnchantObjecType WantTouchDirectionToSpawn; // 0xb3(0x01)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct TArray<struct FName> ParticleNamesOnEndTime; // 0xb8(0x10)
	bool PlayReactionAnimation; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	int32_t CameraShakeIndex; // 0xcc(0x04)
};

// ScriptStruct LineageR.LMREnchantMaterialEventDataTable
// Size: 0x30 (Inherited: 0x08)
struct FLMREnchantMaterialEventDataTable : FTableRowBase {
	int32_t EnchantGroupId; // 0x08(0x04)
	enum class ELMREnchantObjecType SourceType; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	struct FName ParamValueName; // 0x10(0x08)
	float StartRate; // 0x18(0x04)
	float EndRate; // 0x1c(0x04)
	float StartValue; // 0x20(0x04)
	float EndValue; // 0x24(0x04)
	float DefaultValue; // 0x28(0x04)
	float OverEndValue; // 0x2c(0x04)
};

// ScriptStruct LineageR.LMREnchantMovementEventDataTable
// Size: 0x28 (Inherited: 0x08)
struct FLMREnchantMovementEventDataTable : FTableRowBase {
	int32_t EnchantGroupId; // 0x08(0x04)
	float StartRate; // 0x0c(0x04)
	float EndRate; // 0x10(0x04)
	enum class ELMREnchantObjecType SourceType; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct UCurveVector* LocationCurveVector; // 0x18(0x08)
	struct UCurveVector* RotateCurveVector; // 0x20(0x08)
};

// ScriptStruct LineageR.LMRConfigDataIds
// Size: 0x10 (Inherited: 0x00)
struct FLMRConfigDataIds {
	struct TArray<struct FLMRFakeClanInfo> infos; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRFakeClanInfo
// Size: 0x08 (Inherited: 0x00)
struct FLMRFakeClanInfo {
	int32_t npcGroupId; // 0x00(0x04)
	int32_t emblemId; // 0x04(0x04)
};

// ScriptStruct LineageR.LMRForceMoveDataTable
// Size: 0x28 (Inherited: 0x08)
struct FLMRForceMoveDataTable : FTableRowBase {
	struct UCurveFloat* MoveAccelerationCurve; // 0x08(0x08)
	struct UCurveFloat* AirborneCurve; // 0x10(0x08)
	struct FString Memo; // 0x18(0x10)
};

// ScriptStruct LineageR.LMResolutionOptionData
// Size: 0x0c (Inherited: 0x00)
struct FLMResolutionOptionData {
	int32_t LowResPercent; // 0x00(0x04)
	int32_t MidResPercent; // 0x04(0x04)
	int32_t HighResPercent; // 0x08(0x04)
};

// ScriptStruct LineageR.LMRFPSOptionData
// Size: 0x0c (Inherited: 0x00)
struct FLMRFPSOptionData {
	int32_t LowMaxFPS; // 0x00(0x04)
	int32_t MidMaxFPS; // 0x04(0x04)
	int32_t HighMaxFPS; // 0x08(0x04)
};

// ScriptStruct LineageR.LMROptionSlotSliderTypeBData
// Size: 0x14 (Inherited: 0x00)
struct FLMROptionSlotSliderTypeBData {
	int32_t NameUITextID; // 0x00(0x04)
	int32_t HPPercentUITextID; // 0x04(0x04)
	int32_t HPValueUITextID; // 0x08(0x04)
	struct FLMROptionSlotToolTipData ToolTipData; // 0x0c(0x08)
};

// ScriptStruct LineageR.LMROptionSlotToolTipData
// Size: 0x08 (Inherited: 0x00)
struct FLMROptionSlotToolTipData {
	bool IsFullPageGuide; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t TooltipId; // 0x04(0x04)
};

// ScriptStruct LineageR.LMROptionSlotSliderTypeAData
// Size: 0x10 (Inherited: 0x00)
struct FLMROptionSlotSliderTypeAData {
	int32_t NameUITextID; // 0x00(0x04)
	int32_t SliderValueUITextID; // 0x04(0x04)
	struct FLMROptionSlotToolTipData ToolTipData; // 0x08(0x08)
};

// ScriptStruct LineageR.LMROptionSlotCommonData
// Size: 0x38 (Inherited: 0x00)
struct FLMROptionSlotCommonData {
	int32_t NameUITextID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<int32_t> ElementUITextIDs; // 0x08(0x10)
	struct TArray<struct FString> IconTextureNames; // 0x18(0x10)
	struct FLMROptionSlotToolTipData ToolTipData; // 0x28(0x08)
	bool UseResetButton; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
};

// ScriptStruct LineageR.LMRGameStateDataTable
// Size: 0x38 (Inherited: 0x08)
struct FLMRGameStateDataTable : FTableRowBase {
	enum class ELMRGameStateType GameStateType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftClassPtr<UObject> GameStateBlueprint; // 0x10(0x28)
};

// ScriptStruct LineageR.GhostMaterialParamCurve
// Size: 0x10 (Inherited: 0x00)
struct FGhostMaterialParamCurve {
	struct FName ParamName; // 0x00(0x08)
	struct UCurveBase* ParamCurve; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRTokenData
// Size: 0x28 (Inherited: 0x00)
struct FLMRTokenData {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct LineageR.LMRJosaExcludeData
// Size: 0x20 (Inherited: 0x00)
struct FLMRJosaExcludeData {
	struct FString str1; // 0x00(0x10)
	struct FString str2; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRJosaCheckerData
// Size: 0x20 (Inherited: 0x00)
struct FLMRJosaCheckerData {
	struct FString str1; // 0x00(0x10)
	struct FString str2; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRHyperLinkStyleRow
// Size: 0x500 (Inherited: 0x08)
struct FLMRHyperLinkStyleRow : FTableRowBase {
	struct FHyperlinkStyle HyperlinkStyle; // 0x08(0x4f8)
};

// ScriptStruct LineageR.LMRImageSwitcherInfo
// Size: 0x30 (Inherited: 0x00)
struct FLMRImageSwitcherInfo {
	struct UObject* Texture; // 0x00(0x08)
	struct FSlateColor TextureTintColor; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRItemSoundDataTable
// Size: 0xb8 (Inherited: 0x08)
struct FLMRItemSoundDataTable : FTableRowBase {
	enum class EItemCategory itemCategory; // 0x08(0x01)
	enum class EItemWeaponType weaponType; // 0x09(0x01)
	char pad_A[0x2]; // 0x0a(0x02)
	enum class EEquipSlotTypeForSound equipSlotType; // 0x0c(0x04)
	enum class EItemMaterial materialType; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TSoftObjectPtr<UAkAudioEvent> TouchSound; // 0x18(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> EquipSound; // 0x40(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> UnEquipSound; // 0x68(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> DropSound; // 0x90(0x28)
};

// ScriptStruct LineageR.LMRKeyMappingTableRow
// Size: 0x38 (Inherited: 0x08)
struct FLMRKeyMappingTableRow : FTableRowBase {
	enum class ELMRKeyMappingCategory Category; // 0x08(0x01)
	enum class ELMRKeyMappingSubcategory Subcategory; // 0x09(0x01)
	enum class ELMRControlType ControlType; // 0x0a(0x01)
	enum class ELMRMappingType MappingType; // 0x0b(0x01)
	float AxisScale; // 0x0c(0x04)
	struct FName RollbackKey; // 0x10(0x08)
	int32_t Control_DescId; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString Control_Desc; // 0x20(0x10)
	bool AllowEditKey; // 0x30(0x01)
	bool AllowDuplicatedKey; // 0x31(0x01)
	bool Hide; // 0x32(0x01)
	char pad_33[0x5]; // 0x33(0x05)
};

// ScriptStruct LineageR.LMRLoadingScreenInfo
// Size: 0x78 (Inherited: 0x00)
struct FLMRLoadingScreenInfo {
	struct FSoftObjectPath Image; // 0x00(0x18)
	char pad_18[0x8]; // 0x18(0x08)
	struct FName ImageName; // 0x20(0x08)
	enum class EStretch ImageStretch; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FText LoadingTitleText; // 0x30(0x18)
	struct FText LoadingSummaryText; // 0x48(0x18)
	struct FText GameTipText; // 0x60(0x18)
};

// ScriptStruct LineageR.LMRLoadingScreenDescription
// Size: 0xd0 (Inherited: 0x00)
struct FLMRLoadingScreenDescription {
	float MinimumLoadingScreenDisplayTime; // 0x00(0x04)
	bool bAutoCompleteWhenLoadingCompletes; // 0x04(0x01)
	bool bMoviesAreSkippable; // 0x05(0x01)
	bool bWaitForManualStop; // 0x06(0x01)
	enum class EMoviePlaybackType PlaybackType; // 0x07(0x01)
	char pad_8[0x78]; // 0x08(0x78)
	struct TArray<struct FString> MoviePaths; // 0x80(0x10)
	bool bShowUIOverlay; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FText LoadingText; // 0x98(0x18)
	struct FLinearColor BackgroundColor; // 0xb0(0x10)
	struct FLinearColor TipBackgroundColor; // 0xc0(0x10)
};

// ScriptStruct LineageR.LMRGenderSelectContainer
// Size: 0x30 (Inherited: 0x00)
struct FLMRGenderSelectContainer {
	struct FSoftObjectPath MaleMovie; // 0x00(0x18)
	struct FSoftObjectPath FemaleMovie; // 0x18(0x18)
};

// ScriptStruct LineageR.LMRClassSelectContainer
// Size: 0x60 (Inherited: 0x00)
struct FLMRClassSelectContainer {
	struct FSoftObjectPath ClassSelectMovie_Male; // 0x00(0x18)
	struct FSoftObjectPath ClassEnterIngameMovie_Male; // 0x18(0x18)
	struct FSoftObjectPath ClassSelectMovie_Female; // 0x30(0x18)
	struct FSoftObjectPath ClassEnterIngameMovie_Female; // 0x48(0x18)
};

// ScriptStruct LineageR.LMRReactionContainer
// Size: 0x18 (Inherited: 0x00)
struct FLMRReactionContainer {
	struct FSoftObjectPath ClassDecoReactionLevelSequence; // 0x00(0x18)
};

// ScriptStruct LineageR.LMRSpellContainer
// Size: 0x48 (Inherited: 0x00)
struct FLMRSpellContainer {
	struct FSoftObjectPath Spell0; // 0x00(0x18)
	struct FSoftObjectPath Spell1; // 0x18(0x18)
	struct FSoftObjectPath Spell2; // 0x30(0x18)
};

// ScriptStruct LineageR.LMRWeaponContainer
// Size: 0x30 (Inherited: 0x00)
struct FLMRWeaponContainer {
	struct FSoftObjectPath Weapon; // 0x00(0x18)
	struct FSoftObjectPath AttackType; // 0x18(0x18)
};

// ScriptStruct LineageR.LMRDynamicParameterContainer
// Size: 0x50 (Inherited: 0x00)
struct FLMRDynamicParameterContainer {
	struct TMap<enum class ELMRClassType, struct FSoftObjectPath> CameraSequences; // 0x00(0x50)
};

// ScriptStruct LineageR.LMRLevelSequenceContainer
// Size: 0x10 (Inherited: 0x00)
struct FLMRLevelSequenceContainer {
	struct TArray<struct FLMRLevelSequenceData> LevelSequenceDatas; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRLevelSequenceData
// Size: 0x20 (Inherited: 0x00)
struct FLMRLevelSequenceData {
	bool bInteraction; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FSoftObjectPath Path; // 0x08(0x18)
};

// ScriptStruct LineageR.LMRLocalizationTarget
// Size: 0x18 (Inherited: 0x00)
struct FLMRLocalizationTarget {
	enum class ELMRLocalizationDataType DataType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FDirectoryPath> Paths; // 0x08(0x10)
};

// ScriptStruct LineageR.LMRParamData
// Size: 0x10 (Inherited: 0x00)
struct FLMRParamData {
	char pad_0[0x8]; // 0x00(0x08)
	struct FName ParamName; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRVectorParamData
// Size: 0x20 (Inherited: 0x10)
struct FLMRVectorParamData : FLMRParamData {
	struct FVector Param; // 0x10(0x0c)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct LineageR.LMRFloatParamData
// Size: 0x18 (Inherited: 0x10)
struct FLMRFloatParamData : FLMRParamData {
	float Param; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRMediaPlayInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRMediaPlayInfo {
	struct UMediaSource* mediaSource_; // 0x00(0x08)
	char pad_8[0x8]; // 0x08(0x08)
};

// ScriptStruct LineageR.LMRMonsterMusicTableRow
// Size: 0x38 (Inherited: 0x08)
struct FLMRMonsterMusicTableRow : FTableRowBase {
	struct TSoftObjectPtr<ULMRMusic> MonsterMusicEvent; // 0x08(0x28)
	float Radius; // 0x30(0x04)
	float DeactivateRangeRadiusOffset; // 0x34(0x04)
};

// ScriptStruct LineageR.LMRMoodMusicTableRow
// Size: 0x80 (Inherited: 0x08)
struct FLMRMoodMusicTableRow : FTableRowBase {
	struct TSoftObjectPtr<UAkAudioEvent> MoodMusicEventToPlay; // 0x08(0x28)
	struct TSoftObjectPtr<UAkAudioEvent> MoodMusicEventToStop; // 0x30(0x28)
	struct TSoftObjectPtr<ULMRMusic> MoodMusicEvent; // 0x58(0x28)
};

// ScriptStruct LineageR.LMRLobbyServerInfoTableRow
// Size: 0x38 (Inherited: 0x08)
struct FLMRLobbyServerInfoTableRow : FTableRowBase {
	struct FString ServerAddress; // 0x08(0x10)
	int32_t ServerPort; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct FString APIServerAddressAndPort; // 0x20(0x10)
	enum class ELMRNPNetCode NPNetCode; // 0x30(0x01)
	bool ShowServerName; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
};

// ScriptStruct LineageR.LMRObjectInitializeParameters
// Size: 0x02 (Inherited: 0x00)
struct FLMRObjectInitializeParameters {
	bool IsPlayer; // 0x00(0x01)
	bool IsBackgroundObject; // 0x01(0x01)
};

// ScriptStruct LineageR.LMRState
// Size: 0x48 (Inherited: 0x00)
struct FLMRState {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct LineageR.LMRSoundPackDataTable
// Size: 0x20 (Inherited: 0x08)
struct FLMRSoundPackDataTable : FTableRowBase {
	struct FSoftObjectPath SoundAsset; // 0x08(0x18)
};

// ScriptStruct LineageR.LMRPackagingTargetDataTable
// Size: 0x10 (Inherited: 0x08)
struct FLMRPackagingTargetDataTable : FTableRowBase {
	enum class ELMRPackagingTargetType Type; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};

// ScriptStruct LineageR.LMRParticleAssetTable
// Size: 0x40 (Inherited: 0x08)
struct FLMRParticleAssetTable : FTableRowBase {
	int32_t ID; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString TargetUIPath; // 0x10(0x10)
	int32_t SizeX; // 0x20(0x04)
	int32_t SizeY; // 0x24(0x04)
	int32_t PositionX; // 0x28(0x04)
	int32_t PositionY; // 0x2c(0x04)
	bool KillOnEnd; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	int32_t FXScale; // 0x34(0x04)
	bool ClipToBound; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

// ScriptStruct LineageR.LMRPlayerLocationParameter
// Size: 0x28 (Inherited: 0x00)
struct FLMRPlayerLocationParameter {
	struct UMaterialParameterCollection* PlayerLocationParameterCollection; // 0x00(0x08)
	struct FName ParameterName; // 0x08(0x08)
	float ToleranceDistance; // 0x10(0x04)
	float UpdateInterval; // 0x14(0x04)
	float UpdateAmbientSoundInterval; // 0x18(0x04)
	float UpdateMonsterMusicInterval; // 0x1c(0x04)
	float UpdateHideableStaticMeshActorsInterval; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct LineageR.LMRPPVCharacterEmissiveConfig
// Size: 0x3f0 (Inherited: 0x00)
struct FLMRPPVCharacterEmissiveConfig {
	bool IsOverrideEmissiveContrastCurve; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FRuntimeFloatCurve EmissiveContrastCurve; // 0x08(0x88)
	bool IsOverrideEmissiveOffsetCurve; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FRuntimeFloatCurve EmissiveOffsetCurve; // 0x98(0x88)
	bool IsOverrideEmissiveIntensityCurve; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
	struct FRuntimeFloatCurve EmissiveIntensityCurve; // 0x128(0x88)
	bool IsOverrideCharPosEmissiveOffsetCurve; // 0x1b0(0x01)
	char pad_1B1[0x7]; // 0x1b1(0x07)
	struct FRuntimeFloatCurve CharPosEmissiveOffsetCurve; // 0x1b8(0x88)
	bool IsOverrideCharPosEmissiveIntensityCurve; // 0x240(0x01)
	char pad_241[0x7]; // 0x241(0x07)
	struct FRuntimeFloatCurve CharPosEmissiveIntensityCurve; // 0x248(0x88)
	bool IsOverrideCameraDirEmissiveOffsetCurve; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct FRuntimeFloatCurve CameraDirEmissiveOffsetCurve; // 0x2d8(0x88)
	bool IsOverrideCameraDirEmissiveIntensityCurve; // 0x360(0x01)
	char pad_361[0x7]; // 0x361(0x07)
	struct FRuntimeFloatCurve CameraDirEmissiveIntensityCurve; // 0x368(0x88)
};

// ScriptStruct LineageR.LMRPPVDayNightSceneConfig
// Size: 0x100 (Inherited: 0x00)
struct FLMRPPVDayNightSceneConfig {
	bool IsOverrideDayBottomAddColor; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FLinearColor DayBottomAddColor; // 0x04(0x10)
	bool IsOverrideDayBottomMultiplyColor; // 0x14(0x01)
	char pad_15[0x3]; // 0x15(0x03)
	struct FLinearColor DayBottomMultiplyColor; // 0x18(0x10)
	bool IsOverrideDayDarkColor; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	struct FLinearColor DayDarkColor; // 0x2c(0x10)
	bool IsOverrideDayDarkDesaturation; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	float DayDarkDesaturation; // 0x40(0x04)
	bool IsOverrideDayLightingColor; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	struct FLinearColor DayLightingColor; // 0x48(0x10)
	bool IsOverrideDayLightingDesaturation; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	float DayLightingDesaturation; // 0x5c(0x04)
	bool IsOverrideDayMaskSize; // 0x60(0x01)
	char pad_61[0x3]; // 0x61(0x03)
	float DayMaskSize; // 0x64(0x04)
	bool IsOverrideDownMaskContrast; // 0x68(0x01)
	char pad_69[0x3]; // 0x69(0x03)
	float DownMaskContrast; // 0x6c(0x04)
	bool IsOverrideDownMaskOffset; // 0x70(0x01)
	char pad_71[0x3]; // 0x71(0x03)
	float DownMaskOffset; // 0x74(0x04)
	bool IsOverrideNightBottomAddColor; // 0x78(0x01)
	char pad_79[0x3]; // 0x79(0x03)
	struct FLinearColor NightBottomAddColor; // 0x7c(0x10)
	bool IsOverrideNightBottomMultiplyColor; // 0x8c(0x01)
	char pad_8D[0x3]; // 0x8d(0x03)
	struct FLinearColor NightBottomMultiplyColor; // 0x90(0x10)
	bool IsOverrideNightDarkColor; // 0xa0(0x01)
	char pad_A1[0x3]; // 0xa1(0x03)
	struct FLinearColor NightDarkColor; // 0xa4(0x10)
	bool IsOverrideNightDarkDesaturation; // 0xb4(0x01)
	char pad_B5[0x3]; // 0xb5(0x03)
	float NightDarkDesaturation; // 0xb8(0x04)
	bool IsOverrideNightLightingColor; // 0xbc(0x01)
	char pad_BD[0x3]; // 0xbd(0x03)
	struct FLinearColor NightLightingColor; // 0xc0(0x10)
	bool IsOverrideNightLightingDesaturation; // 0xd0(0x01)
	char pad_D1[0x3]; // 0xd1(0x03)
	float NightLightingDesaturation; // 0xd4(0x04)
	bool IsOverrideNightMaskSize; // 0xd8(0x01)
	char pad_D9[0x3]; // 0xd9(0x03)
	float NightMaskSize; // 0xdc(0x04)
	bool IsOverrideClampHighlightScale; // 0xe0(0x01)
	char pad_E1[0x3]; // 0xe1(0x03)
	float ClampHighlightScale; // 0xe4(0x04)
	bool IsOverrideClampHighlightValue; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	float ClampHighlightValue; // 0xec(0x04)
	bool IsOverrideSharpenDarkWeight; // 0xf0(0x01)
	char pad_F1[0x3]; // 0xf1(0x03)
	float SharpenDarkWeight; // 0xf4(0x04)
	bool IsOverrideSharpenLightWeight; // 0xf8(0x01)
	char pad_F9[0x3]; // 0xf9(0x03)
	float SharpenLightWeight; // 0xfc(0x04)
};

// ScriptStruct LineageR.LMRPPVSkyLightConfig
// Size: 0x2b8 (Inherited: 0x00)
struct FLMRPPVSkyLightConfig {
	LazyObjectProperty WorldSkyLight; // 0x00(0x1c)
	bool IsOverrideIntensityCurve; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	struct FRuntimeFloatCurve SkyLightIntensityCurve; // 0x20(0x88)
	bool IsOverrideColorCurve; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FRuntimeCurveLinearColor SkyLightColorCurve; // 0xb0(0x208)
};

// ScriptStruct LineageR.LMRPPVExponentialHeightFogConfig
// Size: 0x798 (Inherited: 0x00)
struct FLMRPPVExponentialHeightFogConfig {
	LazyObjectProperty WorldExponentialHeightFog; // 0x00(0x1c)
	bool IsOverrideDensityCurve; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	struct FRuntimeFloatCurve DensityCurve; // 0x20(0x88)
	bool IsOverrideHeightFalloffCurve; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FRuntimeFloatCurve HeightFalloffCurve; // 0xb0(0x88)
	bool IsOverrideInscatteringColorCurve; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
	struct FRuntimeCurveLinearColor InscatteringColorCurve; // 0x140(0x208)
	bool IsOverrideMaxOpacityCurve; // 0x348(0x01)
	char pad_349[0x7]; // 0x349(0x07)
	struct FRuntimeFloatCurve MaxOpacityCurve; // 0x350(0x88)
	bool IsOverrideStartDistanceCurve; // 0x3d8(0x01)
	char pad_3D9[0x7]; // 0x3d9(0x07)
	struct FRuntimeFloatCurve StartDistanceCurve; // 0x3e0(0x88)
	bool IsOverrideDirectionalInscatteringExponentCurve; // 0x468(0x01)
	char pad_469[0x7]; // 0x469(0x07)
	struct FRuntimeFloatCurve DirectionalInscatteringExponentCurve; // 0x470(0x88)
	bool IsOverrideDirectionalInscatteringStartDistanceCurve; // 0x4f8(0x01)
	char pad_4F9[0x7]; // 0x4f9(0x07)
	struct FRuntimeFloatCurve DirectionalInscatteringStartDistanceCurve; // 0x500(0x88)
	bool IsOverrideDirectionalInscatteringColorCurve; // 0x588(0x01)
	char pad_589[0x7]; // 0x589(0x07)
	struct FRuntimeCurveLinearColor DirectionalInscatteringColorCurve; // 0x590(0x208)
};

// ScriptStruct LineageR.LMRPPVDirectionalLightConfig
// Size: 0x470 (Inherited: 0x00)
struct FLMRPPVDirectionalLightConfig {
	LazyObjectProperty WorldDirectionalLight; // 0x00(0x1c)
	bool IsOverrideIntensityCurve; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	struct FRuntimeFloatCurve IntensityCurve; // 0x20(0x88)
	bool IsOverrideColorCurve; // 0xa8(0x01)
	char pad_A9[0x7]; // 0xa9(0x07)
	struct FRuntimeCurveLinearColor ColorCurve; // 0xb0(0x208)
	bool IsOverrideRotationCurve; // 0x2b8(0x01)
	char pad_2B9[0x7]; // 0x2b9(0x07)
	struct FLMRPPVRotationCurveInfo RotationCurve; // 0x2c0(0x1b0)
};

// ScriptStruct LineageR.LMRPPVRotationCurveInfo
// Size: 0x1b0 (Inherited: 0x00)
struct FLMRPPVRotationCurveInfo {
	bool IsOverrideYaw; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct FRuntimeFloatCurve RotationYawCurve; // 0x08(0x88)
	bool IsOverridePitch; // 0x90(0x01)
	char pad_91[0x7]; // 0x91(0x07)
	struct FRuntimeFloatCurve RotationPitchCurve; // 0x98(0x88)
	bool IsOverrideRoll; // 0x120(0x01)
	char pad_121[0x7]; // 0x121(0x07)
	struct FRuntimeFloatCurve RotationRollCurve; // 0x128(0x88)
};

// ScriptStruct LineageR.LMRProtoData
// Size: 0x10 (Inherited: 0x00)
struct FLMRProtoData {
	struct TArray<char> BinaryDatas; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRQuestDecoActorConfig
// Size: 0x18 (Inherited: 0x00)
struct FLMRQuestDecoActorConfig {
	struct TArray<struct FName> FixedActorLayers; // 0x00(0x10)
	int32_t PostProcessVolumeIndex; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRQuestMusicTableRow
// Size: 0x08 (Inherited: 0x08)
struct FLMRQuestMusicTableRow : FTableRowBase {
};

// ScriptStruct LineageR.LMRQuestObjectSpawnTable
// Size: 0x10 (Inherited: 0x08)
struct FLMRQuestObjectSpawnTable : FTableRowBase {
	bool IsHiddenAtSpawn; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
};

// ScriptStruct LineageR.LMRSoftObjectPathTable
// Size: 0x28 (Inherited: 0x08)
struct FLMRSoftObjectPathTable : FTableRowBase {
	struct FSoftObjectPath ResourcePath; // 0x08(0x18)
	bool IsGeneratedClass; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
};

// ScriptStruct LineageR.LMRStandaloneGameStateDataTable
// Size: 0x38 (Inherited: 0x08)
struct FLMRStandaloneGameStateDataTable : FTableRowBase {
	enum class ELMRGameStateType GameStateType; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct TSoftClassPtr<UObject> GameStateBlueprint; // 0x10(0x28)
};

// ScriptStruct LineageR.LMRLandMarkWidgetOption
// Size: 0x04 (Inherited: 0x00)
struct FLMRLandMarkWidgetOption {
	int32_t DescID; // 0x00(0x04)
};

// ScriptStruct LineageR.LMRSubtitleCharacterDialogVisibleOption
// Size: 0x0c (Inherited: 0x00)
struct FLMRSubtitleCharacterDialogVisibleOption {
	int32_t CharacterDialogIndex; // 0x00(0x04)
	int32_t Sequence; // 0x04(0x04)
	bool PauseCutscene; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct LineageR.LMRSubtitleSpeechBubbleInvisibleOption
// Size: 0x01 (Inherited: 0x00)
struct FLMRSubtitleSpeechBubbleInvisibleOption {
	char pad_0[0x1]; // 0x00(0x01)
};

// ScriptStruct LineageR.LMRSubtitleSpeechBubbleVisibleOption
// Size: 0x0c (Inherited: 0x00)
struct FLMRSubtitleSpeechBubbleVisibleOption {
	int32_t DescID; // 0x00(0x04)
	float DisplayTimePerCharacter; // 0x04(0x04)
	enum class ELMRScreenWidgetTargetType WigetTargetType; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
};

// ScriptStruct LineageR.LMRSubtitleInvisibleOption
// Size: 0x08 (Inherited: 0x00)
struct FLMRSubtitleInvisibleOption {
	int32_t SubtitleId; // 0x00(0x04)
	float FadeOutTime; // 0x04(0x04)
};

// ScriptStruct LineageR.LMRSubtitleVisibleOption
// Size: 0x28 (Inherited: 0x00)
struct FLMRSubtitleVisibleOption {
	int32_t SubtitleId; // 0x00(0x04)
	struct FVector2D Alignment; // 0x04(0x08)
	float FadeInTime; // 0x0c(0x04)
	int32_t SubtitleDescId; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct UDataTable* TextStyleSet; // 0x18(0x08)
	float DisplayTimePerCharacter; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
};

// ScriptStruct LineageR.LMRMagicDollDialogSaveData
// Size: 0x28 (Inherited: 0x00)
struct FLMRMagicDollDialogSaveData {
	bool Played; // 0x00(0x01)
	bool Achieved; // 0x01(0x01)
	char pad_2[0x6]; // 0x02(0x06)
	struct FString UniqueKey; // 0x08(0x10)
	struct FString ExtraInfos; // 0x18(0x10)
};

// ScriptStruct LineageR.LMRAITerritorySaveData
// Size: 0xa0 (Inherited: 0x00)
struct FLMRAITerritorySaveData {
	struct TSet<int32_t> CheckedTerritoryIds; // 0x00(0x50)
	struct TMap<int32_t, int32_t> ExplorationData; // 0x50(0x50)
};

// ScriptStruct LineageR.LMRCameraModeStateParameters
// Size: 0x24 (Inherited: 0x00)
struct FLMRCameraModeStateParameters {
	enum class FLMRCameraModePriority Priority; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float FOV; // 0x04(0x04)
	float Yaw; // 0x08(0x04)
	float Pitch; // 0x0c(0x04)
	float Distance; // 0x10(0x04)
	float BlendingTime; // 0x14(0x04)
	struct FVector TargetOffset; // 0x18(0x0c)
};

// ScriptStruct LineageR.LMRCameraModeParameters
// Size: 0x40 (Inherited: 0x00)
struct FLMRCameraModeParameters {
	float FOV; // 0x00(0x04)
	float Yaw; // 0x04(0x04)
	float Pitch; // 0x08(0x04)
	float MinDistance; // 0x0c(0x04)
	float MaxDistance; // 0x10(0x04)
	struct FVector TargetOffset; // 0x14(0x0c)
	float BlendingTime; // 0x20(0x04)
	enum class ELMRBlendViewTargetType Target_CharacterType; // 0x24(0x01)
	char pad_25[0x3]; // 0x25(0x03)
	int32_t Target_CharacterClassID; // 0x28(0x04)
	struct FVector Position; // 0x2c(0x0c)
	float FocalRegion; // 0x38(0x04)
	float FocalDistance; // 0x3c(0x04)
};

// ScriptStruct LineageR.LMRInAppsMission
// Size: 0x10 (Inherited: 0x00)
struct FLMRInAppsMission {
	struct TArray<struct FLMRInAppsMissionActivateInfos> events; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRInAppsMissionActivateInfos
// Size: 0x10 (Inherited: 0x00)
struct FLMRInAppsMissionActivateInfos {
	struct TArray<struct FLMRInAppsMissionActivateInfo> missions; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRInAppsMissionActivateInfo
// Size: 0x18 (Inherited: 0x00)
struct FLMRInAppsMissionActivateInfo {
	struct FString mission_id; // 0x00(0x10)
	bool is_active; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct LineageR.LMRInAppsStepUpInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRInAppsStepUpInfo {
	struct TArray<struct FLMRInAppsStepUpGoodsInfo> goods_list; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRInAppsStepUpGoodsInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRInAppsStepUpGoodsInfo {
	struct TArray<struct FLMRInAppsStepUpPgInfo> pgs; // 0x00(0x10)
	struct TArray<struct FLMRInAppsStepUpMissionInfo> goods_missions; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRInAppsStepUpMissionInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRInAppsStepUpMissionInfo {
	struct FString event_id; // 0x00(0x10)
	struct FString mission_id; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRInAppsStepUpPgInfo
// Size: 0x18 (Inherited: 0x00)
struct FLMRInAppsStepUpPgInfo {
	int32_t pg_id; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString pg_goods_key; // 0x08(0x10)
};

// ScriptStruct LineageR.LMRJpCountryPaymentLimit
// Size: 0x28 (Inherited: 0x00)
struct FLMRJpCountryPaymentLimit {
	int32_t order; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString display_text; // 0x08(0x10)
	struct FString limit; // 0x18(0x10)
};

// ScriptStruct LineageR.LMRSignPostInfo
// Size: 0x50 (Inherited: 0x00)
struct FLMRSignPostInfo {
	struct TMap<struct FString, int32_t> MapSignPostName; // 0x00(0x50)
};

// ScriptStruct LineageR.LMRIllusBottomEffectData
// Size: 0x20 (Inherited: 0x00)
struct FLMRIllusBottomEffectData {
	struct TArray<struct FName> SpawnEffectNames; // 0x00(0x10)
	struct TArray<struct FSoftObjectPath> SpawnDecals; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRPrimaryAssetContainer
// Size: 0x50 (Inherited: 0x00)
struct FLMRPrimaryAssetContainer {
	struct TArray<struct FLMRPrimaryAssetTypeInfo> ScanAssets; // 0x00(0x10)
	struct FSoftObjectPath ScanPackagingTargetDataTable; // 0x10(0x18)
	struct FSoftObjectPath ScanCustomPackagingTargetDataTable; // 0x28(0x18)
	struct TArray<struct FDirectoryPath> NonAssetPaths; // 0x40(0x10)
};

// ScriptStruct LineageR.LMRPrimaryAssetTypeInfo
// Size: 0x70 (Inherited: 0x00)
struct FLMRPrimaryAssetTypeInfo {
	struct FName PrimaryAssetType; // 0x00(0x08)
	struct TSoftClassPtr<UObject> AssetBaseClass; // 0x08(0x28)
	bool bHasBlueprintClasses; // 0x30(0x01)
	bool bIsEditorOnly; // 0x31(0x01)
	char pad_32[0x6]; // 0x32(0x06)
	struct TArray<struct FDirectoryPath> Directories; // 0x38(0x10)
	struct TArray<struct FLMRPreloadAssetTypePath> SpecificAssets; // 0x48(0x10)
	struct FPrimaryAssetRules Rules; // 0x58(0x0c)
	bool bIsDynamicAsset; // 0x64(0x01)
	char pad_65[0x3]; // 0x65(0x03)
	int32_t NumberOfAssets; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// ScriptStruct LineageR.LMRCutscenePlaybackSetting
// Size: 0x100 (Inherited: 0x14)
struct FLMRCutscenePlaybackSetting : FMovieSceneSequencePlaybackSettings {
	char pad_14[0xec]; // 0x14(0xec)
};

// ScriptStruct LineageR.LMRViewTargetParams
// Size: 0x10 (Inherited: 0x00)
struct FLMRViewTargetParams {
	struct FViewTargetTransitionParams BlendParams; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRFXDecoMgr
// Size: 0x28 (Inherited: 0x00)
struct FLMRFXDecoMgr {
	char pad_0[0x28]; // 0x00(0x28)
};

// ScriptStruct LineageR.LMRFXParameters
// Size: 0xa8 (Inherited: 0x00)
struct FLMRFXParameters {
	bool UseRelativeOffset; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FVector RelativeOffset; // 0x04(0x0c)
	bool UseWorldLocation; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	struct FVector OverrideWorldLocation; // 0x14(0x0c)
	struct FVector FireLocation; // 0x20(0x0c)
	bool UseOverrideScale; // 0x2c(0x01)
	char pad_2D[0x3]; // 0x2d(0x03)
	float OverrideScale; // 0x30(0x04)
	bool UseScaleFactor; // 0x34(0x01)
	char pad_35[0x3]; // 0x35(0x03)
	struct FRotator OverrideRotator; // 0x38(0x0c)
	bool UseRotatorFactor; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	struct FVector ScaleFactor; // 0x48(0x0c)
	float AnimRateScale; // 0x54(0x04)
	bool UseServerRotation; // 0x58(0x01)
	bool IgnoreOnwerVisibleCheck; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)
	struct ULMRSoundParameters* SoundParameters; // 0x60(0x08)
	char pad_68[0x40]; // 0x68(0x40)
};

// ScriptStruct LineageR.LMREnchantFxInfo
// Size: 0x40 (Inherited: 0x00)
struct FLMREnchantFxInfo {
	char pad_0[0x40]; // 0x00(0x40)
};

// ScriptStruct LineageR.LMREnchantMaterialEventInfo
// Size: 0x0c (Inherited: 0x00)
struct FLMREnchantMaterialEventInfo {
	char pad_0[0xc]; // 0x00(0x0c)
};

// ScriptStruct LineageR.LMREnchantMovementInfo
// Size: 0x08 (Inherited: 0x00)
struct FLMREnchantMovementInfo {
	char pad_0[0x8]; // 0x00(0x08)
};

// ScriptStruct LineageR.LMREnchantTouchTrackerInfo
// Size: 0x40 (Inherited: 0x00)
struct FLMREnchantTouchTrackerInfo {
	int32_t EnchantGroupId; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct UCurveVector* SplineAsset; // 0x08(0x08)
	struct FName ParticleName; // 0x10(0x08)
	struct FName SourceSocketName; // 0x18(0x08)
	struct FName TargetSocketName; // 0x20(0x08)
	struct FVector SourceOffsetPosition; // 0x28(0x0c)
	struct FVector TargetOffsetPosition; // 0x34(0x0c)
};

// ScriptStruct LineageR.LMREnchantTouchRandomFxInfo
// Size: 0x0c (Inherited: 0x00)
struct FLMREnchantTouchRandomFxInfo {
	enum class ELMREnchantObjecType SourceType; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	struct FName ParticleName; // 0x04(0x08)
};

// ScriptStruct LineageR.LMREnchantFxEventBaseInfo
// Size: 0x30 (Inherited: 0x00)
struct FLMREnchantFxEventBaseInfo {
	int32_t EnchantGroupId; // 0x00(0x04)
	enum class ELMREnchantObjecType SourceType; // 0x04(0x01)
	char pad_5[0x3]; // 0x05(0x03)
	struct FName ParticleName; // 0x08(0x08)
	struct FName ParamValueName; // 0x10(0x08)
	float Value; // 0x18(0x04)
	struct FName SourceSocketName; // 0x1c(0x08)
	struct FVector SourceOffsetPosition; // 0x24(0x0c)
};

// ScriptStruct LineageR.LMRExponentialHeightFogParameters
// Size: 0x20 (Inherited: 0x00)
struct FLMRExponentialHeightFogParameters {
	float BlendDuration; // 0x00(0x04)
	float FogDensity; // 0x04(0x04)
	struct FLinearColor FogInscatteringColor; // 0x08(0x10)
	float FogHeightFalloff; // 0x18(0x04)
	float FogMaxOpacity; // 0x1c(0x04)
};

// ScriptStruct LineageR.LMRTimeOfDayDayNightOverrideParameters
// Size: 0x34 (Inherited: 0x00)
struct FLMRTimeOfDayDayNightOverrideParameters {
	struct FLMRTimeOfDayOverrideParameters DayParams; // 0x00(0x18)
	struct FLMRTimeOfDayOverrideParameters NightParams; // 0x18(0x18)
	float BlendDuration; // 0x30(0x04)
};

// ScriptStruct LineageR.LMRTimeOfDayOverrideParameters
// Size: 0x18 (Inherited: 0x00)
struct FLMRTimeOfDayOverrideParameters {
	float DirectionalLightIntensityMultiplier; // 0x00(0x04)
	bool IsOverrideNightLightVisibility; // 0x04(0x01)
	bool IsVisibleNightLight; // 0x05(0x01)
	bool IsOverride_VignetteIntensity; // 0x06(0x01)
	char pad_7[0x1]; // 0x07(0x01)
	float VignetteIntensity; // 0x08(0x04)
	float VignetteLightBonusIntensity; // 0x0c(0x04)
	bool IsOverride_AutoExposureBias; // 0x10(0x01)
	char pad_11[0x3]; // 0x11(0x03)
	float AutoExposureBias; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRTimeOfDayParameters
// Size: 0x48 (Inherited: 0x00)
struct FLMRTimeOfDayParameters {
	struct UCurveLinearColor* ColorCurveOfDay; // 0x00(0x08)
	struct TArray<struct FLMREnvironmentScalarParameter> WeatherParameters; // 0x08(0x10)
	struct TArray<struct FLMREnvironmentScalarParameter> DayParameters; // 0x18(0x10)
	struct TArray<struct FLMREnvironmentScalarParameter> NightParameters; // 0x28(0x10)
	struct UParticleSystem* CameraParticleTemplate; // 0x38(0x08)
	float CameraParticleWeatherScale; // 0x40(0x04)
	char pad_44[0x4]; // 0x44(0x04)
};

// ScriptStruct LineageR.LMREnvironmentScalarParameter
// Size: 0x20 (Inherited: 0x00)
struct FLMREnvironmentScalarParameter {
	struct UMaterialParameterCollection* TODParameterCollection; // 0x00(0x08)
	struct FName ParameterName; // 0x08(0x08)
	float ActivatedValue; // 0x10(0x04)
	float DeactivatedValue; // 0x14(0x04)
	char pad_18[0x8]; // 0x18(0x08)
};

// ScriptStruct LineageR.LMRDungeonEnvironmentParameters
// Size: 0x10 (Inherited: 0x00)
struct FLMRDungeonEnvironmentParameters {
	struct TArray<struct FLMREnvironmentScalarParameter> ScalarParameters; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRTimeOfDaySpec
// Size: 0x08 (Inherited: 0x00)
struct FLMRTimeOfDaySpec {
	enum class ELMRWeatherType Weather; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Value; // 0x04(0x04)
};

// ScriptStruct LineageR.LMRMaterialScalarParameterCollection
// Size: 0x18 (Inherited: 0x00)
struct FLMRMaterialScalarParameterCollection {
	struct UMaterialParameterCollection* ParameterCollection; // 0x00(0x08)
	struct FName ParameterName; // 0x08(0x08)
	float ActivatedValue; // 0x10(0x04)
	float DeactivatedValue; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRItemTradeItemSetSalesInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRItemTradeItemSetSalesInfo {
	struct TArray<struct FLMRItemTradeItemInfo> list; // 0x00(0x10)
	char pad_10[0x10]; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRItemTradeItemInfo
// Size: 0x78 (Inherited: 0x00)
struct FLMRItemTradeItemInfo {
	bool is_set_item; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	int32_t game_item_key; // 0x04(0x04)
	int32_t game_item_category_id; // 0x08(0x04)
	int32_t game_item_grade_id; // 0x0c(0x04)
	uint64_t game_item_quantity; // 0x10(0x08)
	struct FString display_data; // 0x18(0x10)
	struct TArray<struct FLMRItemTradeGameItemSearchCondition> game_item_conditions; // 0x28(0x10)
	char pad_38[0x40]; // 0x38(0x40)
};

// ScriptStruct LineageR.LMRItemTradeGameItemSearchCondition
// Size: 0x18 (Inherited: 0x00)
struct FLMRItemTradeGameItemSearchCondition {
	struct FString Key; // 0x00(0x10)
	int32_t Value; // 0x10(0x04)
	int32_t Type; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRItemTradeSellItemDetailList
// Size: 0x90 (Inherited: 0x00)
struct FLMRItemTradeSellItemDetailList {
	bool has_next_page; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FLMRItemTradeSellItemDetailInfo> sales; // 0x08(0x10)
	struct FDateTime Loaded; // 0x18(0x08)
	char pad_20[0x70]; // 0x20(0x70)
};

// ScriptStruct LineageR.LMRItemTradeSellItemDetailInfo
// Size: 0xa0 (Inherited: 0x78)
struct FLMRItemTradeSellItemDetailInfo : FLMRItemTradeItemInfo {
	struct FString sale_id; // 0x78(0x10)
	uint64_t sale_price; // 0x88(0x08)
	float unit_price; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FDateTime effective_to; // 0x98(0x08)
};

// ScriptStruct LineageR.LMRItemTradeSellItemCategoryList
// Size: 0x38 (Inherited: 0x00)
struct FLMRItemTradeSellItemCategoryList {
	bool has_next_page; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FLMRItemTradeSellItemSummaryInfo> list; // 0x08(0x10)
	struct FDateTime Loaded; // 0x18(0x08)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct LineageR.LMRItemTradeSellItemSummaryInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRItemTradeSellItemSummaryInfo {
	int32_t game_item_key; // 0x00(0x04)
	uint32_t sale_count; // 0x04(0x04)
	float min_unit_price; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FLMRItemTradeGameItemSearchCondition> game_item_conditions; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRItemTradePriceInfo
// Size: 0x38 (Inherited: 0x00)
struct FLMRItemTradePriceInfo {
	uint64_t sale_count; // 0x00(0x08)
	float max_unit_price; // 0x08(0x04)
	float min_unit_price; // 0x0c(0x04)
	float average_unit_price; // 0x10(0x04)
	float latest_average_unit_price; // 0x14(0x04)
	struct FDateTime registered; // 0x18(0x08)
	char pad_20[0x18]; // 0x20(0x18)
};

// ScriptStruct LineageR.LMRItemTradeEarningInfo
// Size: 0x20 (Inherited: 0x00)
struct FLMRItemTradeEarningInfo {
	int32_t total_count; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	uint64_t sum_earnings; // 0x08(0x08)
	struct TArray<struct FLMRItemTradeDeliveryData> deliveries; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRItemTradeDeliveryData
// Size: 0xa0 (Inherited: 0x78)
struct FLMRItemTradeDeliveryData : FLMRItemTradeItemInfo {
	struct FString delivery_id; // 0x78(0x10)
	uint64_t sale_price; // 0x88(0x08)
	uint64_t earnings; // 0x90(0x08)
	struct FDateTime registered; // 0x98(0x08)
};

// ScriptStruct LineageR.LMRItemTradeMySellInfo
// Size: 0x38 (Inherited: 0x00)
struct FLMRItemTradeMySellInfo {
	uint64_t total_estimated_earnings; // 0x00(0x08)
	uint64_t total_sale_price; // 0x08(0x08)
	uint64_t source_total_sale_price; // 0x10(0x08)
	int32_t source_total_count; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
	struct TArray<struct FLMRItemTradeMySellItemInfo> sales; // 0x20(0x10)
	struct FDateTime Loaded; // 0x30(0x08)
};

// ScriptStruct LineageR.LMRItemTradeMySellItemInfo
// Size: 0xb0 (Inherited: 0x78)
struct FLMRItemTradeMySellItemInfo : FLMRItemTradeItemInfo {
	struct FString sale_id; // 0x78(0x10)
	uint64_t sale_price; // 0x88(0x08)
	float unit_price; // 0x90(0x04)
	char pad_94[0x4]; // 0x94(0x04)
	struct FDateTime effective_to; // 0x98(0x08)
	struct FDateTime effective_from; // 0xa0(0x08)
	int32_t sale_status; // 0xa8(0x04)
	char pad_AC[0x4]; // 0xac(0x04)
};

// ScriptStruct LineageR.LMRItemTradeGameItemSearchSort
// Size: 0x20 (Inherited: 0x00)
struct FLMRItemTradeGameItemSearchSort {
	struct FString Key; // 0x00(0x10)
	struct FString order_by; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRItemTradeGameItemSearchConditionType
// Size: 0x18 (Inherited: 0x00)
struct FLMRItemTradeGameItemSearchConditionType {
	struct FString Key; // 0x00(0x10)
	int32_t Type; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRItemTradeGameItemSearchConditionRange
// Size: 0x18 (Inherited: 0x00)
struct FLMRItemTradeGameItemSearchConditionRange {
	struct FString Key; // 0x00(0x10)
	int32_t From; // 0x10(0x04)
	int32_t To; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRItemTradeGameItemSearchConditionValue
// Size: 0x18 (Inherited: 0x00)
struct FLMRItemTradeGameItemSearchConditionValue {
	struct FString Key; // 0x00(0x10)
	int32_t Value; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct LineageR.LMRItemTradeFavorites
// Size: 0x10 (Inherited: 0x00)
struct FLMRItemTradeFavorites {
	struct TArray<struct FLMRItemTradeGameItemKey> list; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRItemTradeGameItemKey
// Size: 0x04 (Inherited: 0x00)
struct FLMRItemTradeGameItemKey {
	int32_t game_item_key; // 0x00(0x04)
};

// ScriptStruct LineageR.LMRItemTradePolicy
// Size: 0x30 (Inherited: 0x00)
struct FLMRItemTradePolicy {
	struct FLMRItemTradePolicySalesLimit sales_limit; // 0x00(0x08)
	struct TArray<struct FLMRItemTradePolicyFee> fee; // 0x08(0x10)
	struct TArray<struct FLMRItemTradeGameItemKey> blocked_game_items; // 0x18(0x10)
	struct FDateTime Loaded; // 0x28(0x08)
};

// ScriptStruct LineageR.LMRItemTradePolicyFee
// Size: 0x0c (Inherited: 0x00)
struct FLMRItemTradePolicyFee {
	int32_t fee_rate; // 0x00(0x04)
	int32_t fee_type; // 0x04(0x04)
	int32_t min_fee; // 0x08(0x04)
};

// ScriptStruct LineageR.LMRItemTradePolicySalesLimit
// Size: 0x08 (Inherited: 0x00)
struct FLMRItemTradePolicySalesLimit {
	int32_t per_server; // 0x00(0x04)
	int32_t per_char_key; // 0x04(0x04)
};

// ScriptStruct LineageR.LMRObjectMaterialSwapSpec
// Size: 0x18 (Inherited: 0x00)
struct FLMRObjectMaterialSwapSpec {
	bool HasDisappearEffectWhenDead; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float DelayDisappearEffectWhenDead; // 0x04(0x04)
	char pad_8[0x10]; // 0x08(0x10)
};

// ScriptStruct LineageR.LMRRequestObjectMaterialSwapParams
// Size: 0x2c (Inherited: 0x00)
struct FLMRRequestObjectMaterialSwapParams {
	enum class ELMRObjectMaterialSwapType Type; // 0x00(0x01)
	enum class ELMRFXSoundType SoundType; // 0x01(0x01)
	bool IsOverride_ParamName; // 0x02(0x01)
	char pad_3[0x1]; // 0x03(0x01)
	struct FName OverrideParamName; // 0x04(0x08)
	bool IsOverride_BlendScalar; // 0x0c(0x01)
	char pad_D[0x3]; // 0x0d(0x03)
	float OverrideBlendInScalar; // 0x10(0x04)
	float OverrideBlendOutScalar; // 0x14(0x04)
	bool IsOverride_Duration; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float Duration; // 0x1c(0x04)
	bool IsReverse; // 0x20(0x01)
	bool IsResotreBaseMaterialAtEnd; // 0x21(0x01)
	char pad_22[0x2]; // 0x22(0x02)
	float StartRate; // 0x24(0x04)
	float Multiplier; // 0x28(0x04)
};

// ScriptStruct LineageR.LMRObjectMaterialSwapSource
// Size: 0xd8 (Inherited: 0x00)
struct FLMRObjectMaterialSwapSource {
	struct TArray<struct UMaterialInterface*> SwapMaterials; // 0x00(0x10)
	struct FName EffectName; // 0x10(0x08)
	struct FLMRMaterialSwapEffectSound SwapEffectSound; // 0x18(0x88)
	struct TArray<struct UMaterialSwapParticleSysParam*> ParticleSysParams; // 0xa0(0x10)
	struct FName ReverseEffectName; // 0xb0(0x08)
	struct TArray<struct UMaterialSwapParticleSysParam*> ReverseParticleSysParams; // 0xb8(0x10)
	bool UseCustomDuration; // 0xc8(0x01)
	char pad_C9[0x3]; // 0xc9(0x03)
	float Duration; // 0xcc(0x04)
	float ReversedDuration; // 0xd0(0x04)
	char pad_D4[0x4]; // 0xd4(0x04)
};

// ScriptStruct LineageR.LMRMaterialSwapEffectSound
// Size: 0x88 (Inherited: 0x00)
struct FLMRMaterialSwapEffectSound {
	struct FLMRMaterialSwapSound SwapInSound; // 0x00(0x20)
	struct FLMRMaterialSwapSound SwapOutSound; // 0x20(0x20)
	struct FLMRMaterialSwapSound ReverseSwapInSound; // 0x40(0x20)
	struct FLMRMaterialSwapSound ReverseSwapOutSound; // 0x60(0x20)
	char pad_80[0x8]; // 0x80(0x08)
};

// ScriptStruct LineageR.LMRMaterialSwapSound
// Size: 0x20 (Inherited: 0x00)
struct FLMRMaterialSwapSound {
	struct UAkAudioEvent* EffectSound; // 0x00(0x08)
	struct UAkAudioEvent* Effect3PSound; // 0x08(0x08)
	struct UAkAudioEvent* PlayBGM; // 0x10(0x08)
	struct UAkAudioEvent* StopBGM; // 0x18(0x08)
};

// ScriptStruct LineageR.PathFindingTestCase
// Size: 0x14 (Inherited: 0x00)
struct FPathFindingTestCase {
	int32_t Range; // 0x00(0x04)
	struct FIntPoint Start; // 0x04(0x08)
	struct FIntPoint End; // 0x0c(0x08)
};

// ScriptStruct LineageR.LMRPlatformErrorExtra
// Size: 0x04 (Inherited: 0x00)
struct FLMRPlatformErrorExtra {
	struct FLMRPlatformBanInfo ban; // 0x00(0x04)
};

// ScriptStruct LineageR.LMRPlatformBanInfo
// Size: 0x04 (Inherited: 0x00)
struct FLMRPlatformBanInfo {
	int32_t ban_reason_code; // 0x00(0x04)
};

// ScriptStruct LineageR.DeathPenaltyLostData
// Size: 0x50 (Inherited: 0x00)
struct FDeathPenaltyLostData {
	char pad_0[0x50]; // 0x00(0x50)
};

// ScriptStruct LineageR.LMRSearchHistoryInfo
// Size: 0x10 (Inherited: 0x00)
struct FLMRSearchHistoryInfo {
	struct TArray<struct FLMRSearchHistoryData> Datas; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRSearchHistoryData
// Size: 0x18 (Inherited: 0x00)
struct FLMRSearchHistoryData {
	struct FString SearchString; // 0x00(0x10)
	bool PerfectMatch; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct LineageR.LMRSocketBonusTextInfo
// Size: 0x30 (Inherited: 0x00)
struct FLMRSocketBonusTextInfo {
	char pad_0[0x30]; // 0x00(0x30)
};

// ScriptStruct LineageR.LMRSoundBattleAutoVolumeSettings
// Size: 0x58 (Inherited: 0x00)
struct FLMRSoundBattleAutoVolumeSettings {
	struct TMap<enum class ELMRGameOptionType, int32_t> SoundVolumeOptions; // 0x00(0x50)
	int32_t SoundToneOptionIndex; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct LineageR.LMRVoiceSettings
// Size: 0x38 (Inherited: 0x00)
struct FLMRVoiceSettings {
	int32_t Index; // 0x00(0x04)
	int32_t UIMenuOrder; // 0x04(0x04)
	bool Enable; // 0x08(0x01)
	enum class ELMRLanguageType LanguageType; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FString WwiseCulture; // 0x10(0x10)
	struct FText WWiseCultureName; // 0x20(0x18)
};

// ScriptStruct LineageR.LMRObjectSoundSpec
// Size: 0x38 (Inherited: 0x00)
struct FLMRObjectSoundSpec {
	bool UseBodyFallSound; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TSoftObjectPtr<UAkAudioEvent> BodyFallSound; // 0x08(0x28)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct LineageR.LMRQuestMusicState
// Size: 0x58 (Inherited: 0x00)
struct FLMRQuestMusicState {
	char pad_0[0x58]; // 0x00(0x58)
};

// ScriptStruct LineageR.LMRMonsterBGMState
// Size: 0x38 (Inherited: 0x00)
struct FLMRMonsterBGMState {
	char pad_0[0x38]; // 0x00(0x38)
};

// ScriptStruct LineageR.LMRBGMState
// Size: 0x48 (Inherited: 0x00)
struct FLMRBGMState {
	char pad_0[0x48]; // 0x00(0x48)
};

// ScriptStruct LineageR.InfravisionColorData
// Size: 0x50 (Inherited: 0x00)
struct FInfravisionColorData {
	struct TMap<enum class ELMRInfravisionSelectType, struct FInfravisionColorParam> InfravisionColorData; // 0x00(0x50)
};

// ScriptStruct LineageR.InfravisionColorParam
// Size: 0x1c (Inherited: 0x00)
struct FInfravisionColorParam {
	int32_t custumDepth; // 0x00(0x04)
	struct FLinearColor materialColor; // 0x04(0x10)
	enum class ELMRClanDiplomacyType diplomacyType; // 0x14(0x01)
	char pad_15[0x7]; // 0x15(0x07)
};

// ScriptStruct LineageR.LMRWorldConditionPostProcessVolumeInfo
// Size: 0x58 (Inherited: 0x00)
struct FLMRWorldConditionPostProcessVolumeInfo {
	struct FName Comment; // 0x00(0x08)
	struct TSet<int32_t> VolumeSelections; // 0x08(0x50)
};

// ScriptStruct LineageR.LMRWorldConditionMPCGroupParameters
// Size: 0x18 (Inherited: 0x00)
struct FLMRWorldConditionMPCGroupParameters {
	struct UMaterialParameterCollection* Source; // 0x00(0x08)
	struct TArray<struct FLMRWorldConditionMPCGroupData> MPCGroupDataList; // 0x08(0x10)
};

// ScriptStruct LineageR.LMRWorldConditionMPCGroupData
// Size: 0x68 (Inherited: 0x00)
struct FLMRWorldConditionMPCGroupData {
	struct FName ParameterName; // 0x00(0x08)
	float BlendingTime; // 0x08(0x04)
	float BlendingTimeRate; // 0x0c(0x04)
	float DefaultValue; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
	struct TMap<int32_t, float> MapStateActivateValue; // 0x18(0x50)
};

// ScriptStruct LineageR.LMRWorldConditionMPCParameters
// Size: 0x04 (Inherited: 0x00)
struct FLMRWorldConditionMPCParameters {
	float Value; // 0x00(0x04)
};

// ScriptStruct LineageR.LMRPrecomputedLightingScenariosParameters
// Size: 0x50 (Inherited: 0x00)
struct FLMRPrecomputedLightingScenariosParameters {
	int32_t GroupIndex; // 0x00(0x04)
	float MaterialSwapAppearEffectDuration; // 0x04(0x04)
	float MaterialSwapDisappearEffectDuration; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct TArray<struct FLMRPrecomputedLightingScenarioParameters> ActivateList; // 0x10(0x10)
	struct FLMRPrecomputedLightingScenarioParameters DefaultActivate; // 0x20(0x30)
};

// ScriptStruct LineageR.LMRPrecomputedLightingScenarioParameters
// Size: 0x30 (Inherited: 0x00)
struct FLMRPrecomputedLightingScenarioParameters {
	int32_t StateID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UWorld> Sublevel; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRWorldConditionGroupParameters
// Size: 0x10 (Inherited: 0x00)
struct FLMRWorldConditionGroupParameters {
	struct TArray<struct FLMRWorldConditionGroupParameterData> GroupParameterData; // 0x00(0x10)
};

// ScriptStruct LineageR.LMRWorldConditionGroupParameterData
// Size: 0x58 (Inherited: 0x00)
struct FLMRWorldConditionGroupParameterData {
	int32_t StateID; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSet<struct FString> Activate; // 0x08(0x50)
};

// ScriptStruct LineageR.LMRWorldConditionTimelapseData
// Size: 0x08 (Inherited: 0x00)
struct FLMRWorldConditionTimelapseData {
	int32_t TimeToMaxProgress; // 0x00(0x04)
	float DegreeMaxProgress; // 0x04(0x04)
};

// ScriptStruct LineageR.LMRWorldConditionSpawnActorData
// Size: 0x18 (Inherited: 0x00)
struct FLMRWorldConditionSpawnActorData {
	struct FSoftObjectPath SpawnActorPath; // 0x00(0x18)
};

// ScriptStruct LineageR.LMRWorldConditionActorDataGroup
// Size: 0x28 (Inherited: 0x00)
struct FLMRWorldConditionActorDataGroup {
	enum class ELMRWorldConditionDisplayType DisplayType; // 0x00(0x01)
	char pad_1[0x7]; // 0x01(0x07)
	struct TArray<struct FLMRWorldConditionSpawnParameters> SpawnDataList; // 0x08(0x10)
	struct TArray<struct FName> FixedActorLayers; // 0x18(0x10)
};

// ScriptStruct LineageR.LMRWorldConditionSpawnParameters
// Size: 0x40 (Inherited: 0x00)
struct FLMRWorldConditionSpawnParameters {
	int32_t WorldConditionId; // 0x00(0x04)
	char pad_4[0xc]; // 0x04(0x0c)
	struct FTransform Transform; // 0x10(0x30)
};

// ScriptStruct LineageR.LMRWorldConditionSkeletalParameters
// Size: 0x1c (Inherited: 0x00)
struct FLMRWorldConditionSkeletalParameters {
	LazyObjectProperty Target; // 0x00(0x1c)
};

// ScriptStruct LineageR.UIColorData
// Size: 0x20 (Inherited: 0x08)
struct FUIColorData : FTableRowBase {
	struct FColor Color; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FString Desc; // 0x10(0x10)
};

// ScriptStruct LineageR.LMRUIEffectDataTable
// Size: 0x70 (Inherited: 0x08)
struct FLMRUIEffectDataTable : FTableRowBase {
	struct TSoftObjectPtr<UParticleSystem> ParticleSystem; // 0x08(0x28)
	bool UseClipping; // 0x30(0x01)
	char pad_31[0x3]; // 0x31(0x03)
	float ViewDistance; // 0x34(0x04)
	struct FString Memo; // 0x38(0x10)
	struct TSoftObjectPtr<UAkAudioEvent> SoundEvent; // 0x48(0x28)
};

// ScriptStruct LineageR.LMRUIEffectSoundTableRow
// Size: 0x30 (Inherited: 0x08)
struct FLMRUIEffectSoundTableRow : FTableRowBase {
	struct TSoftObjectPtr<UAkAudioEvent> UIEffectEventToPlay; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRGradeFXData
// Size: 0x30 (Inherited: 0x00)
struct FLMRGradeFXData {
	struct FColor FxColor; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UMaterialInstance> FxMaterial; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRUIMoodStateEventTableRow
// Size: 0x38 (Inherited: 0x08)
struct FLMRUIMoodStateEventTableRow : FTableRowBase {
	struct FSoftObjectPath UIClass; // 0x08(0x18)
	struct FSoftObjectPath MoodStateEvent; // 0x20(0x18)
};

// ScriptStruct LineageR.LMRUITagDataTable
// Size: 0x50 (Inherited: 0x20)
struct FLMRUITagDataTable : FGameplayTagTableRow {
	struct TSoftClassPtr<UObject> TargetWidgetClass; // 0x20(0x28)
	struct FName ParentTag; // 0x48(0x08)
};

// ScriptStruct LineageR.LMRDungeonCategoryIconInfo
// Size: 0x30 (Inherited: 0x00)
struct FLMRDungeonCategoryIconInfo {
	int32_t dungeonCategory; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TSoftObjectPtr<UTexture2D> Icon; // 0x08(0x28)
};

// ScriptStruct LineageR.LMRQuestIconInfo
// Size: 0x28 (Inherited: 0x00)
struct FLMRQuestIconInfo {
	struct TSoftObjectPtr<UTexture2D> MapQuestShortcutIcon; // 0x00(0x28)
};

// ScriptStruct LineageR.LMRRankingIconInfo
// Size: 0xf0 (Inherited: 0x00)
struct FLMRRankingIconInfo {
	struct TSoftObjectPtr<UTexture2D> New; // 0x00(0x28)
	struct TSoftObjectPtr<UTexture2D> Down; // 0x28(0x28)
	struct TSoftObjectPtr<UTexture2D> Up; // 0x50(0x28)
	struct TSoftObjectPtr<UTexture2D> Same; // 0x78(0x28)
	struct TMap<int32_t, struct TSoftObjectPtr<UTexture2D>> RankerIcons; // 0xa0(0x50)
};

// ScriptStruct LineageR.LMRWorldMapIconInfo
// Size: 0x78 (Inherited: 0x00)
struct FLMRWorldMapIconInfo {
	struct TMap<int32_t, struct TSoftObjectPtr<UTexture2D>> QuestOrderIcons; // 0x00(0x50)
	struct TSoftObjectPtr<UTexture2D> EmptySegmentIcon; // 0x50(0x28)
};

// ScriptStruct LineageR.LMRBattleFeildIconInfo
// Size: 0x140 (Inherited: 0x00)
struct FLMRBattleFeildIconInfo {
	struct TMap<enum class ELMRBattleFieldCommandType, struct TSoftObjectPtr<UTexture2D>> BattleFieldCommandIconType; // 0x00(0x50)
	struct TMap<enum class ELMRBattleFieldCommandType, struct TSoftObjectPtr<UTexture2D>> BattleFieldCommandMinimapIconType; // 0x50(0x50)
	struct TMap<int32_t, struct TSoftObjectPtr<UTexture2D>> BattleFieldCommandSquadIcons; // 0xa0(0x50)
	struct TMap<enum class ELMRClassType, struct TSoftObjectPtr<UTexture2D>> BattleFieldEnemyClassIconType; // 0xf0(0x50)
};

// ScriptStruct LineageR.LMRSpellIconInfo
// Size: 0xa0 (Inherited: 0x00)
struct FLMRSpellIconInfo {
	struct TMap<int32_t, struct TSoftObjectPtr<UTexture2D>> PolySpellIcons; // 0x00(0x50)
	struct TMap<enum class ELMRClassType, struct FLMRSpellDetailIconInfo> SpellDetailIcons; // 0x50(0x50)
};

// ScriptStruct LineageR.LMRSpellDetailIconInfo
// Size: 0x50 (Inherited: 0x00)
struct FLMRSpellDetailIconInfo {
	struct TSoftObjectPtr<UTexture2D> On; // 0x00(0x28)
	struct TSoftObjectPtr<UTexture2D> Off; // 0x28(0x28)
};

// ScriptStruct LineageR.LMRGameClassIconInfo
// Size: 0xc8 (Inherited: 0x00)
struct FLMRGameClassIconInfo {
	struct TSoftObjectPtr<UTexture2D> Icon; // 0x00(0x28)
	struct TSoftObjectPtr<UTexture2D> PortraitIcon; // 0x28(0x28)
	struct TSoftObjectPtr<UTexture2D> DisableIcon; // 0x50(0x28)
	struct TSoftObjectPtr<UTexture2D> CircularThumbnail; // 0x78(0x28)
	struct TSoftObjectPtr<UTexture2D> CircularThumbnail_Female; // 0xa0(0x28)
};

// ScriptStruct LineageR.LMRWeaponTableRow
// Size: 0xa8 (Inherited: 0x08)
struct FLMRWeaponTableRow : FTableRowBase {
	struct TSoftObjectPtr<UStaticMesh> WeaponAsset; // 0x08(0x28)
	struct TMap<enum class ELMRObjectMaterialSwapType, struct FLMRObjectMaterialSwapSource> DynamicSwapMaterialSorceMap; // 0x30(0x50)
	struct FVector RelativeLocation; // 0x80(0x0c)
	struct FRotator RelativeRotation; // 0x8c(0x0c)
	struct FVector RelativeScale3D; // 0x98(0x0c)
	char pad_A4[0x4]; // 0xa4(0x04)
};

// ScriptStruct LineageR.WidgetPoolData
// Size: 0x78 (Inherited: 0x00)
struct FWidgetPoolData {
	struct TArray<struct ULMRBaseWidget*> ActiveWidgets; // 0x00(0x10)
	struct TArray<struct ULMRBaseWidget*> InactiveWidgets; // 0x10(0x10)
	char pad_20[0x58]; // 0x20(0x58)
};

// ScriptStruct LineageR.LMRWorldConditionSpawnAssetTable
// Size: 0x38 (Inherited: 0x08)
struct FLMRWorldConditionSpawnAssetTable : FTableRowBase {
	struct FSoftObjectPath WorldConditionActorAsset; // 0x08(0x18)
	bool StatueType; // 0x20(0x01)
	char pad_21[0x7]; // 0x21(0x07)
	struct FString Comment; // 0x28(0x10)
};

