// WidgetBlueprintGeneratedClass UI_HUD_Map_Zone.UI_HUD_Map_Zone_C
// Size: 0x2d8 (Inherited: 0x258)
struct UUI_HUD_Map_Zone_C : UUserWidget {
	struct ULMRImage* Image_1; // 0x258(0x08)
	struct ULMRImage* Image_2; // 0x260(0x08)
	struct ULMRImage* Image_3; // 0x268(0x08)
	struct ULMRImage* Image_4; // 0x270(0x08)
	struct ULMRImage* Image_5; // 0x278(0x08)
	struct ULMRImage* Image_6; // 0x280(0x08)
	struct ULMRImage* LMRImage_1; // 0x288(0x08)
	struct ULMRImage* LMRImage_2; // 0x290(0x08)
	struct ULMRImage* LMRImage_3; // 0x298(0x08)
	struct ULMRImage* LMRImage_126; // 0x2a0(0x08)
	struct ULMRTextBlock* LMRTextBlock_1; // 0x2a8(0x08)
	struct ULMRTextBlock* LMRTextBlock_2; // 0x2b0(0x08)
	struct ULMRTextBlock* tb_title; // 0x2b8(0x08)
	struct ULMRTextBlock* tb_title_2; // 0x2c0(0x08)
	struct ULMRTextBlock* tb_title_3; // 0x2c8(0x08)
	struct ULMRTextBlock* tb_title_4; // 0x2d0(0x08)
};

