// WidgetBlueprintGeneratedClass UI_Chat_Voice_Btn.UI_Chat_Voice_Btn_C
// Size: 0x320 (Inherited: 0x300)
struct UUI_Chat_Voice_Btn_C : ULMRChatVoiceButtonWidget {
	struct ULMRImage* Dot1; // 0x300(0x08)
	struct ULMRImage* Dot1_2; // 0x308(0x08)
	struct ULMRImage* Dot1_3; // 0x310(0x08)
	struct ULMRImage* GLOW; // 0x318(0x08)
};

