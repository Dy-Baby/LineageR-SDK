// WidgetBlueprintGeneratedClass UI_ObjectNameTag.UI_ObjectNameTag_C
// Size: 0x450 (Inherited: 0x440)
struct UUI_ObjectNameTag_C : ULMRObjectNameTag {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct ULMRImage* Fx_GlowLight_2; // 0x448(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_ObjectNameTag.UI_ObjectNameTag_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void Construct(); // Function UI_ObjectNameTag.UI_ObjectNameTag_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_UI_ObjectNameTag(int32_t EntryPoint); // Function UI_ObjectNameTag.UI_ObjectNameTag_C.ExecuteUbergraph_UI_ObjectNameTag // (Final|UbergraphFunction) // @ game+0x2849850
};

