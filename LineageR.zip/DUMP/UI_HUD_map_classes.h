// WidgetBlueprintGeneratedClass UI_HUD_map.UI_HUD_map_C
// Size: 0x6e0 (Inherited: 0x6c0)
struct UUI_HUD_map_C : ULMRMinimapWidget {
	struct ULMRImage* Image_MapBG; // 0x6c0(0x08)
	struct ULMRImage* Img_Light2; // 0x6c8(0x08)
	struct URetainerBox* RetainerBox_1; // 0x6d0(0x08)
	struct UUI_MinimapPlayer_C* UI_MinimapPlayer; // 0x6d8(0x08)
};

