// BlueprintGeneratedClass BP_Default_DungeonEnvironment.BP_Default_DungeonEnvironment_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct ABP_Default_DungeonEnvironment_C : ALMRDungeonEnvironment {
};

