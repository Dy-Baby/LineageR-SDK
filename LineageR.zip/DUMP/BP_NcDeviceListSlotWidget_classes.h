// WidgetBlueprintGeneratedClass BP_NcDeviceListSlotWidget.BP_NcDeviceListSlotWidget_C
// Size: 0x4a0 (Inherited: 0x4a0)
struct UBP_NcDeviceListSlotWidget_C : UNcDeviceListSlotWidget {
};

