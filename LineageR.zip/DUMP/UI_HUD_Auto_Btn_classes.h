// WidgetBlueprintGeneratedClass UI_HUD_Auto_Btn.UI_HUD_Auto_Btn_C
// Size: 0x300 (Inherited: 0x300)
struct UUI_HUD_Auto_Btn_C : ULMRAutoStatusWidget {
};

