// WidgetBlueprintGeneratedClass UI_PatchProgress.UI_PatchProgress_C
// Size: 0x2d0 (Inherited: 0x2d0)
struct UUI_PatchProgress_C : ULMRPatchProgressWidget {
};

