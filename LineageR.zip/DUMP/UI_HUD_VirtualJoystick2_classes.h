// WidgetBlueprintGeneratedClass UI_HUD_VirtualJoystick2.UI_HUD_VirtualJoystick2_C
// Size: 0x5a8 (Inherited: 0x5a0)
struct UUI_HUD_VirtualJoystick2_C : ULMRJogButtonWidget {
	struct ULMRImage* LMRImage_1; // 0x5a0(0x08)
};

