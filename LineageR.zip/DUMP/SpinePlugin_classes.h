// Class SpinePlugin.SpineAtlasAsset
// Size: 0x58 (Inherited: 0x28)
struct USpineAtlasAsset : UObject {
	struct TArray<struct UTexture2D*> atlasPages; // 0x28(0x10)
	char pad_38[0x8]; // 0x38(0x08)
	struct FString rawData; // 0x40(0x10)
	struct FName atlasFileName; // 0x50(0x08)
};

// Class SpinePlugin.SpineBoneDriverComponent
// Size: 0x220 (Inherited: 0x1f0)
struct USpineBoneDriverComponent : USceneComponent {
	struct AActor* Target; // 0x1f0(0x08)
	struct FString BoneName; // 0x1f8(0x10)
	bool UseComponentTransform; // 0x208(0x01)
	bool UsePosition; // 0x209(0x01)
	bool UseRotation; // 0x20a(0x01)
	bool UseScale; // 0x20b(0x01)
	char pad_20C[0x14]; // 0x20c(0x14)

	void BeforeUpdateWorldTransform(struct USpineSkeletonComponent* Skeleton); // Function SpinePlugin.SpineBoneDriverComponent.BeforeUpdateWorldTransform // (Final|Native|Protected) // @ game+0xd82f50
};

// Class SpinePlugin.SpineBoneFollowerComponent
// Size: 0x210 (Inherited: 0x1f0)
struct USpineBoneFollowerComponent : USceneComponent {
	struct AActor* Target; // 0x1f0(0x08)
	struct FString BoneName; // 0x1f8(0x10)
	bool UseComponentTransform; // 0x208(0x01)
	bool UsePosition; // 0x209(0x01)
	bool UseRotation; // 0x20a(0x01)
	bool UseScale; // 0x20b(0x01)
	char pad_20C[0x4]; // 0x20c(0x04)
};

// Class SpinePlugin.TrackEntry
// Size: 0x90 (Inherited: 0x28)
struct UTrackEntry : UObject {
	struct FMulticastInlineDelegate animationStart; // 0x28(0x10)
	struct FMulticastInlineDelegate AnimationInterrupt; // 0x38(0x10)
	struct FMulticastInlineDelegate AnimationEvent; // 0x48(0x10)
	struct FMulticastInlineDelegate AnimationComplete; // 0x58(0x10)
	struct FMulticastInlineDelegate animationEnd; // 0x68(0x10)
	struct FMulticastInlineDelegate AnimationDispose; // 0x78(0x10)
	char pad_88[0x8]; // 0x88(0x08)

	void SetTrackTime(float trackTime); // Function SpinePlugin.TrackEntry.SetTrackTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd86100
	void SetTrackEnd(float trackEnd); // Function SpinePlugin.TrackEntry.SetTrackEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xd86070
	void SetTimeScale(float TimeScale); // Function SpinePlugin.TrackEntry.SetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd85fa0
	void SetMixTime(float mixTime); // Function SpinePlugin.TrackEntry.SetMixTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd85690
	void SetMixDuration(float mixDuration); // Function SpinePlugin.TrackEntry.SetMixDuration // (Final|Native|Public|BlueprintCallable) // @ game+0xd85600
	void SetLoop(bool Loop); // Function SpinePlugin.TrackEntry.SetLoop // (Final|Native|Public|BlueprintCallable) // @ game+0xd85570
	void SetEventThreshold(float eventThreshold); // Function SpinePlugin.TrackEntry.SetEventThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd854e0
	void SetDrawOrderThreshold(float drawOrderThreshold); // Function SpinePlugin.TrackEntry.SetDrawOrderThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd852b0
	void SetDelay(float Delay); // Function SpinePlugin.TrackEntry.SetDelay // (Final|Native|Public|BlueprintCallable) // @ game+0xd85220
	void SetAttachmentThreshold(float attachmentThreshold); // Function SpinePlugin.TrackEntry.SetAttachmentThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd84ed0
	void SetAnimationStart(float animationStart); // Function SpinePlugin.TrackEntry.SetAnimationStart // (Final|Native|Public|BlueprintCallable) // @ game+0xd84b60
	void SetAnimationLast(float animationLast); // Function SpinePlugin.TrackEntry.SetAnimationLast // (Final|Native|Public|BlueprintCallable) // @ game+0xd84ad0
	void SetAnimationEnd(float animationEnd); // Function SpinePlugin.TrackEntry.SetAnimationEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xd84a40
	void SetAlpha(float Alpha); // Function SpinePlugin.TrackEntry.SetAlpha // (Final|Native|Public|BlueprintCallable) // @ game+0xd846d0
	float isValidAnimation(); // Function SpinePlugin.TrackEntry.isValidAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd86440
	float GetTrackTime(); // Function SpinePlugin.TrackEntry.GetTrackTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd840e0
	int32_t GetTrackIndex(); // Function SpinePlugin.TrackEntry.GetTrackIndex // (Final|Native|Public|BlueprintCallable) // @ game+0xd84090
	float GetTrackEnd(); // Function SpinePlugin.TrackEntry.GetTrackEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xd84040
	float GetTimeScale(); // Function SpinePlugin.TrackEntry.GetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd83ff0
	float GetMixTime(); // Function SpinePlugin.TrackEntry.GetMixTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd83b40
	float GetMixDuration(); // Function SpinePlugin.TrackEntry.GetMixDuration // (Final|Native|Public|BlueprintCallable) // @ game+0xd83af0
	bool GetLoop(); // Function SpinePlugin.TrackEntry.GetLoop // (Final|Native|Public|BlueprintCallable) // @ game+0xd83aa0
	float GetEventThreshold(); // Function SpinePlugin.TrackEntry.GetEventThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd83a50
	float GetDrawOrderThreshold(); // Function SpinePlugin.TrackEntry.GetDrawOrderThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd83a00
	float GetDelay(); // Function SpinePlugin.TrackEntry.GetDelay // (Final|Native|Public|BlueprintCallable) // @ game+0xd839b0
	float GetAttachmentThreshold(); // Function SpinePlugin.TrackEntry.GetAttachmentThreshold // (Final|Native|Public|BlueprintCallable) // @ game+0xd835d0
	float GetAnimationStart(); // Function SpinePlugin.TrackEntry.GetAnimationStart // (Final|Native|Public|BlueprintCallable) // @ game+0xd833e0
	struct FString getAnimationName(); // Function SpinePlugin.TrackEntry.getAnimationName // (Final|Native|Public|BlueprintCallable) // @ game+0xd862f0
	float GetAnimationLast(); // Function SpinePlugin.TrackEntry.GetAnimationLast // (Final|Native|Public|BlueprintCallable) // @ game+0xd83390
	float GetAnimationEnd(); // Function SpinePlugin.TrackEntry.GetAnimationEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xd83340
	float getAnimationDuration(); // Function SpinePlugin.TrackEntry.getAnimationDuration // (Final|Native|Public|BlueprintCallable) // @ game+0xd862a0
	float GetAlpha(); // Function SpinePlugin.TrackEntry.GetAlpha // (Final|Native|Public|BlueprintCallable) // @ game+0xd83110
};

// Class SpinePlugin.SpineSkeletonComponent
// Size: 0x108 (Inherited: 0xb0)
struct USpineSkeletonComponent : UActorComponent {
	struct USpineAtlasAsset* Atlas; // 0xb0(0x08)
	struct USpineSkeletonDataAsset* SkeletonData; // 0xb8(0x08)
	struct FMulticastInlineDelegate BeforeUpdateWorldTransform; // 0xc0(0x10)
	struct FMulticastInlineDelegate AfterUpdateWorldTransform; // 0xd0(0x10)
	char pad_E0[0x28]; // 0xe0(0x28)

	void UpdateWorldTransform(); // Function SpinePlugin.SpineSkeletonComponent.UpdateWorldTransform // (Final|Native|Public|BlueprintCallable) // @ game+0xd86260
	void SetToSetupPose(); // Function SpinePlugin.SpineSkeletonComponent.SetToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd86030
	void SetSlotsToSetupPose(); // Function SpinePlugin.SpineSkeletonComponent.SetSlotsToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd85e60
	bool SetSkins(struct TArray<struct FString>& SkinNames); // Function SpinePlugin.SpineSkeletonComponent.SetSkins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xd85ca0
	bool SetSkin(struct FString SkinName); // Function SpinePlugin.SpineSkeletonComponent.SetSkin // (Final|Native|Public|BlueprintCallable) // @ game+0xd85ac0
	void SetScaleY(float ScaleY); // Function SpinePlugin.SpineSkeletonComponent.SetScaleY // (Final|Native|Public|BlueprintCallable) // @ game+0xd859c0
	void SetScaleX(float ScaleX); // Function SpinePlugin.SpineSkeletonComponent.SetScaleX // (Final|Native|Public|BlueprintCallable) // @ game+0xd858c0
	void SetBoneWorldPosition(struct FString BoneName, struct FVector& Position); // Function SpinePlugin.SpineSkeletonComponent.SetBoneWorldPosition // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xd85080
	void SetBonesToSetupPose(); // Function SpinePlugin.SpineSkeletonComponent.SetBonesToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd85160
	bool SetAttachment(struct FString SlotName, struct FString attachmentName); // Function SpinePlugin.SpineSkeletonComponent.SetAttachment // (Final|Native|Public|BlueprintCallable) // @ game+0xd84bf0
	bool HasSlot(struct FString SlotName); // Function SpinePlugin.SpineSkeletonComponent.HasSlot // (Final|Native|Public|BlueprintCallable) // @ game+0xd844f0
	bool HasSkin(struct FString SkinName); // Function SpinePlugin.SpineSkeletonComponent.HasSkin // (Final|Native|Public|BlueprintCallable) // @ game+0xd84130
	bool HasBone(struct FString BoneName); // Function SpinePlugin.SpineSkeletonComponent.HasBone // (Final|Native|Public|BlueprintCallable) // @ game+0xd84310
	bool HasAnimation(struct FString AnimationName); // Function SpinePlugin.SpineSkeletonComponent.HasAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd84130
	void GetSlots(struct TArray<struct FString>& Slots); // Function SpinePlugin.SpineSkeletonComponent.GetSlots // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83df0
	void GetSkins(struct TArray<struct FString>& Skins); // Function SpinePlugin.SpineSkeletonComponent.GetSkins // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83c50
	float GetScaleY(); // Function SpinePlugin.SpineSkeletonComponent.GetScaleY // (Final|Native|Public|BlueprintCallable) // @ game+0xd83bf0
	float GetScaleX(); // Function SpinePlugin.SpineSkeletonComponent.GetScaleX // (Final|Native|Public|BlueprintCallable) // @ game+0xd83b90
	struct FTransform GetBoneWorldTransform(struct FString BoneName); // Function SpinePlugin.SpineSkeletonComponent.GetBoneWorldTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xd83620
	void GetBones(struct TArray<struct FString>& Bones); // Function SpinePlugin.SpineSkeletonComponent.GetBones // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd836f0
	void GetAnimations(struct TArray<struct FString>& Animations); // Function SpinePlugin.SpineSkeletonComponent.GetAnimations // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83430
	float getAnimationDuration(struct FString AnimationName); // Function SpinePlugin.SpineSkeletonComponent.getAnimationDuration // (Final|Native|Public|BlueprintCallable) // @ game+0xd83160
};

// Class SpinePlugin.SpineSkeletonAnimationComponent
// Size: 0x240 (Inherited: 0x108)
struct USpineSkeletonAnimationComponent : USpineSkeletonComponent {
	struct FMulticastInlineDelegate animationStart; // 0x108(0x10)
	struct FMulticastInlineDelegate AnimationInterrupt; // 0x118(0x10)
	struct FMulticastInlineDelegate AnimationEvent; // 0x128(0x10)
	struct FMulticastInlineDelegate AnimationComplete; // 0x138(0x10)
	struct FMulticastInlineDelegate animationEnd; // 0x148(0x10)
	struct FMulticastInlineDelegate AnimationDispose; // 0x158(0x10)
	struct FString PreviewAnimation; // 0x168(0x10)
	struct FString PreviewSkin; // 0x178(0x10)
	struct FString LW_StartAnimation; // 0x188(0x10)
	int32_t LW_StartTrackIndex; // 0x198(0x04)
	int32_t LW_StartTrackLoop; // 0x19c(0x04)
	float LW_StartTime; // 0x1a0(0x04)
	char pad_1A4[0xc]; // 0x1a4(0x0c)
	struct TSet<struct UTrackEntry*> trackEntries; // 0x1b0(0x50)
	bool bAutoPlaying; // 0x200(0x01)
	char pad_201[0x3f]; // 0x201(0x3f)

	void SetTimeScale(float TimeScale); // Function SpinePlugin.SpineSkeletonAnimationComponent.SetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd85ea0
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Function SpinePlugin.SpineSkeletonAnimationComponent.SetPlaybackTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd85720
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration); // Function SpinePlugin.SpineSkeletonAnimationComponent.SetEmptyAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd85340
	void SetAutoPlay(bool bInAutoPlays); // Function SpinePlugin.SpineSkeletonAnimationComponent.SetAutoPlay // (Final|Native|Public|BlueprintCallable) // @ game+0xd84f60
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop); // Function SpinePlugin.SpineSkeletonAnimationComponent.SetAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd84760
	float GetTimeScale(); // Function SpinePlugin.SpineSkeletonAnimationComponent.GetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd83f90
	struct UTrackEntry* GetCurrent(int32_t TrackIndex); // Function SpinePlugin.SpineSkeletonAnimationComponent.GetCurrent // (Final|Native|Public|BlueprintCallable) // @ game+0xd83890
	void ClearTracks(); // Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTracks // (Final|Native|Public|BlueprintCallable) // @ game+0xd830d0
	void ClearTrack(int32_t TrackIndex); // Function SpinePlugin.SpineSkeletonAnimationComponent.ClearTrack // (Final|Native|Public|BlueprintCallable) // @ game+0xd82fd0
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay); // Function SpinePlugin.SpineSkeletonAnimationComponent.AddEmptyAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd82d50
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Function SpinePlugin.SpineSkeletonAnimationComponent.AddAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd82a10
};

// Class SpinePlugin.SpineSkeletonDataAsset
// Size: 0xc0 (Inherited: 0x28)
struct USpineSkeletonDataAsset : UObject {
	float DefaultMix; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FSpineAnimationStateMixData> MixData; // 0x30(0x10)
	struct TArray<struct FString> Bones; // 0x40(0x10)
	struct TArray<struct FString> Slots; // 0x50(0x10)
	struct TArray<struct FString> Skins; // 0x60(0x10)
	struct TArray<struct FString> Animations; // 0x70(0x10)
	struct TArray<struct FString> events; // 0x80(0x10)
	struct TArray<char> rawData; // 0x90(0x10)
	struct FName skeletonDataFileName; // 0xa0(0x08)
	char pad_A8[0x18]; // 0xa8(0x18)
};

// Class SpinePlugin.SpineSkeletonRendererComponent
// Size: 0x850 (Inherited: 0x4a0)
struct USpineSkeletonRendererComponent : UProceduralMeshComponent {
	struct UMaterialInterface* NormalBlendMaterial; // 0x498(0x08)
	struct UMaterialInterface* AdditiveBlendMaterial; // 0x4a0(0x08)
	struct UMaterialInterface* MultiplyBlendMaterial; // 0x4a8(0x08)
	struct UMaterialInterface* ScreenBlendMaterial; // 0x4b0(0x08)
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // 0x4b8(0x10)
	char pad_4D0[0x48]; // 0x4d0(0x48)
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // 0x518(0x10)
	char pad_528[0x50]; // 0x528(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // 0x578(0x10)
	char pad_588[0x50]; // 0x588(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // 0x5d8(0x10)
	char pad_5E8[0x50]; // 0x5e8(0x50)
	float DepthOffset; // 0x638(0x04)
	struct FName TextureParameterName; // 0x63c(0x08)
	struct FLinearColor Color; // 0x644(0x10)
	bool bCreateCollision; // 0x654(0x01)
	char pad_655[0x1fb]; // 0x655(0x1fb)

	void SetColor(struct FLinearColor InColor); // Function SpinePlugin.SpineSkeletonRendererComponent.SetColor // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xd851a0
};

// Class SpinePlugin.SpineWidget
// Size: 0x6e8 (Inherited: 0x130)
struct USpineWidget : UWidget {
	float Scale; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct USpineAtlasAsset* Atlas; // 0x138(0x08)
	struct USpineSkeletonDataAsset* SkeletonData; // 0x140(0x08)
	struct UMaterialInterface* NormalBlendMaterial; // 0x148(0x08)
	struct UMaterialInterface* AdditiveBlendMaterial; // 0x150(0x08)
	struct UMaterialInterface* MultiplyBlendMaterial; // 0x158(0x08)
	struct UMaterialInterface* ScreenBlendMaterial; // 0x160(0x08)
	struct FName TextureParameterName; // 0x168(0x08)
	float DepthOffset; // 0x170(0x04)
	struct FLinearColor Color; // 0x174(0x10)
	char pad_184[0x4]; // 0x184(0x04)
	struct FSlateBrush Brush; // 0x188(0x88)
	struct FMulticastInlineDelegate BeforeUpdateWorldTransform; // 0x210(0x10)
	struct FMulticastInlineDelegate AfterUpdateWorldTransform; // 0x220(0x10)
	struct FMulticastInlineDelegate animationStart; // 0x230(0x10)
	struct FMulticastInlineDelegate AnimationInterrupt; // 0x240(0x10)
	struct FMulticastInlineDelegate AnimationEvent; // 0x250(0x10)
	struct FMulticastInlineDelegate AnimationComplete; // 0x260(0x10)
	struct FMulticastInlineDelegate animationEnd; // 0x270(0x10)
	struct FMulticastInlineDelegate AnimationDispose; // 0x280(0x10)
	char pad_290[0x40]; // 0x290(0x40)
	struct TArray<struct UMaterialInstanceDynamic*> atlasNormalBlendMaterials; // 0x2d0(0x10)
	char pad_2E0[0x50]; // 0x2e0(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasAdditiveBlendMaterials; // 0x330(0x10)
	char pad_340[0x50]; // 0x340(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasMultiplyBlendMaterials; // 0x390(0x10)
	char pad_3A0[0x50]; // 0x3a0(0x50)
	struct TArray<struct UMaterialInstanceDynamic*> atlasScreenBlendMaterials; // 0x3f0(0x10)
	char pad_400[0x290]; // 0x400(0x290)
	struct TSet<struct UTrackEntry*> trackEntries; // 0x690(0x50)
	bool bAutoPlaying; // 0x6e0(0x01)
	char pad_6E1[0x7]; // 0x6e1(0x07)

	void UpdateWorldTransform(); // Function SpinePlugin.SpineWidget.UpdateWorldTransform // (Final|Native|Public|BlueprintCallable) // @ game+0xd86280
	void Tick(float DeltaTime, bool CallDelegates); // Function SpinePlugin.SpineWidget.Tick // (Final|Native|Public|BlueprintCallable) // @ game+0xd86190
	void SetToSetupPose(); // Function SpinePlugin.SpineWidget.SetToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd86050
	void SetTimeScale(float TimeScale); // Function SpinePlugin.SpineWidget.SetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd85f20
	void SetSlotsToSetupPose(); // Function SpinePlugin.SpineWidget.SetSlotsToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd85e80
	bool SetSkins(struct TArray<struct FString>& SkinNames); // Function SpinePlugin.SpineWidget.SetSkins // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xd85d80
	bool SetSkin(struct FString SkinName); // Function SpinePlugin.SpineWidget.SetSkin // (Final|Native|Public|BlueprintCallable) // @ game+0xd85bb0
	void SetScaleY(float ScaleY); // Function SpinePlugin.SpineWidget.SetScaleY // (Final|Native|Public|BlueprintCallable) // @ game+0xd85a40
	void SetScaleX(float ScaleX); // Function SpinePlugin.SpineWidget.SetScaleX // (Final|Native|Public|BlueprintCallable) // @ game+0xd85940
	void SetPlaybackTime(float InPlaybackTime, bool bCallDelegates); // Function SpinePlugin.SpineWidget.SetPlaybackTime // (Final|Native|Public|BlueprintCallable) // @ game+0xd857f0
	struct UTrackEntry* SetEmptyAnimation(int32_t TrackIndex, float mixDuration); // Function SpinePlugin.SpineWidget.SetEmptyAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd85410
	void SetBonesToSetupPose(); // Function SpinePlugin.SpineWidget.SetBonesToSetupPose // (Final|Native|Public|BlueprintCallable) // @ game+0xd85180
	void SetAutoPlay(bool bInAutoPlays); // Function SpinePlugin.SpineWidget.SetAutoPlay // (Final|Native|Public|BlueprintCallable) // @ game+0xd84ff0
	bool SetAttachment(struct FString SlotName, struct FString attachmentName); // Function SpinePlugin.SpineWidget.SetAttachment // (Final|Native|Public|BlueprintCallable) // @ game+0xd84d60
	struct UTrackEntry* SetAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop); // Function SpinePlugin.SpineWidget.SetAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd848d0
	bool HasSlot(struct FString SlotName); // Function SpinePlugin.SpineWidget.HasSlot // (Final|Native|Public|BlueprintCallable) // @ game+0xd845e0
	bool HasSkin(struct FString SkinName); // Function SpinePlugin.SpineWidget.HasSkin // (Final|Native|Public|BlueprintCallable) // @ game+0xd84220
	bool HasBone(struct FString BoneName); // Function SpinePlugin.SpineWidget.HasBone // (Final|Native|Public|BlueprintCallable) // @ game+0xd84400
	bool HasAnimation(struct FString AnimationName); // Function SpinePlugin.SpineWidget.HasAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd84220
	float GetTimeScale(); // Function SpinePlugin.SpineWidget.GetTimeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xd83fc0
	void GetSlots(struct TArray<struct FString>& Slots); // Function SpinePlugin.SpineWidget.GetSlots // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83ec0
	void GetSkins(struct TArray<struct FString>& Skins); // Function SpinePlugin.SpineWidget.GetSkins // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83d20
	float GetScaleY(); // Function SpinePlugin.SpineWidget.GetScaleY // (Final|Native|Public|BlueprintCallable) // @ game+0xd83c20
	float GetScaleX(); // Function SpinePlugin.SpineWidget.GetScaleX // (Final|Native|Public|BlueprintCallable) // @ game+0xd83bc0
	struct UTrackEntry* GetCurrent(int32_t TrackIndex); // Function SpinePlugin.SpineWidget.GetCurrent // (Final|Native|Public|BlueprintCallable) // @ game+0xd83920
	void GetBones(struct TArray<struct FString>& Bones); // Function SpinePlugin.SpineWidget.GetBones // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd837c0
	void GetAnimations(struct TArray<struct FString>& Animations); // Function SpinePlugin.SpineWidget.GetAnimations // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xd83500
	float getAnimationDuration(struct FString AnimationName); // Function SpinePlugin.SpineWidget.getAnimationDuration // (Final|Native|Public|BlueprintCallable) // @ game+0xd83250
	void ClearTracks(); // Function SpinePlugin.SpineWidget.ClearTracks // (Final|Native|Public|BlueprintCallable) // @ game+0xd830f0
	void ClearTrack(int32_t TrackIndex); // Function SpinePlugin.SpineWidget.ClearTrack // (Final|Native|Public|BlueprintCallable) // @ game+0xd83050
	struct UTrackEntry* AddEmptyAnimation(int32_t TrackIndex, float mixDuration, float Delay); // Function SpinePlugin.SpineWidget.AddEmptyAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd82e50
	struct UTrackEntry* AddAnimation(int32_t TrackIndex, struct FString AnimationName, bool Loop, float Delay); // Function SpinePlugin.SpineWidget.AddAnimation // (Final|Native|Public|BlueprintCallable) // @ game+0xd82bb0
};

