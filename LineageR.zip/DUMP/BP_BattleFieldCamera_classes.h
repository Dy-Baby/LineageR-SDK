// BlueprintGeneratedClass BP_BattleFieldCamera.BP_BattleFieldCamera_C
// Size: 0x5f8 (Inherited: 0x5f0)
struct ABP_BattleFieldCamera_C : ALMRObject {
	struct UStaticMeshComponent* Sphere; // 0x5f0(0x08)
};

