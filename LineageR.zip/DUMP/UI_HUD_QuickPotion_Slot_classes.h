// WidgetBlueprintGeneratedClass UI_HUD_QuickPotion_Slot.UI_HUD_QuickPotion_Slot_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UUI_HUD_QuickPotion_Slot_C : ULMRQuickPotionOptionSlotWidget {
};

