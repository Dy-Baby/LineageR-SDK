// WidgetBlueprintGeneratedClass UI_HUD_party_player_Btn.UI_HUD_party_player_Btn_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct UUI_HUD_party_player_Btn_C : ULMRPartyPlayerMenuWidget {
};

