// BlueprintGeneratedClass BP_BuffCardPolymorphParent.BP_BuffCardPolymorphParent_C
// Size: 0x6b0 (Inherited: 0x6b0)
struct ABP_BuffCardPolymorphParent_C : ABP_BuffCardParent_C {
};

