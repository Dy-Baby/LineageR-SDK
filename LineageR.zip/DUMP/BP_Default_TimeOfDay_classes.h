// BlueprintGeneratedClass BP_Default_TimeOfDay.BP_Default_TimeOfDay_C
// Size: 0x3b0 (Inherited: 0x3b0)
struct ABP_Default_TimeOfDay_C : ALMRTimeOfDay {
};

