// WidgetBlueprintGeneratedClass UI_PlayerNameTag.UI_PlayerNameTag_C
// Size: 0x3f0 (Inherited: 0x3e8)
struct UUI_PlayerNameTag_C : ULMRPlayerNameTag {
	struct ULMRImage* Img_Question; // 0x3e8(0x08)
};

