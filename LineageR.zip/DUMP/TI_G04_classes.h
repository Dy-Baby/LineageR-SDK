// BlueprintGeneratedClass TI_G04.TI_G04_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_G04_C : ALevelScriptActor {
};

