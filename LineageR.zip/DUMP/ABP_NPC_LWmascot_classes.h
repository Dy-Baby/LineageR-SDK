// AnimBlueprintGeneratedClass ABP_NPC_LWmascot.ABP_NPC_LWmascot_C
// Size: 0xff8 (Inherited: 0xff8)
struct UABP_NPC_LWmascot_C : UABP_Npc_Master_LookAt_SP1_SP2_C {
};

