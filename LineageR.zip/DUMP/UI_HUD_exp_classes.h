// WidgetBlueprintGeneratedClass UI_HUD_exp.UI_HUD_exp_C
// Size: 0x2e8 (Inherited: 0x2d8)
struct UUI_HUD_exp_C : ULMRExpWidget {
	struct ULMRImage* img_Glow; // 0x2d8(0x08)
	struct ULMRUIParticleViewport* UI_FX_Exp; // 0x2e0(0x08)
};

