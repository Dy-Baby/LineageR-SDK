// BlueprintGeneratedClass TI_F03.TI_F03_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_F03_C : ALevelScriptActor {
};

