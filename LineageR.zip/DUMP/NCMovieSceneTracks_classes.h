// Class NCMovieSceneTracks.MovieSceneInGameCameraBlendTransformSectionNC01
// Size: 0x5a0 (Inherited: 0x130)
struct UMovieSceneInGameCameraBlendTransformSectionNC01 : UMovieSceneSection {
	struct FMovieSceneFloatChannel Translation[0x3]; // 0x130(0x1e0)
	struct FMovieSceneFloatChannel Rotation[0x3]; // 0x310(0x1e0)
	struct FMovieSceneFloatChannel BlendWeight; // 0x4f0(0xa0)
	struct TWeakObjectPtr<struct AActor> InGameCamera; // 0x590(0x08)
	bool bUseCurveCamBlendPath; // 0x598(0x01)
	char pad_599[0x7]; // 0x599(0x07)
};

// Class NCMovieSceneTracks.MovieSceneInGameCameraBlendTransformTrackNC01
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneInGameCameraBlendTransformTrackNC01 : UMovieScenePropertyTrack {
};

// Class NCMovieSceneTracks.MovieSceneMorphTargetSectionNC01
// Size: 0x1d8 (Inherited: 0x1d0)
struct UMovieSceneMorphTargetSectionNC01 : UMovieSceneFloatSection {
	struct FName MorphTargetName; // 0x1d0(0x08)
};

// Class NCMovieSceneTracks.MovieSceneMorphTargetTrackNC01
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneMorphTargetTrackNC01 : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
	struct FName MorphTargetName; // 0x68(0x08)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleAnimationSectionNC01
// Size: 0x150 (Inherited: 0x130)
struct UMovieSceneSubTitleAnimationSectionNC01 : UMovieSceneSection {
	struct FMovieSceneSubTitleAnimationParams Params; // 0x130(0x20)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleContentSectionBaseNC01
// Size: 0x150 (Inherited: 0x130)
struct UMovieSceneSubTitleContentSectionBaseNC01 : UMovieSceneSection {
	struct FMovieSceneSubTitleContentParams Params; // 0x130(0x20)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleImageSectionNC01
// Size: 0x1e8 (Inherited: 0x150)
struct UMovieSceneSubTitleImageSectionNC01 : UMovieSceneSubTitleContentSectionBaseNC01 {
	struct FMovieSceneSubTitleImageParams ImageParams; // 0x150(0x98)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleRichTextSectionNC01
// Size: 0x588 (Inherited: 0x150)
struct UMovieSceneSubTitleRichTextSectionNC01 : UMovieSceneSubTitleContentSectionBaseNC01 {
	struct FMovieSceneSubTitleRichTextParams TextParams; // 0x150(0x438)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleTextSectionNC01
// Size: 0x338 (Inherited: 0x150)
struct UMovieSceneSubTitleTextSectionNC01 : UMovieSceneSubTitleContentSectionBaseNC01 {
	struct FMovieSceneSubTitleTextParams TextParams; // 0x150(0x1e8)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleSectionNC01
// Size: 0x130 (Inherited: 0x130)
struct UMovieSceneSubTitleSectionNC01 : UMovieSceneSection {
};

// Class NCMovieSceneTracks.MovieSceneSubTitleSimpleAnimationSectionNC01
// Size: 0x510 (Inherited: 0x130)
struct UMovieSceneSubTitleSimpleAnimationSectionNC01 : UMovieSceneSection {
	struct FMovieSceneSubTitleSimpleAnimationParams Params; // 0x130(0x20)
	struct FMovieSceneFloatChannel Opacity; // 0x150(0xa0)
	struct FMovieSceneFloatChannel Translation[0x2]; // 0x1f0(0x140)
	struct FMovieSceneFloatChannel Rotation; // 0x330(0xa0)
	struct FMovieSceneFloatChannel Scale[0x2]; // 0x3d0(0x140)
};

// Class NCMovieSceneTracks.MovieSceneSubTitleTrackNC01
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneSubTitleTrackNC01 : UMovieSceneNameableTrack {
	struct UUserWidget* SubTitleWidgetClass; // 0x58(0x08)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x60(0x10)
};

// Class NCMovieSceneTracks.MovieSceneTargetFollowCamSectionNC01
// Size: 0x650 (Inherited: 0x130)
struct UMovieSceneTargetFollowCamSectionNC01 : UMovieSceneSection {
	struct FMovieSceneFloatChannel DistanceCurve; // 0x130(0xa0)
	struct FMovieSceneFloatChannel RotationCurves[0x3]; // 0x1d0(0x1e0)
	struct FMovieSceneFloatChannel OffsetCurves[0x3]; // 0x3b0(0x1e0)
	struct FMovieSceneFloatChannel WeightCurve; // 0x590(0xa0)
	struct FMovieSceneObjectBindingID TargetBindingID; // 0x630(0x18)
	struct FName TargetBoneSocketName; // 0x648(0x08)

	void SetTargetBindingID(struct FMovieSceneObjectBindingID& InTargetBindingID); // Function NCMovieSceneTracks.MovieSceneTargetFollowCamSectionNC01.SetTargetBindingID // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa24680
};

// Class NCMovieSceneTracks.MovieSceneTargetFollowCamTrackNC01
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneTargetFollowCamTrackNC01 : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Class NCMovieSceneTracks.MovieSceneWalkingSnapFloorSectionNC01
// Size: 0x1d8 (Inherited: 0x130)
struct UMovieSceneWalkingSnapFloorSectionNC01 : UMovieSceneSection {
	bool DefaultValue; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
	struct FMovieSceneBoolChannel BoolCurve; // 0x138(0x90)
	bool bSnapFloorAtBeginning; // 0x1c8(0x01)
	bool bIsAvailabeFallingState; // 0x1c9(0x01)
	char pad_1CA[0x2]; // 0x1ca(0x02)
	float LowerDistZ; // 0x1cc(0x04)
	float UpperDistZ; // 0x1d0(0x04)
	char pad_1D4[0x4]; // 0x1d4(0x04)
};

// Class NCMovieSceneTracks.MovieSceneWalkingSnapFloorTrackNC01
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneWalkingSnapFloorTrackNC01 : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

