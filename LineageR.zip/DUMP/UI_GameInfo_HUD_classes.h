// WidgetBlueprintGeneratedClass UI_GameInfo_HUD.UI_GameInfo_HUD_C
// Size: 0x448 (Inherited: 0x430)
struct UUI_GameInfo_HUD_C : ULMRGameInfoHUDWidget {
	struct UCanvasPanel* CanvasPanel; // 0x430(0x08)
	struct UUI_HUD_gnb_C* UI_HUD_gnb; // 0x438(0x08)
	struct UUI_HUD_playerInfo_C* UI_HUD_playerInfo_new; // 0x440(0x08)
};

