// WidgetBlueprintGeneratedClass UI_NPCItemRoot.UI_NPCItemRoot_C
// Size: 0x320 (Inherited: 0x308)
struct UUI_NPCItemRoot_C : ULMRGatherNotiWidget {
	struct ULMRImage* Bubble_2; // 0x308(0x08)
	struct ULMRImage* Fx_Flare; // 0x310(0x08)
	struct ULMRImage* fx_glow; // 0x318(0x08)
};

