// BlueprintGeneratedClass TI_SFX.TI_SFX_C
// Size: 0x230 (Inherited: 0x228)
struct ATI_SFX_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)

	void ReceiveBeginPlay(); // Function TI_SFX.TI_SFX_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x2849850
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function TI_SFX.TI_SFX_C.ReceiveEndPlay // (Event|Protected|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_TI_SFX(int32_t EntryPoint); // Function TI_SFX.TI_SFX_C.ExecuteUbergraph_TI_SFX // (Final|UbergraphFunction) // @ game+0x2849850
};

