// WidgetBlueprintGeneratedClass BP_NcShowLoginProviderCircleWidget.BP_NcShowLoginProviderCircleWidget_C
// Size: 0x470 (Inherited: 0x470)
struct UBP_NcShowLoginProviderCircleWidget_C : UNcShowLoginProviderCircleWidget {
};

