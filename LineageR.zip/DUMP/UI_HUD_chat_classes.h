// WidgetBlueprintGeneratedClass UI_HUD_chat.UI_HUD_chat_C
// Size: 0x318 (Inherited: 0x310)
struct UUI_HUD_chat_C : ULMRChatSystemWidget {
	struct UVerticalBox* chatMessageBox; // 0x310(0x08)
};

