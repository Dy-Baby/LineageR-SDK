// AnimBlueprintGeneratedClass ABP_Npc_Gotcha_NoviceGolem_Wire.ABP_Npc_Gotcha_NoviceGolem_Wire_C
// Size: 0xa48 (Inherited: 0xa48)
struct UABP_Npc_Gotcha_NoviceGolem_Wire_C : UABP_Npc_Master_C {
};

