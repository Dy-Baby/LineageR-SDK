// Enum NcPlatformSdk.ENcWidgetBorderType
enum class ENcWidgetBorderType : uint8 {
	Round = 0,
	Square = 1,
	TopRound = 2,
	BottomRound = 3,
	LeftBottomRound = 4,
	RightBottomRound = 5,
	ENcWidgetBorderType_MAX = 6
};

// Enum NcPlatformSdk.ENcWidgetColorType
enum class ENcWidgetColorType : uint8 {
	None = 0,
	Dark = 1,
	Light = 2,
	ENcWidgetColorType_MAX = 3
};

// Enum NcPlatformSdk.ENcWidgetStyleType
enum class ENcWidgetStyleType : uint8 {
	None = 0,
	Style1 = 1,
	Style2 = 2,
	ENcWidgetStyleType_MAX = 3
};

// Enum NcPlatformSdk.ESDKSaveSlotType
enum class ESDKSaveSlotType : uint8 {
	Default = 0,
	AppIdOnly = 1,
	ESDKSaveSlotType_MAX = 2
};

// ScriptStruct NcPlatformSdk.AnimationDialogAnimation
// Size: 0x18 (Inherited: 0x00)
struct FAnimationDialogAnimation {
	struct FString Name; // 0x00(0x10)
	enum class EUMGSequencePlayMode PlayModeType; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
};

// ScriptStruct NcPlatformSdk.NcWidgetColor
// Size: 0x148 (Inherited: 0x08)
struct FNcWidgetColor : FTableRowBase {
	struct FString Background; // 0x08(0x10)
	struct FString Box; // 0x18(0x10)
	struct FString InnerBox; // 0x28(0x10)
	struct FString InputfieldBox; // 0x38(0x10)
	struct FString Line1; // 0x48(0x10)
	struct FString Line2; // 0x58(0x10)
	struct FString Button1; // 0x68(0x10)
	struct FString Button1Hovered; // 0x78(0x10)
	struct FString Button1Pressed; // 0x88(0x10)
	struct FString Button1Disabled; // 0x98(0x10)
	struct FString Button2; // 0xa8(0x10)
	struct FString Button2Hovered; // 0xb8(0x10)
	struct FString Button2Pressed; // 0xc8(0x10)
	struct FString Button2Disabled; // 0xd8(0x10)
	struct FString Text1; // 0xe8(0x10)
	struct FString Text2; // 0xf8(0x10)
	struct FString ButtonText1; // 0x108(0x10)
	struct FString ButtonText2; // 0x118(0x10)
	struct FString PointText; // 0x128(0x10)
	struct FString TextHovered; // 0x138(0x10)
};

// ScriptStruct NcPlatformSdk.NcWidgetStyleOverrideSettings
// Size: 0x78 (Inherited: 0x00)
struct FNcWidgetStyleOverrideSettings {
	bool bOverrideBorderPadding; // 0x00(0x01)
	bool bOverrideTitleSectionPadding; // 0x01(0x01)
	bool bOverrideTitleTextSize; // 0x02(0x01)
	bool bOverrideContentCornerRadius; // 0x03(0x01)
	bool bOverrideContentWidth; // 0x04(0x01)
	bool bOverrideContentSectionPadding; // 0x05(0x01)
	bool bOverrideBackgroundTransparent; // 0x06(0x01)
	bool bOverrideButtonsSpacing; // 0x07(0x01)
	bool bOverrideButtonCornerRadius; // 0x08(0x01)
	bool bOverrideButtonsHeight; // 0x09(0x01)
	bool bOverrideButtonsTextSize; // 0x0a(0x01)
	bool bOverrideButtonSectionPadding; // 0x0b(0x01)
	char pad_C[0x4]; // 0x0c(0x04)
	struct FNcWidgetStyle OverrideStyle; // 0x10(0x68)
};

// ScriptStruct NcPlatformSdk.NcWidgetStyle
// Size: 0x68 (Inherited: 0x08)
struct FNcWidgetStyle : FTableRowBase {
	struct FMargin BorderPadding; // 0x08(0x10)
	struct FMargin TitleSectionPadding; // 0x18(0x10)
	int32_t TitleTextSize; // 0x28(0x04)
	int32_t ContentCornerRadius; // 0x2c(0x04)
	float ContentWidth; // 0x30(0x04)
	struct FMargin ContentSectionPadding; // 0x34(0x10)
	bool bIsBackgroundTransparent; // 0x44(0x01)
	char pad_45[0x3]; // 0x45(0x03)
	float ButtonsSpacing; // 0x48(0x04)
	int32_t ButtonCornerRadius; // 0x4c(0x04)
	float ButtonsHeight; // 0x50(0x04)
	int32_t ButtonsTextSize; // 0x54(0x04)
	struct FMargin ButtonSectionPadding; // 0x58(0x10)
};

