// WidgetBlueprintGeneratedClass UI_MessageBox.UI_MessageBox_C
// Size: 0x5b8 (Inherited: 0x5b0)
struct UUI_MessageBox_C : ULMRMessageBoxWidget {
	struct UBP_Popup_BG_C* BP_Popup_BG; // 0x5b0(0x08)
};

