// WidgetBlueprintGeneratedClass UI_Banner_Map.UI_Banner_Map_C
// Size: 0x2e0 (Inherited: 0x2d0)
struct UUI_Banner_Map_C : ULMRMinimapBanner {
	struct ULMRImage* Bg_Banner; // 0x2d0(0x08)
	struct ULMRImage* fx_glow; // 0x2d8(0x08)
};

