// WidgetBlueprintGeneratedClass UI_Chat_VoiceRec.UI_Chat_VoiceRec_C
// Size: 0x2f0 (Inherited: 0x2e8)
struct UUI_Chat_VoiceRec_C : ULMRChatVoiceRecWidget {
	struct ULMRImage* LMRImage_72; // 0x2e8(0x08)
};

