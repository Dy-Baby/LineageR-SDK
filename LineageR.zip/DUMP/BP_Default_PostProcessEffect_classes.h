// BlueprintGeneratedClass BP_Default_PostProcessEffect.BP_Default_PostProcessEffect_C
// Size: 0x2a8 (Inherited: 0x2a8)
struct ABP_Default_PostProcessEffect_C : ALMRPostProcessEffect {
};

