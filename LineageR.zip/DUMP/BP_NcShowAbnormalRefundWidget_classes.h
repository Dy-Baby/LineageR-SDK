// WidgetBlueprintGeneratedClass BP_NcShowAbnormalRefundWidget.BP_NcShowAbnormalRefundWidget_C
// Size: 0x4b8 (Inherited: 0x4b0)
struct UBP_NcShowAbnormalRefundWidget_C : UNcShowAbnormalRefundWidget {
	struct UBP_NcShowAbnormalRefundSlot_C* BP_NcShowAbnormalRefundSlot; // 0x4b0(0x08)
};

