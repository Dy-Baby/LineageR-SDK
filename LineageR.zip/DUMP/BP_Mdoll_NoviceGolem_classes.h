// BlueprintGeneratedClass BP_Mdoll_NoviceGolem.BP_Mdoll_NoviceGolem_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_Mdoll_NoviceGolem_C : ALMRObject {
};

