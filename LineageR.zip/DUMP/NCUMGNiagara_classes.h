// Class NCUMGNiagara.UIParticleEmitterNC02
// Size: 0x168 (Inherited: 0x158)
struct UUIParticleEmitterNC02 : UUIFXEmitterNC01 {
	struct UNiagaraSystem* NiagaraSystem; // 0x158(0x08)
	struct UNiagaraComponent* NiagaraComponent; // 0x160(0x08)
};

