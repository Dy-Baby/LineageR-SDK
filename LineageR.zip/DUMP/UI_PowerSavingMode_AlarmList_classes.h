// WidgetBlueprintGeneratedClass UI_PowerSavingMode_AlarmList.UI_PowerSavingMode_AlarmList_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UUI_PowerSavingMode_AlarmList_C : ULMRPowerSavingModeAlarmSlotWidget {
};

