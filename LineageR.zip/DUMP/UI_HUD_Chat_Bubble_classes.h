// WidgetBlueprintGeneratedClass UI_HUD_Chat_Bubble.UI_HUD_Chat_Bubble_C
// Size: 0x4a8 (Inherited: 0x4a0)
struct UUI_HUD_Chat_Bubble_C : ULMRSpeechBubbleWidget {
	struct ULMRImage* Img_Bubble; // 0x4a0(0x08)
};

