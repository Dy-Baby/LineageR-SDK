// WidgetBlueprintGeneratedClass UI_HUD_party_participate.UI_HUD_party_participate_C
// Size: 0x360 (Inherited: 0x328)
struct UUI_HUD_party_participate_C : ULMRPartyParticipateWidget {
	struct ULMRImage* bg_Gradation_B; // 0x328(0x08)
	struct UHorizontalBox* HorizontalBox_1; // 0x330(0x08)
	struct ULMRImage* image_Cancle; // 0x338(0x08)
	struct ULMRImage* image_Cancle_2; // 0x340(0x08)
	struct ULMRImage* img_Notice; // 0x348(0x08)
	struct ULMRImage* Img_PartyInvite; // 0x350(0x08)
	struct ULMRImage* Img_PartyInvite_2; // 0x358(0x08)
};

