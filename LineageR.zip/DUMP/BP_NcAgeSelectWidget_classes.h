// WidgetBlueprintGeneratedClass BP_NcAgeSelectWidget.BP_NcAgeSelectWidget_C
// Size: 0x438 (Inherited: 0x430)
struct UBP_NcAgeSelectWidget_C : UNcAgeSelectWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x430(0x08)

	void Construct(); // Function BP_NcAgeSelectWidget.BP_NcAgeSelectWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_NcAgeSelectWidget(int32_t EntryPoint); // Function BP_NcAgeSelectWidget.BP_NcAgeSelectWidget_C.ExecuteUbergraph_BP_NcAgeSelectWidget // (Final|UbergraphFunction) // @ game+0x2849850
};

