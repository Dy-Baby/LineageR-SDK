// WidgetBlueprintGeneratedClass UI_HUD_Ping.UI_HUD_Ping_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UUI_HUD_Ping_C : ULMRPingWidget {
};

