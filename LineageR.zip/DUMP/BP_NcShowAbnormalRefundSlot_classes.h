// WidgetBlueprintGeneratedClass BP_NcShowAbnormalRefundSlot.BP_NcShowAbnormalRefundSlot_C
// Size: 0x488 (Inherited: 0x488)
struct UBP_NcShowAbnormalRefundSlot_C : UNcShowAbnormalRefundSlotWidget {
};

