// Class NcCrashReportSdk.NcCrashReportAPI
// Size: 0x28 (Inherited: 0x28)
struct UNcCrashReportAPI : UBlueprintFunctionLibrary {
};

// Class NcCrashReportSdk.NcCrashReportSdkBPLibrary
// Size: 0x28 (Inherited: 0x28)
struct UNcCrashReportSdkBPLibrary : UBlueprintFunctionLibrary {
};

// Class NcCrashReportSdk.NccrSettings
// Size: 0x58 (Inherited: 0x28)
struct UNccrSettings : UObject {
	bool disablePluginInitialization; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FString AppID; // 0x30(0x10)
	struct FString AppVersion; // 0x40(0x10)
	int32_t AndroidLogcatCount; // 0x50(0x04)
	bool EnableNCCrashReportDialog; // 0x54(0x01)
	char pad_55[0x3]; // 0x55(0x03)
};

