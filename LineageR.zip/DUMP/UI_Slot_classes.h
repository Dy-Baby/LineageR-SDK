// WidgetBlueprintGeneratedClass UI_Slot.UI_Slot_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct UUI_Slot_C : ULMRSlotWidget {
};

