// WidgetBlueprintGeneratedClass BP_Button_Close.BP_Button_Close_C
// Size: 0x300 (Inherited: 0x300)
struct UBP_Button_Close_C : ULMRTemplateButtonBase {
};

