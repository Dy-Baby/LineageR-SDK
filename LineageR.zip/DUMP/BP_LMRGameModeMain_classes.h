// BlueprintGeneratedClass BP_LMRGameModeMain.BP_LMRGameModeMain_C
// Size: 0x310 (Inherited: 0x2c0)
struct ABP_LMRGameModeMain_C : ALMRGameModeMain {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x2c8(0x08)
	struct FTransform ARAlignmentTM; // 0x2d0(0x30)
	bool IsARAlignmentMode; // 0x300(0x01)
	char pad_301[0x7]; // 0x301(0x07)
	struct UARTrackedGeometry* ARTrackedGeom; // 0x308(0x08)

	void ReceiveTick(float DeltaSeconds); // Function BP_LMRGameModeMain.BP_LMRGameModeMain_C.ReceiveTick // (Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_LMRGameModeMain(int32_t EntryPoint); // Function BP_LMRGameModeMain.BP_LMRGameModeMain_C.ExecuteUbergraph_BP_LMRGameModeMain // (Final|UbergraphFunction) // @ game+0x2849850
};

