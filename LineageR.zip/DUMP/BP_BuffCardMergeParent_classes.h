// BlueprintGeneratedClass BP_BuffCardMergeParent.BP_BuffCardMergeParent_C
// Size: 0x6b8 (Inherited: 0x6b0)
struct ABP_BuffCardMergeParent_C : ABP_BuffCardParent_C {
	struct USkeletalMeshComponent* ShadowMesh; // 0x6b0(0x08)
};

