// WidgetBlueprintGeneratedClass UI_InteractionButton.UI_InteractionButton_C
// Size: 0x5b0 (Inherited: 0x550)
struct UUI_InteractionButton_C : ULMRInteractionButtonWidget {
	struct ULMRImage* fx_circle; // 0x550(0x08)
	struct ULMRImage* Fx_GlowLight; // 0x558(0x08)
	struct ULMRImage* Img_Atteck; // 0x560(0x08)
	struct ULMRImage* Img_Collection; // 0x568(0x08)
	struct ULMRImage* Img_Fishing; // 0x570(0x08)
	struct ULMRImage* Img_Foot; // 0x578(0x08)
	struct ULMRImage* Img_Investigate; // 0x580(0x08)
	struct ULMRImage* Img_Loot; // 0x588(0x08)
	struct ULMRImage* Img_Make; // 0x590(0x08)
	struct ULMRImage* img_None; // 0x598(0x08)
	struct ULMRImage* Img_TouchObject; // 0x5a0(0x08)
	struct ULMRImage* Img_UseItemObject; // 0x5a8(0x08)
};

