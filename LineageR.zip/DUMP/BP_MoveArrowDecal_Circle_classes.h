// BlueprintGeneratedClass BP_MoveArrowDecal_Circle.BP_MoveArrowDecal_Circle_C
// Size: 0x240 (Inherited: 0x240)
struct ABP_MoveArrowDecal_Circle_C : ALMRMoveArrowDecal {
};

