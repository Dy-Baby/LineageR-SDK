// UserDefinedEnum EnumAiState.EnumAiState
enum class EnumAiState : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	EnumAiState_MAX = 2
};

