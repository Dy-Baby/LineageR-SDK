// WidgetBlueprintGeneratedClass UI_ScreenTouchEffect.UI_ScreenTouchEffect_C
// Size: 0x440 (Inherited: 0x440)
struct UUI_ScreenTouchEffect_C : ULMRScreenTouchEffectWidget {
};

