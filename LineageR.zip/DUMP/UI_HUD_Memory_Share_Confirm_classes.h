// WidgetBlueprintGeneratedClass UI_HUD_Memory_Share_Confirm.UI_HUD_Memory_Share_Confirm_C
// Size: 0x2e8 (Inherited: 0x2e0)
struct UUI_HUD_Memory_Share_Confirm_C : ULMRMemoryShareConfirmWidget {
	struct ULMRListView* LMRListView_43; // 0x2e0(0x08)
};

