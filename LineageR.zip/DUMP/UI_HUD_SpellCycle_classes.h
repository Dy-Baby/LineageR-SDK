// WidgetBlueprintGeneratedClass UI_HUD_SpellCycle.UI_HUD_SpellCycle_C
// Size: 0x390 (Inherited: 0x390)
struct UUI_HUD_SpellCycle_C : ULMRSpellAutoCycleWidget {
};

