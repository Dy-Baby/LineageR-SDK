// WidgetBlueprintGeneratedClass UI_SimpleSlot.UI_SimpleSlot_C
// Size: 0x558 (Inherited: 0x558)
struct UUI_SimpleSlot_C : ULMRSimpleSlot {
};

