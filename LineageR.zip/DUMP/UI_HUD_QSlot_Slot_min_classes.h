// WidgetBlueprintGeneratedClass UI_HUD_QSlot_Slot_min.UI_HUD_QSlot_Slot_min_C
// Size: 0x5b0 (Inherited: 0x5b0)
struct UUI_HUD_QSlot_Slot_min_C : ULMRHudQuickSlotSmall {
};

