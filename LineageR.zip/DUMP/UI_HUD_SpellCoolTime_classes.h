// WidgetBlueprintGeneratedClass UI_HUD_SpellCoolTime.UI_HUD_SpellCoolTime_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct UUI_HUD_SpellCoolTime_C : ULMRSpellCoolTimeWidget {
};

