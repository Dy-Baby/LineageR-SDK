// ScriptStruct LWCutscene.LMRMovieSceneAnimationParams
// Size: 0xa8 (Inherited: 0x00)
struct FLMRMovieSceneAnimationParams {
	int32_t motionType_; // 0x00(0x04)
	float playRate_; // 0x04(0x04)
	struct FMovieSceneFloatChannel weight_; // 0x08(0xa0)
};

// ScriptStruct LWCutscene.LMRMovieSceneAnimationTypeTemplate
// Size: 0xd0 (Inherited: 0x20)
struct FLMRMovieSceneAnimationTypeTemplate : FMovieSceneEvalTemplate {
	struct FLMRMovieSceneAnimationParams params_; // 0x20(0xa8)
	struct FFrameNumber sectionStartTime_; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
};

