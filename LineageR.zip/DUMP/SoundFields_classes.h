// Class SoundFields.AmbisonicsEncodingSettings
// Size: 0x30 (Inherited: 0x28)
struct UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase {
	int32_t AmbisonicsOrder; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
};

