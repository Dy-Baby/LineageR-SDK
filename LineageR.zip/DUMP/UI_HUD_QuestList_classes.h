// WidgetBlueprintGeneratedClass UI_HUD_QuestList.UI_HUD_QuestList_C
// Size: 0x758 (Inherited: 0x718)
struct UUI_HUD_QuestList_C : ULMRQuestTrackerItemWidget {
	struct ULMRImage* GuideBox; // 0x718(0x08)
	struct ULMRImage* img_Auto; // 0x720(0x08)
	struct ULMRImage* Img_BasicBG; // 0x728(0x08)
	struct ULMRImage* Img_Teleport; // 0x730(0x08)
	struct ULMRImage* questlist_UIFX_Icon_spin_2; // 0x738(0x08)
	struct ULMRImage* uiFX_Complete_Start_2; // 0x740(0x08)
	struct ULMRImage* UIFX_Num_Glow; // 0x748(0x08)
	struct ULMRImage* UIFX_Num_Glow_2; // 0x750(0x08)
};

