// WidgetBlueprintGeneratedClass BP_NcDeviceListWidget.BP_NcDeviceListWidget_C
// Size: 0x468 (Inherited: 0x460)
struct UBP_NcDeviceListWidget_C : UNcDeviceListWidget {
	struct UBP_NcDeviceListSlotWidget_C* BP_NcDeviceListSlotWidget; // 0x460(0x08)
};

