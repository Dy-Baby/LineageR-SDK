// WidgetBlueprintGeneratedClass BP_NcShowLoginWidget.BP_NcShowLoginWidget_C
// Size: 0x500 (Inherited: 0x500)
struct UBP_NcShowLoginWidget_C : UNcShowLoginWidget {
};

