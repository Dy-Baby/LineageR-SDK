// UserDefinedEnum ENiagaraRandomnessMode.ENiagaraRandomnessMode
enum class ENiagaraRandomnessMode : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ENiagaraRandomnessMode_MAX = 3
};

