// WidgetBlueprintGeneratedClass BP_NcGooglePlayAccountCheckWidget.BP_NcGooglePlayAccountCheckWidget_C
// Size: 0x440 (Inherited: 0x438)
struct UBP_NcGooglePlayAccountCheckWidget_C : UNcGooglePlayAccountCheckWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x438(0x08)

	void Construct(); // Function BP_NcGooglePlayAccountCheckWidget.BP_NcGooglePlayAccountCheckWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_NcGooglePlayAccountCheckWidget(int32_t EntryPoint); // Function BP_NcGooglePlayAccountCheckWidget.BP_NcGooglePlayAccountCheckWidget_C.ExecuteUbergraph_BP_NcGooglePlayAccountCheckWidget // (Final|UbergraphFunction) // @ game+0x2849850
};

