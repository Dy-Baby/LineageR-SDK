// BlueprintGeneratedClass TI_E02.TI_E02_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_E02_C : ALevelScriptActor {
};

