// BlueprintGeneratedClass TI_E03.TI_E03_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_E03_C : ALevelScriptActor {
};

