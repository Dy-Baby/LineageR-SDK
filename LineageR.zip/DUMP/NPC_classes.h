// BlueprintGeneratedClass NPC.NPC_C
// Size: 0x228 (Inherited: 0x228)
struct ANPC_C : ALevelScriptActor {
};

