// BlueprintGeneratedClass BP_PlayerObjectComponent.BP_PlayerObjectComponent_C
// Size: 0x290 (Inherited: 0x290)
struct UBP_PlayerObjectComponent_C : ULMRPlayerObjectComponent {
};

