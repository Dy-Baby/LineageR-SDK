// WidgetBlueprintGeneratedClass BP_Button_Cancel.BP_Button_Cancel_C
// Size: 0x3a0 (Inherited: 0x378)
struct UBP_Button_Cancel_C : ULMRTemplateTextButton {
	struct UWidgetAnimation* Anim_Select_off; // 0x378(0x08)
	struct UWidgetAnimation* Anim_Select_on; // 0x380(0x08)
	struct ULMRImage* Img_Check; // 0x388(0x08)
	struct ULMRImage* Img_Focuse; // 0x390(0x08)
	struct ULMRImage* img_Progress; // 0x398(0x08)
};

