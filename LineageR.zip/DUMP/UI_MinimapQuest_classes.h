// WidgetBlueprintGeneratedClass UI_MinimapQuest.UI_MinimapQuest_C
// Size: 0x318 (Inherited: 0x318)
struct UUI_MinimapQuest_C : ULMRMinimapQuestWidget {
};

