// WidgetBlueprintGeneratedClass UI_HUD_gnb.UI_HUD_gnb_C
// Size: 0x338 (Inherited: 0x310)
struct UUI_HUD_gnb_C : ULMRCurrencyWidget {
	struct UButton* adena_btn; // 0x310(0x08)
	struct ULMRImage* adena_btn_img; // 0x318(0x08)
	struct UButton* BmShop_btn_2; // 0x320(0x08)
	struct ULMRImage* dia_btn_img; // 0x328(0x08)
	struct UButton* seal_btn; // 0x330(0x08)
};

