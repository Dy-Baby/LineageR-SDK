// WidgetBlueprintGeneratedClass UI_HUD_QSlot_Target.UI_HUD_QSlot_Target_C
// Size: 0x3b8 (Inherited: 0x388)
struct UUI_HUD_QSlot_Target_C : ULMRQuickSlotAssistTargetWidget {
	struct ULMRImage* Img_QSlot_SelectR_BG; // 0x388(0x08)
	struct ULMRImage* Img_QSlot_SelectR_BottomLine; // 0x390(0x08)
	struct ULMRImage* Img_QSlot_SelectR_VtLine1; // 0x398(0x08)
	struct ULMRImage* Img_QSlot_SelectR_VtLine2; // 0x3a0(0x08)
	struct ULMRImage* Img_QSlot_SelectR_VtLine3; // 0x3a8(0x08)
	struct UUI_HUD_BuffListSlot_S_C* UI_HUD_BuffSlot_Targetting; // 0x3b0(0x08)
};

