// BlueprintGeneratedClass BP_LMRGameViewportClient.BP_LMRGameViewportClient_C
// Size: 0x348 (Inherited: 0x348)
struct UBP_LMRGameViewportClient_C : ULMRGameViewportClient {
};

