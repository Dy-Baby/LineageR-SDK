// WidgetBlueprintGeneratedClass UI_WidgetNameTag.UI_WidgetNameTag_C
// Size: 0x4b0 (Inherited: 0x4b0)
struct UUI_WidgetNameTag_C : ULMRWidgetNameTagWidget {
};

