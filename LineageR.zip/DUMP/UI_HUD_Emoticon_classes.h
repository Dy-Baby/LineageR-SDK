// WidgetBlueprintGeneratedClass UI_HUD_Emoticon.UI_HUD_Emoticon_C
// Size: 0x310 (Inherited: 0x308)
struct UUI_HUD_Emoticon_C : ULMREmoticonHudWidget {
	struct ULMRImage* BG; // 0x308(0x08)
};

