// WidgetBlueprintGeneratedClass BP_NcInputTextAlertWidget.BP_NcInputTextAlertWidget_C
// Size: 0x408 (Inherited: 0x408)
struct UBP_NcInputTextAlertWidget_C : UNcInputTextAlertWidget {
};

