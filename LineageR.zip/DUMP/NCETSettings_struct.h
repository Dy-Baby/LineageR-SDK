// ScriptStruct NCETSettings.SequenceDynamicParamDefaultKeyNameSetting
// Size: 0x20 (Inherited: 0x00)
struct FSequenceDynamicParamDefaultKeyNameSetting {
	struct FString DefaultParamPath; // 0x00(0x10)
	struct FString DefaultKeyName; // 0x10(0x10)
};

// ScriptStruct NCETSettings.LMRSubtitleInfo
// Size: 0x40 (Inherited: 0x00)
struct FLMRSubtitleInfo {
	struct FString IdFieldName; // 0x00(0x10)
	struct FString LanguageFieldName; // 0x10(0x10)
	struct FString TextFieldName; // 0x20(0x10)
	struct FFilePath ParseFilePath; // 0x30(0x10)
};

// ScriptStruct NCETSettings.LangagueInfo
// Size: 0x20 (Inherited: 0x00)
struct FLangagueInfo {
	struct FString LanguageName; // 0x00(0x10)
	struct TArray<struct FFilePath> ParseFilePaths; // 0x10(0x10)
};

