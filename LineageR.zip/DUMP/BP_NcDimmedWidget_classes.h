// WidgetBlueprintGeneratedClass BP_NcDimmedWidget.BP_NcDimmedWidget_C
// Size: 0x3e8 (Inherited: 0x3e8)
struct UBP_NcDimmedWidget_C : UNcDimmedWidget {
};

