// BlueprintGeneratedClass BP_HyperLinkDecorator.BP_HyperLinkDecorator_C
// Size: 0x30 (Inherited: 0x30)
struct UBP_HyperLinkDecorator_C : ULMRHyperLinkRichTextBlockDecorator {
};

