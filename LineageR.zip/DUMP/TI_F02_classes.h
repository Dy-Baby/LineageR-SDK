// BlueprintGeneratedClass TI_F02.TI_F02_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_F02_C : ALevelScriptActor {
};

