// WidgetBlueprintGeneratedClass UI_HUD_QSlot_Big.UI_HUD_QSlot_Big_C
// Size: 0x350 (Inherited: 0x340)
struct UUI_HUD_QSlot_Big_C : ULMRQuickSlotBigWidget {
	struct ULMRImage* GuideBox; // 0x340(0x08)
	struct ULMRImage* Img_QSlot_ArrowRight; // 0x348(0x08)
};

