// WidgetBlueprintGeneratedClass BP_NcShowLoginProviderSquareWidget.BP_NcShowLoginProviderSquareWidget_C
// Size: 0x490 (Inherited: 0x490)
struct UBP_NcShowLoginProviderSquareWidget_C : UNcShowLoginProviderSquareWidget {
};

