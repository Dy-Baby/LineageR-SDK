// WidgetBlueprintGeneratedClass BP_NcGeneralWebviewWidget.BP_NcGeneralWebViewWidget_C
// Size: 0x4a0 (Inherited: 0x4a0)
struct UBP_NcGeneralWebViewWidget_C : UNcGeneralWebViewWidget {
};

