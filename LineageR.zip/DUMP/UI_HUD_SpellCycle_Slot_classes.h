// WidgetBlueprintGeneratedClass UI_HUD_SpellCycle_Slot.UI_HUD_SpellCycle_Slot_C
// Size: 0x2e8 (Inherited: 0x2d0)
struct UUI_HUD_SpellCycle_Slot_C : ULMRSpellAutoCycleSlotWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2d0(0x08)
	struct UWidgetAnimation* Ani_On; // 0x2d8(0x08)
	struct ULMRImage* img_Glow; // 0x2e0(0x08)

	void PlayCycleOnAnimation(); // Function UI_HUD_SpellCycle_Slot.UI_HUD_SpellCycle_Slot_C.PlayCycleOnAnimation // (Event|Protected|BlueprintEvent) // @ game+0x2849850
	void StopCycleOnAnimation(); // Function UI_HUD_SpellCycle_Slot.UI_HUD_SpellCycle_Slot_C.StopCycleOnAnimation // (Event|Protected|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_UI_HUD_SpellCycle_Slot(int32_t EntryPoint); // Function UI_HUD_SpellCycle_Slot.UI_HUD_SpellCycle_Slot_C.ExecuteUbergraph_UI_HUD_SpellCycle_Slot // (Final|UbergraphFunction) // @ game+0x2849850
};

