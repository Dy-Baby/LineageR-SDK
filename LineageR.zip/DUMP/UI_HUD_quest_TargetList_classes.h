// WidgetBlueprintGeneratedClass UI_HUD_quest_TargetList.UI_HUD_quest_TargetList_C
// Size: 0x3f8 (Inherited: 0x3e8)
struct UUI_HUD_quest_TargetList_C : ULMRTargetTrackerItemWidget {
	struct ULMRImage* BGImage_Friendly; // 0x3e8(0x08)
	struct ULMRImage* Image_MonsterIcn; // 0x3f0(0x08)
};

