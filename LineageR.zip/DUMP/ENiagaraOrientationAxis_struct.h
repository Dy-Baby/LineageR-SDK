// UserDefinedEnum ENiagaraOrientationAxis.ENiagaraOrientationAxis
enum class ENiagaraOrientationAxis : uint8 {
	NewEnumerator0 = 0,
	NewEnumerator1 = 1,
	NewEnumerator2 = 2,
	ENiagaraOrientationAxis_MAX = 3
};

