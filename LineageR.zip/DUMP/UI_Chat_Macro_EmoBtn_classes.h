// WidgetBlueprintGeneratedClass UI_Chat_Macro_EmoBtn.UI_Chat_Macro_EmoBtn_C
// Size: 0x578 (Inherited: 0x568)
struct UUI_Chat_Macro_EmoBtn_C : ULMRChatMacroEmoWidget {
	struct UBorder* fx_rect_line; // 0x568(0x08)
	struct UOverlay* Overlay_Slot; // 0x570(0x08)
};

