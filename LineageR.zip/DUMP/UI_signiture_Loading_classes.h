// WidgetBlueprintGeneratedClass UI_signiture_Loading.UI_signiture_Loading_C
// Size: 0x2f8 (Inherited: 0x2c0)
struct UUI_signiture_Loading_C : ULMRSignatureLoadingWidget {
	struct ULMRImage* fx_glow; // 0x2c0(0x08)
	struct ULMRImage* FX_Rotateglow; // 0x2c8(0x08)
	struct ULMRImage* Img_LoadingPattern; // 0x2d0(0x08)
	struct ULMRImage* Moon; // 0x2d8(0x08)
	struct ULMRImage* Niddle01; // 0x2e0(0x08)
	struct ULMRImage* Niddle02; // 0x2e8(0x08)
	struct ULMRImage* Sun; // 0x2f0(0x08)
};

