// WidgetBlueprintGeneratedClass UI_ActionButton.UI_ActionButton_C
// Size: 0x5e8 (Inherited: 0x578)
struct UUI_ActionButton_C : ULMRActionButtonWidget {
	struct UWidgetAnimation* ani_TargetOn_ORI; // 0x578(0x08)
	struct UWidgetAnimation* ani_Press_ori; // 0x580(0x08)
	struct UOverlay* BG_Black; // 0x588(0x08)
	struct ULMRImage* ButtonBg; // 0x590(0x08)
	struct ULMRImage* fx_circle_Deco_Auto_N; // 0x598(0x08)
	struct ULMRImage* fx_circle_Deco_N; // 0x5a0(0x08)
	struct ULMRImage* fx_circle_glowOutline_N; // 0x5a8(0x08)
	struct ULMRImage* fx_circle_line2; // 0x5b0(0x08)
	struct ULMRImage* fx_glow_N; // 0x5b8(0x08)
	struct ULMRImage* fx_Line_N; // 0x5c0(0x08)
	struct ULMRImage* GuideBox; // 0x5c8(0x08)
	struct ULMRImage* Img_Gathering; // 0x5d0(0x08)
	struct ULMRImage* Img_Get; // 0x5d8(0x08)
	struct ULMRImage* Img_PvP; // 0x5e0(0x08)
};

