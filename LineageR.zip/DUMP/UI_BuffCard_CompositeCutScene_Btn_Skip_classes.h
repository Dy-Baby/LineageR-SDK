// WidgetBlueprintGeneratedClass UI_BuffCard_CompositeCutScene_Btn_Skip.UI_BuffCard_CompositeCutScene_Btn_Skip_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UUI_BuffCard_CompositeCutScene_Btn_Skip_C : ULMRBuffCardCompositeSkipWidget {
};

