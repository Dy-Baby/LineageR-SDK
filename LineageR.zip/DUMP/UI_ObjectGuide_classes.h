// WidgetBlueprintGeneratedClass UI_ObjectGuide.UI_ObjectGuide_C
// Size: 0x340 (Inherited: 0x340)
struct UUI_ObjectGuide_C : ULMROffScreenObjectGuideWidget {
};

