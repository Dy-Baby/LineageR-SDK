// BlueprintGeneratedClass BP_MinimapGuideDecal.BP_MinimapGuideDecal_C
// Size: 0x250 (Inherited: 0x250)
struct ABP_MinimapGuideDecal_C : ALMRDecalActor {
};

