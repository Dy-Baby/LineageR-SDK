// WidgetBlueprintGeneratedClass UI_HUD_Communication.UI_HUD_Communication_C
// Size: 0x3a8 (Inherited: 0x398)
struct UUI_HUD_Communication_C : ULMRUserCommWidget {
	struct ULMRImage* FX_Patternmask; // 0x398(0x08)
	struct ULMRImage* FX_PatternNoise; // 0x3a0(0x08)
};

