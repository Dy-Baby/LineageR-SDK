// WidgetBlueprintGeneratedClass BP_NcWebBrowser.BP_NcWebBrowser_C
// Size: 0x2b8 (Inherited: 0x2b8)
struct UBP_NcWebBrowser_C : UNcWebBrowser {
};

