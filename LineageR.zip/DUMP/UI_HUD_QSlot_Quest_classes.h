// WidgetBlueprintGeneratedClass UI_HUD_QSlot_Quest.UI_HUD_QSlot_Quest_C
// Size: 0x2d8 (Inherited: 0x2c8)
struct UUI_HUD_QSlot_Quest_C : ULMRQuickSlotQuestWidget {
	struct ULMRImage* GuideBox; // 0x2c8(0x08)
	struct ULMRImage* GuideTarget; // 0x2d0(0x08)
};

