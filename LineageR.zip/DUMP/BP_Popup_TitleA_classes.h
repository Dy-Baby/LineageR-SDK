// WidgetBlueprintGeneratedClass BP_Popup_TitleA.BP_Popup_TitleA_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UBP_Popup_TitleA_C : ULMRTemplateTitleWithText {
	struct ULMRImage* UI_Bg_PopupTitle; // 0x2c8(0x08)
};

