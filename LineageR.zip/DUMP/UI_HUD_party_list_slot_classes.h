// WidgetBlueprintGeneratedClass UI_HUD_party_list_slot.UI_HUD_party_list_slot_C
// Size: 0x328 (Inherited: 0x310)
struct UUI_HUD_party_list_slot_C : ULMRPartyTrackerItemWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x310(0x08)
	struct ULMRImage* Img_Plus1; // 0x318(0x08)
	struct ULMRImage* Img_Plus2; // 0x320(0x08)

	void PreConstruct(bool IsDesignTime); // Function UI_HUD_party_list_slot.UI_HUD_party_list_slot_C.PreConstruct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_UI_HUD_party_list_slot(int32_t EntryPoint); // Function UI_HUD_party_list_slot.UI_HUD_party_list_slot_C.ExecuteUbergraph_UI_HUD_party_list_slot // (Final|UbergraphFunction) // @ game+0x2849850
};

