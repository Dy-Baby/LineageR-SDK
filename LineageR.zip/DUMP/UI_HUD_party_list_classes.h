// WidgetBlueprintGeneratedClass UI_HUD_party_list.UI_HUD_party_list_C
// Size: 0x338 (Inherited: 0x308)
struct UUI_HUD_party_list_C : ULMRPartyTrackerWidget {
	struct ULMRImage* icon_Party; // 0x308(0x08)
	struct ULMRImage* img_DividerDot; // 0x310(0x08)
	struct ULMRImage* LMRImage; // 0x318(0x08)
	struct UUI_HUD_party_list_slot_C* UI_HUD_party_list_slot_1; // 0x320(0x08)
	struct UUI_HUD_party_list_slot_C* UI_HUD_party_list_slot_2; // 0x328(0x08)
	struct UUI_HUD_party_list_slot_C* UI_HUD_party_list_slot_3; // 0x330(0x08)
};

