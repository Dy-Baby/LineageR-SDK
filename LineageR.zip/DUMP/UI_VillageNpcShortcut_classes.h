// WidgetBlueprintGeneratedClass UI_VillageNpcShortcut.UI_VillageNpcShortcut_C
// Size: 0x4d0 (Inherited: 0x4b0)
struct UUI_VillageNpcShortcut_C : ULMRVillageNpcShortcutWidget {
	struct ULMRImage* img_Bg; // 0x4b0(0x08)
	struct ULMRImage* Img_Pattern01; // 0x4b8(0x08)
	struct ULMRImage* Img_Pattern02; // 0x4c0(0x08)
	struct ULMRImage* Img_Pattern03; // 0x4c8(0x08)
};

