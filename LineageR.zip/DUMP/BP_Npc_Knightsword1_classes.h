// BlueprintGeneratedClass BP_Npc_Knightsword1.BP_Npc_Knightsword1_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_Npc_Knightsword1_C : ALMRObject {
};

