// WidgetBlueprintGeneratedClass UI_BuffCard_Info_3DCard.UI_BuffCard_Info_3DCard_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UUI_BuffCard_Info_3DCard_C : ULMRBuffCardInfo3DWidget {
};

