// BlueprintGeneratedClass TI_G02.TI_G02_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_G02_C : ALevelScriptActor {
};

