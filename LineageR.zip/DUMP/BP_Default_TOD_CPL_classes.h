// BlueprintGeneratedClass BP_Default_TOD_CPL.BP_Default_TOD_CPL_C
// Size: 0x360 (Inherited: 0x360)
struct UBP_Default_TOD_CPL_C : ULMRCharacterPointLightComponent {
};

