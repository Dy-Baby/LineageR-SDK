// WidgetBlueprintGeneratedClass UI_HUD_BuffListSlot_S.UI_HUD_BuffListSlot_S_C
// Size: 0x558 (Inherited: 0x558)
struct UUI_HUD_BuffListSlot_S_C : ULMRBuffIconWidget {
};

