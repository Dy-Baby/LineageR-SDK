// WidgetBlueprintGeneratedClass UI_HUD_Clan_PartyList.UI_HUD_Clan_PartyList_C
// Size: 0x268 (Inherited: 0x258)
struct UUI_HUD_Clan_PartyList_C : UUserWidget {
	struct ULMRImageSwitcher* Icon_Class; // 0x258(0x08)
	struct ULMRRichTextBlockNC* RText_Name_Party; // 0x260(0x08)
};

