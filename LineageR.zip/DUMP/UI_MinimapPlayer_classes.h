// WidgetBlueprintGeneratedClass UI_MinimapPlayer.UI_MinimapPlayer_C
// Size: 0x2c0 (Inherited: 0x2c0)
struct UUI_MinimapPlayer_C : ULMRMinimapPlayerWidget {
};

