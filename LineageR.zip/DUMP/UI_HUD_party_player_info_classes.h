// WidgetBlueprintGeneratedClass UI_HUD_party_player_info.UI_HUD_party_player_info_C
// Size: 0x528 (Inherited: 0x4e0)
struct UUI_HUD_party_player_info_C : ULMRPartyPlayerInfoWidget {
	struct UHorizontalBox* buff_list; // 0x4e0(0x08)
	struct UHorizontalBox* buffAll_list; // 0x4e8(0x08)
	struct UHorizontalBox* debuff_list; // 0x4f0(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_2; // 0x4f8(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_3; // 0x500(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_4; // 0x508(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_5; // 0x510(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_6; // 0x518(0x08)
	struct UUI_HUD_BuffListSlot_S_C* ui_HUD_BuffSlot_S_7; // 0x520(0x08)
};

