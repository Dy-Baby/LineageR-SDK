// Class NCCineMediaAssets.CineMediaCaptionSection
// Size: 0x148 (Inherited: 0x130)
struct UCineMediaCaptionSection : UMovieSceneSection {
	int32_t SubtitleId; // 0x130(0x04)
	int32_t PreviewLanguageId; // 0x134(0x04)
	struct FString CaptionString; // 0x138(0x10)
};

// Class NCCineMediaAssets.CineMediaCaptionTrack
// Size: 0x68 (Inherited: 0x58)
struct UCineMediaCaptionTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Class NCCineMediaAssets.CineMediaCaptionWidget
// Size: 0x260 (Inherited: 0x258)
struct UCineMediaCaptionWidget : UUserWidget {
	char pad_258[0x8]; // 0x258(0x08)
};

// Class NCCineMediaAssets.CineMediaCaptionWidgetInterface
// Size: 0x28 (Inherited: 0x28)
struct UCineMediaCaptionWidgetInterface : UInterface {

	void ToggleCaptionVisible(bool bVisible); // Function NCCineMediaAssets.CineMediaCaptionWidgetInterface.ToggleCaptionVisible // (Event|Public|BlueprintEvent) // @ game+0x2849850
	void SetCaptionText(struct FText& CaptionText); // Function NCCineMediaAssets.CineMediaCaptionWidgetInterface.SetCaptionText // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x2849850
};

// Class NCCineMediaAssets.CineMediaLanguageGroupFolder
// Size: 0x80 (Inherited: 0x70)
struct UCineMediaLanguageGroupFolder : UMovieSceneFolder {
	struct FString languageCode; // 0x70(0x10)
};

// Class NCCineMediaAssets.CineMediaMaterial
// Size: 0x4e8 (Inherited: 0x4e8)
struct UCineMediaMaterial : UMaterial {
};

// Class NCCineMediaAssets.CineMediaSequence
// Size: 0x4d0 (Inherited: 0x348)
struct UCineMediaSequence : UMovieSceneSequence {
	struct FString FilePath; // 0x348(0x10)
	struct UUserWidget* CineMediaCaptionWidget; // 0x358(0x08)
	enum class ECineMediaViewportScale ViewportScale; // 0x360(0x01)
	char pad_361[0x3]; // 0x361(0x03)
	struct FLinearColor BorderColor; // 0x364(0x10)
	bool bDisableWorldRendering; // 0x374(0x01)
	bool bMuteSound; // 0x375(0x01)
	char pad_376[0x32]; // 0x376(0x32)
	struct UMovieScene* MovieScene; // 0x3a8(0x08)
	struct UFileMediaSource* VideoFileSource; // 0x3b0(0x08)
	struct UMediaTexture* CineMediaTexture; // 0x3b8(0x08)
	struct UMediaPlayer* CineMediaPlayer; // 0x3c0(0x08)
	struct UMaterial* CineMediaMaterial; // 0x3c8(0x08)
	bool bUseExternalMaterial; // 0x3d0(0x01)
	char pad_3D1[0x7]; // 0x3d1(0x07)
	struct UMaterial* ExternalMediaMaterial; // 0x3d8(0x08)
	struct FName TextureParameterName; // 0x3e0(0x08)
	struct UMaterialInstanceDynamic* ExternalMediaMaterialInstance; // 0x3e8(0x08)
	char pad_3F0[0x40]; // 0x3f0(0x40)
	struct TScriptInterface<ICineMediaCaptionWidgetInterface> CineMediaCaptionWidgetInstance; // 0x430(0x10)
	struct FIntPoint VideoDimension; // 0x440(0x08)
	char pad_448[0x10]; // 0x448(0x10)
	struct FGuid VideoTrackGuid; // 0x458(0x10)
	struct FGuid VideoSectionGuid; // 0x468(0x10)
	struct TMap<struct FGuid, struct FString> LanguageTrackMap; // 0x478(0x50)
	char pad_4C8[0x8]; // 0x4c8(0x08)

	void OnOpenFailedCineMedia(struct FString OpenedUrl); // Function NCCineMediaAssets.CineMediaSequence.OnOpenFailedCineMedia // (Final|Native|Public) // @ game+0xa4c7f0
	void OnOpenedCineMedia(struct FString OpenedUrl); // Function NCCineMediaAssets.CineMediaSequence.OnOpenedCineMedia // (Final|Native|Public) // @ game+0xa4c8d0
};

// Class NCCineMediaAssets.CineMediaSequencePlayer
// Size: 0x8e8 (Inherited: 0x8d8)
struct UCineMediaSequencePlayer : UMovieSceneSequencePlayer {
	char pad_8D8[0x10]; // 0x8d8(0x10)

	void StopCineMediaSequence(struct UObject* InWorldContextObject); // Function NCCineMediaAssets.CineMediaSequencePlayer.StopCineMediaSequence // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa4cd00
	void PlayCineMediaSequenceAsync(struct UObject* InWorldContextObject, struct FSoftObjectPath InCineMediaSequence, struct FMovieSceneSequencePlaybackSettings InPlaybackSettings, struct FString InOverrideLanguageCode); // Function NCCineMediaAssets.CineMediaSequencePlayer.PlayCineMediaSequenceAsync // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0xa4cb20
	void PlayCineMediaSequence(struct UObject* InWorldContextObject, struct UCineMediaSequence* InCineMediaSequence, struct FMovieSceneSequencePlaybackSettings InPlaybackSettings, struct FString InOverrideLanguageCode); // Function NCCineMediaAssets.CineMediaSequencePlayer.PlayCineMediaSequence // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa4c9b0
};

// Class NCCineMediaAssets.CineMediaSequenceActor
// Size: 0x260 (Inherited: 0x220)
struct ACineMediaSequenceActor : AActor {
	struct UCineMediaSequencePlayer* CineMediaSequencePlayer; // 0x220(0x08)
	struct UMediaSoundComponent* CineMediaSoundComponent; // 0x228(0x08)
	char pad_230[0x30]; // 0x230(0x30)
};

// Class NCCineMediaAssets.CineMediaVideoSection
// Size: 0x160 (Inherited: 0x130)
struct UCineMediaVideoSection : UMovieSceneSection {
	struct UMediaSource* MediaSource; // 0x130(0x08)
	bool bLooping; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	struct FFrameNumber StartFrameOffset; // 0x13c(0x04)
	struct UMediaTexture* MediaTexture; // 0x140(0x08)
	struct UMediaSoundComponent* MediaSoundComponent; // 0x148(0x08)
	bool bUseExternalMediaPlayer; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct UMediaPlayer* ExternalMediaPlayer; // 0x158(0x08)
};

// Class NCCineMediaAssets.CineMediaVideoTrack
// Size: 0x68 (Inherited: 0x58)
struct UCineMediaVideoTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> MediaSections; // 0x58(0x10)
};

