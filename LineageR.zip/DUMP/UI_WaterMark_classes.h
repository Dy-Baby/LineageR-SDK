// WidgetBlueprintGeneratedClass UI_WaterMark.UI_WaterMark_C
// Size: 0x2d8 (Inherited: 0x2d8)
struct UUI_WaterMark_C : ULMRWaterMarkWidget {
};

