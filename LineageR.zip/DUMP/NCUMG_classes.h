// Class NCUMG.BackgroundBlurNC01
// Size: 0x208 (Inherited: 0x148)
struct UBackgroundBlurNC01 : UContentWidget {
	struct FMargin Padding; // 0x148(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x158(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x159(0x01)
	bool bApplyAlphaToBlur; // 0x15a(0x01)
	char pad_15B[0x1]; // 0x15b(0x01)
	float BlurStrength; // 0x15c(0x04)
	bool bOverrideAutoRadiusCalculation; // 0x160(0x01)
	char pad_161[0x3]; // 0x161(0x03)
	int32_t BlurRadius; // 0x164(0x04)
	struct FSlateBrush LowQualityFallbackBrush; // 0x168(0x88)
	struct UTexture2D* MaskingTexture; // 0x1f0(0x08)
	char pad_1F8[0x10]; // 0x1f8(0x10)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function NCUMG.BackgroundBlurNC01.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x9fb090
	void SetPadding(struct FMargin InPadding); // Function NCUMG.BackgroundBlurNC01.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0x9fad90
	void SetMaskingTexture(struct UTexture2D* InTexture); // Function NCUMG.BackgroundBlurNC01.SetMaskingTexture // (Final|Native|Public|BlueprintCallable) // @ game+0x9fad10
	void SetLowQualityFallbackBrush(struct FSlateBrush& InBrush); // Function NCUMG.BackgroundBlurNC01.SetLowQualityFallbackBrush // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9fab90
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function NCUMG.BackgroundBlurNC01.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa730
	void SetBlurStrength(float InStrength); // Function NCUMG.BackgroundBlurNC01.SetBlurStrength // (Native|Public|BlueprintCallable) // @ game+0x9fa4f0
	void SetBlurRadius(int32_t InBlurRadius); // Function NCUMG.BackgroundBlurNC01.SetBlurRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa470
	void SetApplyAlphaToBlur(bool bInApplyAlphaToBlur); // Function NCUMG.BackgroundBlurNC01.SetApplyAlphaToBlur // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa3e0
};

// Class NCUMG.BackgroundBlurSlotNC01
// Size: 0x60 (Inherited: 0x38)
struct UBackgroundBlurSlotNC01 : UPanelSlot {
	struct FMargin Padding; // 0x38(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x48(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x49(0x01)
	char pad_4A[0x16]; // 0x4a(0x16)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function NCUMG.BackgroundBlurSlotNC01.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x9fb110
	void SetPadding(struct FMargin InPadding); // Function NCUMG.BackgroundBlurSlotNC01.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0x9fae20
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function NCUMG.BackgroundBlurSlotNC01.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa7b0
};

// Class NCUMG.ComboBoxStringNC01
// Size: 0x1030 (Inherited: 0x130)
struct UComboBoxStringNC01 : UWidget {
	struct TArray<struct FString> DefaultOptions; // 0x130(0x10)
	struct FString InitiallySelectedOption; // 0x140(0x10)
	struct FComboBoxStyleNC01 WidgetStyle; // 0x150(0xe40)
	bool EnableGamepadNavigationMode; // 0xf90(0x01)
	bool bIsFocusable; // 0xf91(0x01)
	char pad_F92[0x2]; // 0xf92(0x02)
	struct FDelegate OnGenerateButtonWidgetEvent; // 0xf94(0x10)
	struct FDelegate OnGenerateMenuWidgetEvent; // 0xfa4(0x10)
	char pad_FB4[0x4]; // 0xfb4(0x04)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0xfb8(0x10)
	struct FMulticastInlineDelegate OnOpening; // 0xfc8(0x10)
	char pad_FD8[0x58]; // 0xfd8(0x58)

	void SetSelectedIndex(int32_t Index); // Function NCUMG.ComboBoxStringNC01.SetSelectedIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x9faeb0
	void SetInitiallySelectedOption(struct FString Option); // Function NCUMG.ComboBoxStringNC01.SetInitiallySelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa830
	bool RemoveOption(struct FString Option); // Function NCUMG.ComboBoxStringNC01.RemoveOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa280
	void RefreshOptions(); // Function NCUMG.ComboBoxStringNC01.RefreshOptions // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa240
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // DelegateFunction NCUMG.ComboBoxStringNC01.OnSelectionChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	void OnOpeningEvent__DelegateSignature(); // DelegateFunction NCUMG.ComboBoxStringNC01.OnOpeningEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	bool IsOpen(); // Function NCUMG.ComboBoxStringNC01.IsOpen // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa1e0
	struct FString GetSelectedOption(); // Function NCUMG.ComboBoxStringNC01.GetSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa010
	int32_t GetSelectedIndex(); // Function NCUMG.ComboBoxStringNC01.GetSelectedIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9fb0
	int32_t GetOptionCount(); // Function NCUMG.ComboBoxStringNC01.GetOptionCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9f50
	struct FString GetOptionAtIndex(int32_t Index); // Function NCUMG.ComboBoxStringNC01.GetOptionAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9db0
	int32_t FindOptionIndex(struct FString Option); // Function NCUMG.ComboBoxStringNC01.FindOptionIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9c50
	void ClearSelection(); // Function NCUMG.ComboBoxStringNC01.ClearSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9c10
	void ClearOptions(); // Function NCUMG.ComboBoxStringNC01.ClearOptions // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9bd0
	void AddOption(struct FString Option); // Function NCUMG.ComboBoxStringNC01.AddOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9a70
};

// Class NCUMG.ComboBoxStringNC02
// Size: 0x15d0 (Inherited: 0x130)
struct UComboBoxStringNC02 : UWidget {
	struct TArray<struct FString> DefaultOptions; // 0x130(0x10)
	struct FString InitiallySelectedOption; // 0x140(0x10)
	struct FComboBoxStyleNC02 WidgetStyle; // 0x150(0x1368)
	bool EnableGamepadNavigationMode; // 0x14b8(0x01)
	bool bIsFocusable; // 0x14b9(0x01)
	char pad_14BA[0x2]; // 0x14ba(0x02)
	struct FDelegate OnGenerateButtonWidgetEvent; // 0x14bc(0x10)
	struct FDelegate OnGenerateMenuWidgetEvent; // 0x14cc(0x10)
	char pad_14DC[0x4]; // 0x14dc(0x04)
	struct FMulticastInlineDelegate OnSelectionChanged; // 0x14e0(0x10)
	struct FMulticastInlineDelegate OnOpening; // 0x14f0(0x10)
	char pad_1500[0x58]; // 0x1500(0x58)
	struct URichTextBlockNC01* ButtonRichTextBlock; // 0x1558(0x08)
	struct TMap<int32_t, struct URichTextBlockNC01*> MenuRichTextBlocks; // 0x1560(0x50)
	char pad_15B0[0x20]; // 0x15b0(0x20)

	void SetSelectedIndex(int32_t Index); // Function NCUMG.ComboBoxStringNC02.SetSelectedIndex // (Final|Native|Public|BlueprintCallable) // @ game+0x9faf30
	void SetInitiallySelectedOption(struct FString Option); // Function NCUMG.ComboBoxStringNC02.SetInitiallySelectedOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa910
	bool RemoveOption(struct FString Option); // Function NCUMG.ComboBoxStringNC02.RemoveOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa330
	void RefreshOptions(); // Function NCUMG.ComboBoxStringNC02.RefreshOptions // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa260
	void OnSelectionChangedEvent__DelegateSignature(struct FString SelectedItem, enum class ESelectInfo SelectionType); // DelegateFunction NCUMG.ComboBoxStringNC02.OnSelectionChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	void OnOpeningEvent__DelegateSignature(); // DelegateFunction NCUMG.ComboBoxStringNC02.OnOpeningEvent__DelegateSignature // (MulticastDelegate|Public|Delegate) // @ game+0x2849850
	bool IsOpen(); // Function NCUMG.ComboBoxStringNC02.IsOpen // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa210
	struct FString GetSelectedOption(); // Function NCUMG.ComboBoxStringNC02.GetSelectedOption // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa090
	int32_t GetSelectedIndex(); // Function NCUMG.ComboBoxStringNC02.GetSelectedIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9fe0
	int32_t GetOptionCount(); // Function NCUMG.ComboBoxStringNC02.GetOptionCount // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9f80
	struct FString GetOptionAtIndex(int32_t Index); // Function NCUMG.ComboBoxStringNC02.GetOptionAtIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9e80
	int32_t FindOptionIndex(struct FString Option); // Function NCUMG.ComboBoxStringNC02.FindOptionIndex // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9f9d00
	void ClearSelection(); // Function NCUMG.ComboBoxStringNC02.ClearSelection // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9c30
	void ClearOptions(); // Function NCUMG.ComboBoxStringNC02.ClearOptions // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9bf0
	void AddOption(struct FString Option); // Function NCUMG.ComboBoxStringNC02.AddOption // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9b10
};

// Class NCUMG.EditableTextBoxNC01
// Size: 0x1330 (Inherited: 0x130)
struct UEditableTextBoxNC01 : UWidget {
	struct FText Text; // 0x130(0x18)
	struct FDelegate TextDelegate; // 0x148(0x10)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x158(0x38)
	struct FHintTextStyleInfoNC01 HintTextStyleInfo; // 0x190(0x30)
	struct FEditableTextBoxStyleNC01 WidgetStyle; // 0x1c0(0x7f0)
	struct USlateWidgetStyleAsset* Style; // 0x9b0(0x08)
	struct FText HintText; // 0x9b8(0x18)
	struct FDelegate HintTextDelegate; // 0x9d0(0x10)
	struct FSlateFontInfo Font; // 0x9e0(0x50)
	struct FLinearColor ForegroundColor; // 0xa30(0x10)
	struct FLinearColor BackgroundColor; // 0xa40(0x10)
	struct FLinearColor ReadOnlyForegroundColor; // 0xa50(0x10)
	bool IsReadOnly; // 0xa60(0x01)
	bool IsPassword; // 0xa61(0x01)
	char pad_A62[0x2]; // 0xa62(0x02)
	float MinimumDesiredWidth; // 0xa64(0x04)
	struct FMargin Padding; // 0xa68(0x10)
	bool IsCaretMovedWhenGainFocus; // 0xa78(0x01)
	bool SelectAllTextWhenFocused; // 0xa79(0x01)
	bool RevertTextOnEscape; // 0xa7a(0x01)
	bool ClearKeyboardFocusOnCommit; // 0xa7b(0x01)
	bool SelectAllTextOnCommit; // 0xa7c(0x01)
	bool AllowContextMenu; // 0xa7d(0x01)
	enum class EVirtualKeyboardType KeyboardType; // 0xa7e(0x01)
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0xa7f(0x01)
	enum class EVirtualKeyboardTrigger VirtualKeyboardTrigger; // 0xa80(0x01)
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0xa81(0x01)
	enum class ETextJustifyNC01 Justification; // 0xa82(0x01)
	char pad_A83[0x1]; // 0xa83(0x01)
	struct FMargin Margin; // 0xa84(0x10)
	struct FShapedTextOptions ShapedTextOptions; // 0xa94(0x03)
	char pad_A97[0x1]; // 0xa97(0x01)
	struct FMulticastInlineDelegate OnTextChanged; // 0xa98(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0xaa8(0x10)
	char pad_AB8[0x10]; // 0xab8(0x10)
	struct FEditableTextBoxStyleNC01 CombinedWidgetStyle; // 0xac8(0x7f0)
	struct FSlateFontInfo HintFont; // 0x12b8(0x50)
	struct FSlateColor HintColorAndOpacity; // 0x1308(0x28)

	void SetText(struct FText InText); // Function NCUMG.EditableTextBoxNC01.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0x9fafb0
	void SetJustification(enum class ETextJustifyNC01 InJustification); // Function NCUMG.EditableTextBoxNC01.SetJustification // (Final|Native|Public|BlueprintCallable) // @ game+0x9fab10
	void SetIsReadOnly(bool bReadOnly); // Function NCUMG.EditableTextBoxNC01.SetIsReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x9faa80
	void SetIsPassword(bool bIsPassword); // Function NCUMG.EditableTextBoxNC01.SetIsPassword // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa9f0
	void SetHintText(struct FText InText); // Function NCUMG.EditableTextBoxNC01.SetHintText // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa650
	void SetError(struct FText InError); // Function NCUMG.EditableTextBoxNC01.SetError // (Final|Native|Public|BlueprintCallable) // @ game+0x9fa570
	void OnEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // DelegateFunction NCUMG.EditableTextBoxNC01.OnEditableTextBoxCommittedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	void OnEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // DelegateFunction NCUMG.EditableTextBoxNC01.OnEditableTextBoxChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	bool HasError(); // Function NCUMG.EditableTextBoxNC01.HasError // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa1b0
	struct FText GetText(); // Function NCUMG.EditableTextBoxNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fa110
	void ClearError(); // Function NCUMG.EditableTextBoxNC01.ClearError // (Final|Native|Public|BlueprintCallable) // @ game+0x9f9bb0
};

// Class NCUMG.EditableTextNC01
// Size: 0x758 (Inherited: 0x130)
struct UEditableTextNC01 : UWidget {
	struct FText Text; // 0x130(0x18)
	struct FDelegate TextDelegate; // 0x148(0x10)
	struct FText HintText; // 0x158(0x18)
	struct FDelegate HintTextDelegate; // 0x170(0x10)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x180(0x38)
	struct FHintTextStyleInfoNC01 HintTextStyleInfo; // 0x1b8(0x30)
	struct FEditableTextStyleNC01 WidgetStyle; // 0x1e8(0x218)
	bool IsReadOnly; // 0x400(0x01)
	bool IsPassword; // 0x401(0x01)
	char pad_402[0x2]; // 0x402(0x02)
	float MinimumDesiredWidth; // 0x404(0x04)
	bool IsCaretMovedWhenGainFocus; // 0x408(0x01)
	bool SelectAllTextWhenFocused; // 0x409(0x01)
	bool RevertTextOnEscape; // 0x40a(0x01)
	bool ClearKeyboardFocusOnCommit; // 0x40b(0x01)
	bool SelectAllTextOnCommit; // 0x40c(0x01)
	bool AllowContextMenu; // 0x40d(0x01)
	enum class EVirtualKeyboardType KeyboardType; // 0x40e(0x01)
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x40f(0x01)
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x410(0x01)
	char pad_411[0x7]; // 0x411(0x07)
	struct FOuterGlowStyleNC01 OuterGlowStyle; // 0x418(0x38)
	enum class ETextJustifyNC01 Justification; // 0x450(0x01)
	char pad_451[0x3]; // 0x451(0x03)
	struct FMargin Margin; // 0x454(0x10)
	struct FShapedTextOptions ShapedTextOptions; // 0x464(0x03)
	char pad_467[0x1]; // 0x467(0x01)
	struct FMulticastInlineDelegate OnTextChanged; // 0x468(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0x478(0x10)
	char pad_488[0x40]; // 0x488(0x40)
	struct FEditableTextStyleNC01 CombinedWidgetStyle; // 0x4c8(0x218)
	struct FSlateFontInfo HintFont; // 0x6e0(0x50)
	struct FSlateColor HintColorAndOpacity; // 0x730(0x28)

	void SynchronizeOuterGlowProperties(); // Function NCUMG.EditableTextNC01.SynchronizeOuterGlowProperties // (Final|Native|Public|BlueprintCallable) // @ game+0xa00380
	void SetText(struct FText InText); // Function NCUMG.EditableTextNC01.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffcc0
	void SetJustification(enum class ETextJustifyNC01 InJustification); // Function NCUMG.EditableTextNC01.SetJustification // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffac0
	void SetIsReadOnly(bool InbIsReadyOnly); // Function NCUMG.EditableTextNC01.SetIsReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff910
	void SetIsPassword(bool InbIsPassword); // Function NCUMG.EditableTextNC01.SetIsPassword // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff880
	void SetHintText(struct FText InHintText); // Function NCUMG.EditableTextNC01.SetHintText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff5e0
	void OnEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // DelegateFunction NCUMG.EditableTextNC01.OnEditableTextCommittedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	void OnEditableTextChangedEvent__DelegateSignature(struct FText& Text); // DelegateFunction NCUMG.EditableTextNC01.OnEditableTextChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	struct FText GetText(); // Function NCUMG.EditableTextNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fea60
};

// Class NCUMG.MergedWidgetBillboardComponentNC01
// Size: 0x530 (Inherited: 0x410)
struct UMergedWidgetBillboardComponentNC01 : UPrimitiveComponent {
	char pad_410[0x8]; // 0x410(0x08)
	struct UBodySetup* BodySetup; // 0x418(0x08)
	char pad_420[0x110]; // 0x420(0x110)
};

// Class NCUMG.MovieSceneTextStyleGlowPropertySectionNC01
// Size: 0x590 (Inherited: 0x130)
struct UMovieSceneTextStyleGlowPropertySectionNC01 : UMovieSceneSection {
	struct FMovieSceneFloatChannel OuterGlowColor[0x4]; // 0x130(0x280)
	struct FMovieSceneFloatChannel OuterGlowParameter[0x3]; // 0x3b0(0x1e0)
};

// Class NCUMG.MovieSceneTextStyleMaterialTrackNC01
// Size: 0x90 (Inherited: 0x68)
struct UMovieSceneTextStyleMaterialTrackNC01 : UMovieSceneMaterialTrack {
	struct UMaterialInstanceDynamic* CachedMaterialInstance; // 0x68(0x08)
	struct FName TextStyleKey; // 0x70(0x08)
	struct FString MaterialTypeString; // 0x78(0x10)
	struct FName TrackName; // 0x88(0x08)
};

// Class NCUMG.MovieSceneTextStylePropertyTrackNC01
// Size: 0x88 (Inherited: 0x58)
struct UMovieSceneTextStylePropertyTrackNC01 : UMovieSceneNameableTrack {
	struct FName TextStyleKey; // 0x58(0x08)
	struct FString MaterialTypeString; // 0x60(0x10)
	struct FName TrackName; // 0x70(0x08)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x78(0x10)
};

// Class NCUMG.TextLayoutWidgetNC01
// Size: 0x150 (Inherited: 0x130)
struct UTextLayoutWidgetNC01 : UWidget {
	struct FShapedTextOptions ShapedTextOptions; // 0x130(0x03)
	enum class ETextJustifyNC01 Justification; // 0x133(0x01)
	enum class ETextWrappingPolicy WrappingPolicy; // 0x134(0x01)
	char AutoWrapText : 1; // 0x135(0x01)
	char pad_135_1 : 7; // 0x135(0x01)
	char pad_136[0x2]; // 0x136(0x02)
	float WrapTextAt; // 0x138(0x04)
	struct FMargin Margin; // 0x13c(0x10)
	float LineHeightPercentage; // 0x14c(0x04)

	void SetJustification(enum class ETextJustifyNC01 InJustification); // Function NCUMG.TextLayoutWidgetNC01.SetJustification // (Native|Public|BlueprintCallable) // @ game+0xa05310
};

// Class NCUMG.MultiLineEditableTextBoxNC01
// Size: 0x1618 (Inherited: 0x150)
struct UMultiLineEditableTextBoxNC01 : UTextLayoutWidgetNC01 {
	struct FText Text; // 0x150(0x18)
	struct FText HintText; // 0x168(0x18)
	struct FDelegate HintTextDelegate; // 0x180(0x10)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x190(0x38)
	struct FHintTextStyleInfoNC01 HintTextStyleInfo; // 0x1c8(0x30)
	struct FEditableTextBoxStyle WidgetStyle; // 0x1f8(0x7f0)
	struct FTextBlockStyleNC01 TextStyle; // 0x9e8(0x308)
	bool bIsReadOnly; // 0xcf0(0x01)
	bool AllowContextMenu; // 0xcf1(0x01)
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0xcf2(0x01)
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0xcf3(0x01)
	char pad_CF4[0x4]; // 0xcf4(0x04)
	struct USlateWidgetStyleAsset* Style; // 0xcf8(0x08)
	struct FSlateFontInfo Font; // 0xd00(0x50)
	struct FLinearColor ForegroundColor; // 0xd50(0x10)
	struct FLinearColor BackgroundColor; // 0xd60(0x10)
	struct FLinearColor ReadOnlyForegroundColor; // 0xd70(0x10)
	struct FMulticastInlineDelegate OnTextChanged; // 0xd80(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0xd90(0x10)
	char pad_DA0[0x10]; // 0xda0(0x10)
	struct FEditableTextBoxStyle CombinedWidgetStyle; // 0xdb0(0x7f0)
	struct FSlateFontInfo HintFont; // 0x15a0(0x50)
	struct FSlateColor HintColorAndOpacity; // 0x15f0(0x28)

	void SetTextStyle(struct FTextBlockStyleNC01& InTextStyle); // Function NCUMG.MultiLineEditableTextBoxNC01.SetTextStyle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa00030
	void SetText(struct FText InText); // Function NCUMG.MultiLineEditableTextBoxNC01.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffda0
	void SetIsReadOnly(bool bReadOnly); // Function NCUMG.MultiLineEditableTextBoxNC01.SetIsReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff9a0
	void SetHintText(struct FText InHintText); // Function NCUMG.MultiLineEditableTextBoxNC01.SetHintText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff6c0
	void SetError(struct FText InError); // Function NCUMG.MultiLineEditableTextBoxNC01.SetError // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff480
	void OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // DelegateFunction NCUMG.MultiLineEditableTextBoxNC01.OnMultiLineEditableTextBoxCommittedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	void OnMultiLineEditableTextBoxChangedEvent__DelegateSignature(struct FText& Text); // DelegateFunction NCUMG.MultiLineEditableTextBoxNC01.OnMultiLineEditableTextBoxChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	struct FText GetText(); // Function NCUMG.MultiLineEditableTextBoxNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9feb00
	struct FText GetHintText(); // Function NCUMG.MultiLineEditableTextBoxNC01.GetHintText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fe820
};

// Class NCUMG.MultiLineEditableTextNC01
// Size: 0x978 (Inherited: 0x150)
struct UMultiLineEditableTextNC01 : UTextLayoutWidgetNC01 {
	struct FText Text; // 0x150(0x18)
	struct FText HintText; // 0x168(0x18)
	struct FDelegate HintTextDelegate; // 0x180(0x10)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x190(0x38)
	struct FHintTextStyleInfoNC01 HintTextStyleInfo; // 0x1c8(0x30)
	struct FTextBlockStyleNC01 WidgetStyle; // 0x1f8(0x308)
	bool bIsReadOnly; // 0x500(0x01)
	char pad_501[0x7]; // 0x501(0x07)
	struct FSlateFontInfo Font; // 0x508(0x50)
	bool SelectAllTextWhenFocused; // 0x558(0x01)
	bool ClearTextSelectionOnFocusLoss; // 0x559(0x01)
	bool RevertTextOnEscape; // 0x55a(0x01)
	bool ClearKeyboardFocusOnCommit; // 0x55b(0x01)
	bool AllowContextMenu; // 0x55c(0x01)
	struct FVirtualKeyboardOptions VirtualKeyboardOptions; // 0x55d(0x01)
	enum class EVirtualKeyboardDismissAction VirtualKeyboardDismissAction; // 0x55e(0x01)
	char pad_55F[0x1]; // 0x55f(0x01)
	struct FOuterGlowStyleNC01 OuterGlowStyle; // 0x560(0x38)
	struct FMulticastInlineDelegate OnTextChanged; // 0x598(0x10)
	struct FMulticastInlineDelegate OnTextCommitted; // 0x5a8(0x10)
	char pad_5B8[0x40]; // 0x5b8(0x40)
	struct FTextBlockStyleNC01 CombinedWidgetStyle; // 0x5f8(0x308)
	struct FSlateFontInfo HintFont; // 0x900(0x50)
	struct FSlateColor HintColorAndOpacity; // 0x950(0x28)

	void SynchronizeOuterGlowProperties(); // Function NCUMG.MultiLineEditableTextNC01.SynchronizeOuterGlowProperties // (Final|Native|Public|BlueprintCallable) // @ game+0xa003a0
	void SetWidgetStyle(struct FTextBlockStyleNC01& InWidgetStyle); // Function NCUMG.MultiLineEditableTextNC01.SetWidgetStyle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa002d0
	void SetText(struct FText InText); // Function NCUMG.MultiLineEditableTextNC01.SetText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffe80
	void SetIsReadOnly(bool bReadOnly); // Function NCUMG.MultiLineEditableTextNC01.SetIsReadOnly // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffa30
	void SetHintText(struct FText InHintText); // Function NCUMG.MultiLineEditableTextNC01.SetHintText // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff7a0
	void OnMultiLineEditableTextCommittedEvent__DelegateSignature(struct FText& Text, enum class ETextCommit CommitMethod); // DelegateFunction NCUMG.MultiLineEditableTextNC01.OnMultiLineEditableTextCommittedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	void OnMultiLineEditableTextChangedEvent__DelegateSignature(struct FText& Text); // DelegateFunction NCUMG.MultiLineEditableTextNC01.OnMultiLineEditableTextChangedEvent__DelegateSignature // (MulticastDelegate|Public|Delegate|HasOutParms) // @ game+0x2849850
	struct FText GetText(); // Function NCUMG.MultiLineEditableTextNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9feba0
	struct FText GetHintText(); // Function NCUMG.MultiLineEditableTextNC01.GetHintText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fe8c0
};

// Class NCUMG.NCUMGFunctionLibrary
// Size: 0x28 (Inherited: 0x28)
struct UNCUMGFunctionLibrary : UBlueprintFunctionLibrary {

	void SetUIParticleViewportZOrder(struct UObject* InWorldContextObject, int32_t InZOrder); // Function NCUMG.NCUMGFunctionLibrary.SetUIParticleViewportZOrder // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa00220
	void SetUIParticleViewportVisible(struct UObject* InWorldContextObject, bool InIsVisible); // Function NCUMG.NCUMGFunctionLibrary.SetUIParticleViewportVisible // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa00160
};

// Class NCUMG.NCUserWidget
// Size: 0x258 (Inherited: 0x258)
struct UNCUserWidget : UUserWidget {
};

// Class NCUMG.PaperFlipBookImageNC01
// Size: 0x1a0 (Inherited: 0x130)
struct UPaperFlipBookImageNC01 : UWidget {
	struct FSlateFlipBookBrushNC01 Brush; // 0x130(0x18)
	struct FLinearColor ColorAndOpacity; // 0x148(0x10)
	struct FDelegate ColorAndOpacityDelegate; // 0x158(0x10)
	enum class EPaperFlipBookStatus FlipBookStatus; // 0x168(0x01)
	char pad_169[0x3]; // 0x169(0x03)
	struct FDelegate FlipBookStatusDelegate; // 0x16c(0x10)
	bool bFlipForRightToLeftFlowDirection; // 0x17c(0x01)
	char pad_17D[0x3]; // 0x17d(0x03)
	struct FDelegate OnMouseButtonDownEvent; // 0x180(0x10)
	char pad_190[0x10]; // 0x190(0x10)

	void SetFlipBookStatus(enum class EPaperFlipBookStatus InStatus); // Function NCUMG.PaperFlipBookImageNC01.SetFlipBookStatus // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff560
	void SetColorAndOpacity(struct FLinearColor InColorAndOpacity); // Function NCUMG.PaperFlipBookImageNC01.SetColorAndOpacity // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9fee30
	enum class EPaperFlipBookStatus GetPaperFlipBookStatus__DelegateSignature(); // DelegateFunction NCUMG.PaperFlipBookImageNC01.GetPaperFlipBookStatus__DelegateSignature // (Public|Delegate) // @ game+0x2849850
};

// Class NCUMG.RichTextBlockDecoratorNC01
// Size: 0x28 (Inherited: 0x28)
struct URichTextBlockDecoratorNC01 : UObject {
};

// Class NCUMG.RichTextBlockImageDecoratorNC01
// Size: 0x30 (Inherited: 0x28)
struct URichTextBlockImageDecoratorNC01 : URichTextBlockDecoratorNC01 {
	struct UDataTable* ImageSet; // 0x28(0x08)
};

// Class NCUMG.RichTextBlockNC01
// Size: 0x9b0 (Inherited: 0x150)
struct URichTextBlockNC01 : UTextLayoutWidgetNC01 {
	float DisplayTimePerCharacter; // 0x150(0x04)
	char pad_154[0x4]; // 0x154(0x04)
	struct FText Text; // 0x158(0x18)
	struct UDataTable* TextStyleSet; // 0x170(0x08)
	struct TArray<struct URichTextBlockDecoratorNC01*> DecoratorClasses; // 0x178(0x10)
	bool bOverrideDefaultStyle; // 0x188(0x01)
	char pad_189[0x7]; // 0x189(0x07)
	struct FTextBlockStyleNC01 DefaultTextStyleOverride; // 0x190(0x308)
	bool bOverrideDefaultStyleTag; // 0x498(0x01)
	char pad_499[0x3]; // 0x499(0x03)
	struct FName OverrideDefaultStyleTagName; // 0x49c(0x08)
	float MinDesiredWidth; // 0x4a4(0x04)
	struct FStrikethroughStyleNC01 StrikethroughStyle; // 0x4a8(0xf0)
	bool bOverrideMargin; // 0x598(0x01)
	bool bOverrideLineHeightPercentage; // 0x599(0x01)
	char pad_59A[0x6]; // 0x59a(0x06)
	struct FEllipsisStyleNC01 EllipsisStyle; // 0x5a0(0x20)
	char pad_5C0[0x320]; // 0x5c0(0x320)
	struct TArray<struct URichTextBlockDecoratorNC01*> InstanceDecorators; // 0x8e0(0x10)
	char pad_8F0[0xc0]; // 0x8f0(0xc0)

	void SetTextStyleSet(struct UDataTable* NewTextStyleSet); // Function NCUMG.RichTextBlockNC01.SetTextStyleSet // (Final|Native|Public|BlueprintCallable) // @ game+0xa000e0
	void SetText(struct FText& InText); // Function NCUMG.RichTextBlockNC01.SetText // (Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9fff60
	void SetShadowOffset(struct FVector2D InShadowOffset); // Function NCUMG.RichTextBlockNC01.SetShadowOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9ffc40
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Function NCUMG.RichTextBlockNC01.SetShadowColorAndOpacity // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9ffbc0
	void SetMinDesiredWidth(float InMinDesiredWidth); // Function NCUMG.RichTextBlockNC01.SetMinDesiredWidth // (Final|Native|Public|BlueprintCallable) // @ game+0x9ffb40
	void SetDisplayTimePerCharacter(float InDisplayTimePerCharacterInSeconds); // Function NCUMG.RichTextBlockNC01.SetDisplayTimePerCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0x9ff400
	void SetDefaultTextStyle(struct FTextBlockStyleNC01& InDefaultTextStyle); // Function NCUMG.RichTextBlockNC01.SetDefaultTextStyle // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9ff350
	void SetDefaultStrikeBrush(struct FSlateBrush& InStrikeBrush); // Function NCUMG.RichTextBlockNC01.SetDefaultStrikeBrush // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x9ff1d0
	void SetDefaultShadowOffset(struct FVector2D InShadowOffset); // Function NCUMG.RichTextBlockNC01.SetDefaultShadowOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9ff150
	void SetDefaultShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Function NCUMG.RichTextBlockNC01.SetDefaultShadowColorAndOpacity // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x9ff0d0
	void SetDefaultFont(struct FSlateFontInfo InFontInfo); // Function NCUMG.RichTextBlockNC01.SetDefaultFont // (Final|Native|Public|BlueprintCallable) // @ game+0x9fefa0
	void SetDefaultColorAndOpacity(struct FSlateColor InColorAndOpacity); // Function NCUMG.RichTextBlockNC01.SetDefaultColorAndOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0x9feeb0
	void SetAutoWrapText(bool InAutoTextWrap); // Function NCUMG.RichTextBlockNC01.SetAutoWrapText // (Final|Native|Public|BlueprintCallable) // @ game+0x9feda0
	void SetAdditionalKerning(float InAdditionalKerning); // Function NCUMG.RichTextBlockNC01.SetAdditionalKerning // (Final|Native|Public|BlueprintCallable) // @ game+0x9fed20
	void ResumeDisplayTimePerCharacter(); // Function NCUMG.RichTextBlockNC01.ResumeDisplayTimePerCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0x9fed00
	void PauseDisplayTimePerCharacter(); // Function NCUMG.RichTextBlockNC01.PauseDisplayTimePerCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0x9fece0
	struct FText GetText(); // Function NCUMG.RichTextBlockNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x9fec40
	struct UMaterialInterface* GetStyleSetMaterial(struct FName& InStyleSetName, struct FString InMaterialTypeString); // Function NCUMG.RichTextBlockNC01.GetStyleSetMaterial // (Final|Native|Public|HasOutParms) // @ game+0x9fe960
	struct URichTextBlockDecoratorNC01* GetDecoratorByClass(struct URichTextBlockDecoratorNC01* DecoratorClass); // Function NCUMG.RichTextBlockNC01.GetDecoratorByClass // (Final|Native|Public|BlueprintCallable) // @ game+0x9fe790
	void ClearAllDefaultStyleOverrides(); // Function NCUMG.RichTextBlockNC01.ClearAllDefaultStyleOverrides // (Final|Native|Public) // @ game+0x9fe770
};

// Class NCUMG.ScaleBoxNC01
// Size: 0x168 (Inherited: 0x148)
struct UScaleBoxNC01 : UContentWidget {
	enum class EStretchNC01 Stretch; // 0x148(0x01)
	enum class EStretchDirection StretchDirection; // 0x149(0x01)
	char pad_14A[0x2]; // 0x14a(0x02)
	float UserSpecifiedScale; // 0x14c(0x04)
	bool IgnoreInheritedScale; // 0x150(0x01)
	char pad_151[0x17]; // 0x151(0x17)

	void SetUserSpecifiedScale(float InUserSpecifiedScale); // Function NCUMG.ScaleBoxNC01.SetUserSpecifiedScale // (Final|Native|Public|BlueprintCallable) // @ game+0xa04490
	void SetStretchDirection(enum class EStretchDirection InStretchDirection); // Function NCUMG.ScaleBoxNC01.SetStretchDirection // (Final|Native|Public|BlueprintCallable) // @ game+0xa04100
	void SetStretch(enum class EStretchNC01 InStretch); // Function NCUMG.ScaleBoxNC01.SetStretch // (Final|Native|Public|BlueprintCallable) // @ game+0xa04080
	void SetIgnoreInheritedScale(bool bInIgnoreInheritedScale); // Function NCUMG.ScaleBoxNC01.SetIgnoreInheritedScale // (Final|Native|Public|BlueprintCallable) // @ game+0xa03890
};

// Class NCUMG.ScaleBoxSlotNC01
// Size: 0x60 (Inherited: 0x38)
struct UScaleBoxSlotNC01 : UPanelSlot {
	struct FMargin Padding; // 0x38(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x48(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x49(0x01)
	char pad_4A[0x16]; // 0x4a(0x16)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function NCUMG.ScaleBoxSlotNC01.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0xa04510
	void SetPadding(struct FMargin InPadding); // Function NCUMG.ScaleBoxSlotNC01.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0xa03ba0
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function NCUMG.ScaleBoxSlotNC01.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0xa03790
};

// Class NCUMG.ScreenWidgetComponentNC01
// Size: 0x480 (Inherited: 0x410)
struct UScreenWidgetComponentNC01 : UPrimitiveComponent {
	struct UUserWidget* WidgetClass; // 0x408(0x08)
	struct FIntPoint DrawSize; // 0x410(0x08)
	bool bDrawAtDesiredSize; // 0x418(0x01)
	struct FVector2D Pivot; // 0x41c(0x08)
	bool bApplyGammaCorrection; // 0x424(0x01)
	struct ULocalPlayer* OwnerPlayer; // 0x428(0x08)
	struct UUserWidget* Widget; // 0x430(0x08)
	char pad_43A[0x1e]; // 0x43a(0x1e)
	bool bAddedToScreen; // 0x458(0x01)
	bool bEditTimeUsable; // 0x459(0x01)
	char pad_45A[0x6]; // 0x45a(0x06)
	struct UCurveFloat* DistanceToSizeCurve; // 0x460(0x08)
	bool bOverrideFaceCameraOffset; // 0x468(0x01)
	char pad_469[0x3]; // 0x469(0x03)
	float FaceCameraOffset; // 0x46c(0x04)
	struct FName SharedLayerName; // 0x470(0x08)
	int32_t LayerZOrder; // 0x478(0x04)
	char pad_47C[0x4]; // 0x47c(0x04)

	void SetWidget(struct UUserWidget* Widget); // Function NCUMG.ScreenWidgetComponentNC01.SetWidget // (Native|Public|BlueprintCallable) // @ game+0xa04690
	void SetPivot(struct FVector2D& InPivot); // Function NCUMG.ScreenWidgetComponentNC01.SetPivot // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa03cc0
	void SetOwnerPlayer(struct ULocalPlayer* LocalPlayer); // Function NCUMG.ScreenWidgetComponentNC01.SetOwnerPlayer // (Final|Native|Public|BlueprintCallable) // @ game+0xa03b20
	void SetFaceCameraOffset(float Offset); // Function NCUMG.ScreenWidgetComponentNC01.SetFaceCameraOffset // (Final|Native|Public|BlueprintCallable) // @ game+0xa035e0
	void SetDrawSize(struct FVector2D Size); // Function NCUMG.ScreenWidgetComponentNC01.SetDrawSize // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa03560
	void SetDrawAtDesiredSize(bool bInDrawAtDesiredSize); // Function NCUMG.ScreenWidgetComponentNC01.SetDrawAtDesiredSize // (Final|Native|Public|BlueprintCallable) // @ game+0xa034e0
	void SetDistanceToSizeCurve(struct UCurveFloat* InDistanceToSizeCurve); // Function NCUMG.ScreenWidgetComponentNC01.SetDistanceToSizeCurve // (Final|Native|Public|BlueprintCallable) // @ game+0xa03460
	struct UUserWidget* GetUserWidgetObject(); // Function NCUMG.ScreenWidgetComponentNC01.GetUserWidgetObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02e50
	struct FVector2D GetPivot(); // Function NCUMG.ScreenWidgetComponentNC01.GetPivot // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02c20
	struct ULocalPlayer* GetOwnerPlayer(); // Function NCUMG.ScreenWidgetComponentNC01.GetOwnerPlayer // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02bf0
	struct FVector2D GetDrawSize(); // Function NCUMG.ScreenWidgetComponentNC01.GetDrawSize // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02b50
	bool GetDrawAtDesiredSize(); // Function NCUMG.ScreenWidgetComponentNC01.GetDrawAtDesiredSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02b30
};

// Class NCUMG.ScrollBoxNC01
// Size: 0x948 (Inherited: 0x148)
struct UScrollBoxNC01 : UPanelWidget {
	struct FScrollBoxStyle WidgetStyle; // 0x148(0x228)
	struct FScrollBarStyle WidgetBarStyle; // 0x370(0x4d0)
	struct FScrollBoxAdditionalStyleNC01 WidgetAdditionalStyle; // 0x840(0xa8)
	enum class EOrientation Orientation; // 0x8e8(0x01)
	enum class EScrollBarLayoutTypeNC01 ScrollBarLayoutType; // 0x8e9(0x01)
	enum class ESlateVisibility ScrollBarVisibility; // 0x8ea(0x01)
	bool ScrollBarVisibleOnlyWhenScroll; // 0x8eb(0x01)
	enum class EConsumeMouseWheel ConsumeMouseWheel; // 0x8ec(0x01)
	char pad_8ED[0x3]; // 0x8ed(0x03)
	struct FVector2D ScrollbarThickness; // 0x8f0(0x08)
	struct FMargin ScrollbarPadding; // 0x8f8(0x10)
	bool AlwaysShowScrollbarTrack; // 0x908(0x01)
	bool AllowOverscroll; // 0x909(0x01)
	bool bAnimateWheelScrolling; // 0x90a(0x01)
	enum class EDescendantScrollDestination NavigationDestination; // 0x90b(0x01)
	float NavigationScrollPadding; // 0x90c(0x04)
	struct UMaterialInterface* BorderMaterialInstance; // 0x910(0x08)
	bool bAllowRightClickDragScrolling; // 0x918(0x01)
	char pad_919[0x3]; // 0x919(0x03)
	float WheelScrollMultiplier; // 0x91c(0x04)
	struct FMulticastInlineDelegate OnUserScrolled; // 0x920(0x10)
	char pad_930[0x18]; // 0x930(0x18)

	void SetWheelScrollMultiplier(float NewWheelScrollMultiplier); // Function NCUMG.ScrollBoxNC01.SetWheelScrollMultiplier // (Final|Native|Public|BlueprintCallable) // @ game+0xa04610
	void SetScrollOffset(float NewScrollOffset); // Function NCUMG.ScrollBoxNC01.SetScrollOffset // (Final|Native|Public|BlueprintCallable) // @ game+0xa03dd0
	void SetScrollBarVisibility(enum class ESlateVisibility NewScrollBarVisibility); // Function NCUMG.ScrollBoxNC01.SetScrollBarVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0xa03d50
	void SetScrollbarThickness(struct FVector2D& NewScrollbarThickness); // Function NCUMG.ScrollBoxNC01.SetScrollbarThickness // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa03ef0
	void SetScrollbarPadding(struct FMargin& NewScrollbarPadding); // Function NCUMG.ScrollBoxNC01.SetScrollbarPadding // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa03e50
	void SetOrientation(enum class EOrientation NewOrientation); // Function NCUMG.ScrollBoxNC01.SetOrientation // (Final|Native|Public|BlueprintCallable) // @ game+0xa03a20
	void SetConsumeMouseWheel(enum class EConsumeMouseWheel NewConsumeMouseWheel); // Function NCUMG.ScrollBoxNC01.SetConsumeMouseWheel // (Final|Native|Public|BlueprintCallable) // @ game+0xa033e0
	void SetAnimateWheelScrolling(bool bShouldAnimateWheelScrolling); // Function NCUMG.ScrollBoxNC01.SetAnimateWheelScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0xa03140
	void SetAllowOverscroll(bool NewAllowOverscroll); // Function NCUMG.ScrollBoxNC01.SetAllowOverscroll // (Final|Native|Public|BlueprintCallable) // @ game+0xa030b0
	void ScrollWidgetIntoView(struct UWidget* WidgetToFind, bool AnimateScroll, enum class EDescendantScrollDestination ScrollDestination); // Function NCUMG.ScrollBoxNC01.ScrollWidgetIntoView // (Final|Native|Public|BlueprintCallable) // @ game+0xa02f30
	void ScrollToStart(); // Function NCUMG.ScrollBoxNC01.ScrollToStart // (Final|Native|Public|BlueprintCallable) // @ game+0xa02f10
	void ScrollToEnd(); // Function NCUMG.ScrollBoxNC01.ScrollToEnd // (Final|Native|Public|BlueprintCallable) // @ game+0xa02ef0
	float GetViewOffsetFraction(); // Function NCUMG.ScrollBoxNC01.GetViewOffsetFraction // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02e80
	float GetScrollOffsetOfEnd(); // Function NCUMG.ScrollBoxNC01.GetScrollOffsetOfEnd // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02c80
	float GetScrollOffset(); // Function NCUMG.ScrollBoxNC01.GetScrollOffset // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02c50
	void EndInertialScrolling(); // Function NCUMG.ScrollBoxNC01.EndInertialScrolling // (Final|Native|Public|BlueprintCallable) // @ game+0xa02b10
};

// Class NCUMG.ScrollBoxSlotNC01
// Size: 0x78 (Inherited: 0x38)
struct UScrollBoxSlotNC01 : UPanelSlot {
	struct FMargin Padding; // 0x38(0x10)
	enum class EHorizontalAlignment HorizontalAlignment; // 0x48(0x01)
	enum class EVerticalAlignment VerticalAlignment; // 0x49(0x01)
	char pad_4A[0x1e]; // 0x4a(0x1e)
	struct FMargin BorderPadding; // 0x68(0x10)

	void SetVerticalAlignment(enum class EVerticalAlignment InVerticalAlignment); // Function NCUMG.ScrollBoxSlotNC01.SetVerticalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0xa04590
	void SetPadding(struct FMargin InPadding); // Function NCUMG.ScrollBoxSlotNC01.SetPadding // (Final|Native|Public|BlueprintCallable) // @ game+0xa03c30
	void SetHorizontalAlignment(enum class EHorizontalAlignment InHorizontalAlignment); // Function NCUMG.ScrollBoxSlotNC01.SetHorizontalAlignment // (Final|Native|Public|BlueprintCallable) // @ game+0xa03810
	void SetBorderPadding(struct FMargin InBorderPadding); // Function NCUMG.ScrollBoxSlotNC01.SetBorderPadding // (Final|Native|Public|BlueprintCallable) // @ game+0xa03260
};

// Class NCUMG.TextBlockNC01
// Size: 0x490 (Inherited: 0x150)
struct UTextBlockNC01 : UTextLayoutWidgetNC01 {
	struct FText Text; // 0x150(0x18)
	float DisplayTimePerCharacter; // 0x168(0x04)
	struct FDelegate TextDelegate; // 0x16c(0x10)
	char pad_17C[0x4]; // 0x17c(0x04)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x180(0x38)
	struct FSlateColor ColorAndOpacity; // 0x1b8(0x28)
	struct FDelegate ColorAndOpacityDelegate; // 0x1e0(0x10)
	struct FSlateFontInfo Font; // 0x1f0(0x50)
	float AdditionalKerning; // 0x240(0x04)
	struct FVector2D ShadowOffset; // 0x244(0x08)
	struct FLinearColor ShadowColorAndOpacity; // 0x24c(0x10)
	struct FDelegate ShadowColorAndOpacityDelegate; // 0x25c(0x10)
	float MinDesiredWidth; // 0x26c(0x04)
	bool bWrapWithInvalidationPanel; // 0x270(0x01)
	bool bAutoWrapText; // 0x271(0x01)
	char pad_272[0x6]; // 0x272(0x06)
	struct FEllipsisStyleNC01 EllipsisStyle; // 0x278(0x20)
	struct FStrikethroughStyleNC01 StrikethroughStyle; // 0x298(0xf0)
	struct FOuterGlowStyleNC01 OuterGlowStyle; // 0x388(0x38)
	char pad_3C0[0x88]; // 0x3c0(0x88)
	bool bSimpleTextMode; // 0x448(0x01)
	char pad_449[0x47]; // 0x449(0x47)

	void SynchronizeOuterGlowProperties(); // Function NCUMG.TextBlockNC01.SynchronizeOuterGlowProperties // (Final|Native|Public|BlueprintCallable) // @ game+0xa04720
	void SetText(struct FText InText); // Function NCUMG.TextBlockNC01.SetText // (Native|Public|BlueprintCallable) // @ game+0xa043b0
	void SetStrikeBrush(struct FSlateBrush InStrikeBrush); // Function NCUMG.TextBlockNC01.SetStrikeBrush // (Final|Native|Public|BlueprintCallable) // @ game+0xa04180
	void SetShadowOffset(struct FVector2D InShadowOffset); // Function NCUMG.TextBlockNC01.SetShadowOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa04000
	void SetShadowColorAndOpacity(struct FLinearColor InShadowColorAndOpacity); // Function NCUMG.TextBlockNC01.SetShadowColorAndOpacity // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa03f80
	void SetOuterGlowStrength(float InOuterGlowStrength); // Function NCUMG.TextBlockNC01.SetOuterGlowStrength // (Final|Native|Public|BlueprintCallable) // @ game+0xa03aa0
	void SetOpacity(float InOpacity); // Function NCUMG.TextBlockNC01.SetOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0xa039a0
	void SetMinDesiredWidth(float InMinDesiredWidth); // Function NCUMG.TextBlockNC01.SetMinDesiredWidth // (Final|Native|Public|BlueprintCallable) // @ game+0xa03920
	void SetFont(struct FSlateFontInfo InFontInfo); // Function NCUMG.TextBlockNC01.SetFont // (Final|Native|Public|BlueprintCallable) // @ game+0xa03660
	void SetDisplayTimePerCharacter(float InDisplayTimePerCharacterInSeconds); // Function NCUMG.TextBlockNC01.SetDisplayTimePerCharacter // (Native|Public|BlueprintCallable) // @ game+0x9fa4f0
	void SetColorAndOpacity(struct FSlateColor InColorAndOpacity); // Function NCUMG.TextBlockNC01.SetColorAndOpacity // (Final|Native|Public|BlueprintCallable) // @ game+0xa032f0
	void SetAutoWrapText(bool InAutoTextWrap); // Function NCUMG.TextBlockNC01.SetAutoWrapText // (Final|Native|Public|BlueprintCallable) // @ game+0xa031d0
	void SetAdditionalKerning(float InAdditionalKerning); // Function NCUMG.TextBlockNC01.SetAdditionalKerning // (Final|Native|Public|BlueprintCallable) // @ game+0xa03030
	void ResumeDisplayTimePerCharacter(); // Function NCUMG.TextBlockNC01.ResumeDisplayTimePerCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0xa02ed0
	void PauseDisplayTimePerCharacter(); // Function NCUMG.TextBlockNC01.PauseDisplayTimePerCharacter // (Final|Native|Public|BlueprintCallable) // @ game+0xa02eb0
	struct FText GetText(); // Function NCUMG.TextBlockNC01.GetText // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa02db0
	struct UMaterialInterface* GetStyleSetMaterial(struct FName& InStyleSetName, struct FString InMaterialTypeString); // Function NCUMG.TextBlockNC01.GetStyleSetMaterial // (Final|Native|Public|HasOutParms) // @ game+0xa02cb0
	struct UMaterialInstanceDynamic* GetDynamicOutlineMaterial(); // Function NCUMG.TextBlockNC01.GetDynamicOutlineMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0xa02bc0
	struct UMaterialInstanceDynamic* GetDynamicFontMaterial(); // Function NCUMG.TextBlockNC01.GetDynamicFontMaterial // (Final|Native|Public|BlueprintCallable) // @ game+0xa02b90
};

// Class NCUMG.UIFXEmitterNC01
// Size: 0x158 (Inherited: 0x130)
struct UUIFXEmitterNC01 : UWidget {
	bool bDrawSeparately; // 0x130(0x01)
	bool bUseClipping; // 0x131(0x01)
	enum class EUIParticleStateNC01 ParticleState; // 0x132(0x01)
	char pad_133[0x1]; // 0x133(0x01)
	struct FVector ViewAngle; // 0x134(0x0c)
	float ViewDistance; // 0x140(0x04)
	char pad_144[0x14]; // 0x144(0x14)

	void SetViewDistance(float InViewDistance); // Function NCUMG.UIFXEmitterNC01.SetViewDistance // (Final|Native|Public|BlueprintCallable) // @ game+0xa05650
	void SetViewAngle(struct FVector InViewAngle); // Function NCUMG.UIFXEmitterNC01.SetViewAngle // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa055c0
	void SetParticleState(enum class EUIParticleStateNC01 InParticleState); // Function NCUMG.UIFXEmitterNC01.SetParticleState // (Final|Native|Public|BlueprintCallable) // @ game+0xa05390
};

// Class NCUMG.UIParticleEmitterNC01
// Size: 0x180 (Inherited: 0x158)
struct UUIParticleEmitterNC01 : UUIFXEmitterNC01 {
	struct UParticleSystem* ParticleSystem; // 0x158(0x08)
	int32_t LODLevel; // 0x160(0x04)
	bool bUseThumbnailAngle; // 0x164(0x01)
	bool bUseThumbnailDistance; // 0x165(0x01)
	char pad_166[0x2]; // 0x166(0x02)
	struct FVector ThumbnailAngle; // 0x168(0x0c)
	float ThumbnailDistance; // 0x174(0x04)
	struct UParticleSystemComponent* ParticleSystemComponent; // 0x178(0x08)
};

// Class NCUMG.WidgetBillboardComponentNC01
// Size: 0x460 (Inherited: 0x410)
struct UWidgetBillboardComponentNC01 : UPrimitiveComponent {
	struct TWeakObjectPtr<struct UUserWidget> Widget; // 0x408(0x08)
	struct FIntPoint DrawSize; // 0x410(0x08)
	struct FIntPoint CurrentDrawSize; // 0x418(0x08)
	bool bWidgetShouldTick; // 0x420(0x01)
	enum class EWidgetBlendMode BlendMode; // 0x421(0x01)
	bool bReceiveHardwareInput; // 0x422(0x01)
	bool TickWhenOffscreen; // 0x423(0x01)
	char pad_42C[0x4]; // 0x42c(0x04)
	struct UUserWidget* WidgetClass; // 0x430(0x08)
	struct FVector2D Pivot; // 0x438(0x08)
	char pad_440[0xc]; // 0x440(0x0c)
	bool bDrawAtDesiredSize; // 0x44c(0x01)
	char pad_44D[0x3]; // 0x44d(0x03)
	struct UCurveFloat* DistanceToSizeCurve; // 0x450(0x08)
	struct UBodySetup* BodySetup; // 0x458(0x08)

	void SetWidgetShouldTick(bool InWidgetShouldTick); // Function NCUMG.WidgetBillboardComponentNC01.SetWidgetShouldTick // (Final|Native|Public|BlueprintCallable) // @ game+0xa05750
	void SetWidget(struct UUserWidget* InWidget); // Function NCUMG.WidgetBillboardComponentNC01.SetWidget // (Final|Native|Public|BlueprintCallable) // @ game+0xa056d0
	void SetTickWhenOffscreen(bool InTickWhenOffscreen); // Function NCUMG.WidgetBillboardComponentNC01.SetTickWhenOffscreen // (Final|Native|Public|BlueprintCallable) // @ game+0xa05530
	void SetReceiveHardwareInput(bool InReceiveHardwareInput); // Function NCUMG.WidgetBillboardComponentNC01.SetReceiveHardwareInput // (Final|Native|Public|BlueprintCallable) // @ game+0xa054a0
	void SetPivot(struct FVector2D& NewPivot); // Function NCUMG.WidgetBillboardComponentNC01.SetPivot // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa05410
	void SetDrawSize(struct FIntPoint& NewDrawSize); // Function NCUMG.WidgetBillboardComponentNC01.SetDrawSize // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa05280
	void SetDistanceToSizeCurve(struct UCurveFloat* InDistanceToSizeCurve); // Function NCUMG.WidgetBillboardComponentNC01.SetDistanceToSizeCurve // (Final|Native|Public|BlueprintCallable) // @ game+0xa05200
	void SetBlendMode(enum class EWidgetBlendMode InBlendMode); // Function NCUMG.WidgetBillboardComponentNC01.SetBlendMode // (Final|Native|Public|BlueprintCallable) // @ game+0xa05180
	struct UUserWidget* GetUserWidgetObject(); // Function NCUMG.WidgetBillboardComponentNC01.GetUserWidgetObject // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa05150
};

// Class NCUMG.WidgetBillboardMaterialHolder
// Size: 0x40 (Inherited: 0x28)
struct UWidgetBillboardMaterialHolder : UObject {
	struct UMaterialInterface* DefaultMaskedMaterial; // 0x28(0x08)
	struct UMaterialInterface* DefaultOpaqueMaterial; // 0x30(0x08)
	struct UMaterialInterface* DefaultTranslucentMaterial; // 0x38(0x08)
};

