// WidgetBlueprintGeneratedClass BP_Button_OK.BP_Button_OK_C
// Size: 0x390 (Inherited: 0x378)
struct UBP_Button_OK_C : ULMRTemplateTextButton {
	struct ULMRImage* Img_Check; // 0x378(0x08)
	struct ULMRImage* Img_Focuse; // 0x380(0x08)
	struct ULMRImage* img_Progress; // 0x388(0x08)
};

