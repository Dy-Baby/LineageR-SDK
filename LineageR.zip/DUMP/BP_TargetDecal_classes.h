// BlueprintGeneratedClass BP_TargetDecal.BP_TargetDecal_C
// Size: 0x250 (Inherited: 0x250)
struct ABP_TargetDecal_C : ALMRDecalActor {
};

