// WidgetBlueprintGeneratedClass UI_NPCIcon.UI_NPCIcon_C
// Size: 0x320 (Inherited: 0x318)
struct UUI_NPCIcon_C : ULMRDialogueActionWidget {
	struct UWidgetAnimation* Ani_NPCGlow; // 0x318(0x08)
};

