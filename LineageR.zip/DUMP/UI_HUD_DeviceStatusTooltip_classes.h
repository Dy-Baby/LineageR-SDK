// WidgetBlueprintGeneratedClass UI_HUD_DeviceStatusTooltip.UI_HUD_DeviceStatusTooltip_C
// Size: 0x2e0 (Inherited: 0x2e0)
struct UUI_HUD_DeviceStatusTooltip_C : ULMRDeviceStatusTooltipWidget {
};

