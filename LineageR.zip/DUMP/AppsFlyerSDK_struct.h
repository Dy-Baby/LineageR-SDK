// ScriptStruct AppsFlyerSDK.AppsFlyerConversionData
// Size: 0x50 (Inherited: 0x00)
struct FAppsFlyerConversionData {
	struct TMap<struct FString, struct FString> InstallData; // 0x00(0x50)
};

