// WidgetBlueprintGeneratedClass UI_HUD_QSlot.UI_HUD_QSlot_C
// Size: 0x4e0 (Inherited: 0x4b0)
struct UUI_HUD_QSlot_C : ULMRQuickSlotHudWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x4b0(0x08)
	struct ULMRImage* Img_QSlot_Min_arrow_down; // 0x4b8(0x08)
	struct ULMRImage* Img_QSlot_Min_arrow_up; // 0x4c0(0x08)
	struct ULMRImage* Img_QSlot_Min_L; // 0x4c8(0x08)
	struct ULMRImage* Img_QSlot_Min_s; // 0x4d0(0x08)
	struct UUI_HUD_QSlot_Small_C* UI_HUD_QSlot_Small; // 0x4d8(0x08)

	void SequenceEvent__ENTRYPOINTUI_HUD_QSlot_1(); // Function UI_HUD_QSlot.UI_HUD_QSlot_C.SequenceEvent__ENTRYPOINTUI_HUD_QSlot_1 // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x2849850
	void SequenceEvent_SwitchSlot(); // Function UI_HUD_QSlot.UI_HUD_QSlot_C.SequenceEvent_SwitchSlot // (BlueprintCallable|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_UI_HUD_QSlot(int32_t EntryPoint); // Function UI_HUD_QSlot.UI_HUD_QSlot_C.ExecuteUbergraph_UI_HUD_QSlot // (Final|UbergraphFunction) // @ game+0x2849850
};

