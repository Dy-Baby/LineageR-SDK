// Enum IOSAppTrackingTransparency.EIOSAppTrackingAuthStatus
enum class EIOSAppTrackingAuthStatus : uint8 {
	Restricted = 0,
	NotDetermined = 1,
	Denied = 2,
	Authorized = 3,
	EIOSAppTrackingAuthStatus_MAX = 4
};

