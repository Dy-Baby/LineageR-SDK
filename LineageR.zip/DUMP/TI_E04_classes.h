// BlueprintGeneratedClass TI_E04.TI_E04_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_E04_C : ALevelScriptActor {
};

