// BlueprintGeneratedClass TI_Coll.TI_Coll_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_Coll_C : ALevelScriptActor {
};

