// WidgetBlueprintGeneratedClass BP_TextInput_typeA.BP_TextInput_typeA_C
// Size: 0x340 (Inherited: 0x340)
struct UBP_TextInput_typeA_C : ULMRTemplateEditTextBase {
};

