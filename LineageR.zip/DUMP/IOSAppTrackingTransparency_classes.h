// Class IOSAppTrackingTransparency.IOSAppTrackingTransparencyLib
// Size: 0x28 (Inherited: 0x28)
struct UIOSAppTrackingTransparencyLib : UBlueprintFunctionLibrary {

	enum class EIOSAppTrackingAuthStatus RequestIOSAppTracking(); // Function IOSAppTrackingTransparency.IOSAppTrackingTransparencyLib.RequestIOSAppTracking // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xcc28f0
	enum class EIOSAppTrackingAuthStatus GetIOSAppTrackingAuthStatus(); // Function IOSAppTrackingTransparency.IOSAppTrackingTransparencyLib.GetIOSAppTrackingAuthStatus // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xcc28f0
};

// Class IOSAppTrackingTransparency.IOSAppTrackingTransparencySettings
// Size: 0x38 (Inherited: 0x28)
struct UIOSAppTrackingTransparencySettings : UObject {
	struct FString TrackingRequestDescription; // 0x28(0x10)
};

