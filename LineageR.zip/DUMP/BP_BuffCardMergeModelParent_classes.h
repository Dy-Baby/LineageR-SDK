// BlueprintGeneratedClass BP_BuffCardMergeModelParent.BP_BuffCardMergeModelParent_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_BuffCardMergeModelParent_C : ALMRObject {
};

