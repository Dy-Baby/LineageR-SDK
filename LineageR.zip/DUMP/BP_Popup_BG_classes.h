// WidgetBlueprintGeneratedClass BP_Popup_BG.BP_Popup_BG_C
// Size: 0x278 (Inherited: 0x258)
struct UBP_Popup_BG_C : UUserWidget {
	struct ULMRImage* UI_Bg_PopupCompA; // 0x258(0x08)
	struct ULMRImage* UI_Bg_PopupCompB; // 0x260(0x08)
	struct ULMRImage* UI_Bg_PopupCompC; // 0x268(0x08)
	struct ULMRImage* UI_Bg_PopupCompD; // 0x270(0x08)
};

