// BlueprintGeneratedClass BP_RichImageDecorator.BP_RichImageDecorator_C
// Size: 0x30 (Inherited: 0x30)
struct UBP_RichImageDecorator_C : URichTextBlockImageDecoratorNC01 {
};

