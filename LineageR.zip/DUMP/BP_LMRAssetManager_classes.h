// BlueprintGeneratedClass BP_LMRAssetManager.BP_LMRAssetManager_C
// Size: 0x4d8 (Inherited: 0x4d8)
struct UBP_LMRAssetManager_C : ULMRAssetManager {
};

