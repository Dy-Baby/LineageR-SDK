// WidgetBlueprintGeneratedClass UI_ClanEmblem_Icon.UI_ClanEmblem_Icon_C
// Size: 0x2d0 (Inherited: 0x2d0)
struct UUI_ClanEmblem_Icon_C : ULMRClanEmblemIconWidget {
};

