// WidgetBlueprintGeneratedClass BP_NcShowCampaignWidget.BP_NcShowCampaignWidget_C
// Size: 0x5a0 (Inherited: 0x5a0)
struct UBP_NcShowCampaignWidget_C : UNcShowCampaignWidget {

	enum class ESlateVisibility Get_ExpectTitle_Visibility_1(); // Function BP_NcShowCampaignWidget.BP_NcShowCampaignWidget_C.Get_ExpectTitle_Visibility_1 // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x2849850
};

