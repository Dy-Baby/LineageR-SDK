// WidgetBlueprintGeneratedClass UI_HUD_autoSlot.UI_HUD_autoSlot_C
// Size: 0x360 (Inherited: 0x350)
struct UUI_HUD_autoSlot_C : ULMRQuickPotionOptionWidget {
	struct ULMRImage* img_Bg; // 0x350(0x08)
	struct ULMRImage* img_Line; // 0x358(0x08)
};

