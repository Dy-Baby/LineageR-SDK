// WidgetBlueprintGeneratedClass BP_NcShowAgreementSlotWidget.BP_NcShowAgreementSlotWidget_C
// Size: 0x4e8 (Inherited: 0x4e8)
struct UBP_NcShowAgreementSlotWidget_C : UNcShowAgreementSlotWidget {
};

