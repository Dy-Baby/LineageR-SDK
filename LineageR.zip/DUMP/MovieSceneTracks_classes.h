// Class MovieSceneTracks.MovieSceneMaterialTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneMaterialTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieScenePropertyTrack
// Size: 0x88 (Inherited: 0x58)
struct UMovieScenePropertyTrack : UMovieSceneNameableTrack {
	struct UMovieSceneSection* SectionToKey; // 0x58(0x08)
	struct FName PropertyName; // 0x60(0x08)
	struct FString PropertyPath; // 0x68(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x78(0x10)
};

// Class MovieSceneTracks.MovieSceneFloatSection
// Size: 0x1d0 (Inherited: 0x130)
struct UMovieSceneFloatSection : UMovieSceneSection {
	struct FMovieSceneFloatChannel FloatCurve; // 0x130(0xa0)
};

// Class MovieSceneTracks.MovieSceneTransformOrigin
// Size: 0x28 (Inherited: 0x28)
struct UMovieSceneTransformOrigin : UInterface {

	struct FTransform BP_GetTransformOrigin(); // Function MovieSceneTracks.MovieSceneTransformOrigin.BP_GetTransformOrigin // (Event|Protected|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x2849850
};

// Class MovieSceneTracks.MovieScene3DConstraintSection
// Size: 0x158 (Inherited: 0x130)
struct UMovieScene3DConstraintSection : UMovieSceneSection {
	struct FGuid ConstraintId; // 0x130(0x10)
	struct FMovieSceneObjectBindingID ConstraintBindingID; // 0x140(0x18)

	void SetConstraintBindingID(struct FMovieSceneObjectBindingID& InConstraintBindingID); // Function MovieSceneTracks.MovieScene3DConstraintSection.SetConstraintBindingID // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x364bab0
	struct FMovieSceneObjectBindingID GetConstraintBindingID(); // Function MovieSceneTracks.MovieScene3DConstraintSection.GetConstraintBindingID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x364b9f0
};

// Class MovieSceneTracks.MovieScene3DAttachSection
// Size: 0x170 (Inherited: 0x158)
struct UMovieScene3DAttachSection : UMovieScene3DConstraintSection {
	struct FName AttachSocketName; // 0x158(0x08)
	struct FName AttachComponentName; // 0x160(0x08)
	enum class EAttachmentRule AttachmentLocationRule; // 0x168(0x01)
	enum class EAttachmentRule AttachmentRotationRule; // 0x169(0x01)
	enum class EAttachmentRule AttachmentScaleRule; // 0x16a(0x01)
	enum class EDetachmentRule DetachmentLocationRule; // 0x16b(0x01)
	enum class EDetachmentRule DetachmentRotationRule; // 0x16c(0x01)
	enum class EDetachmentRule DetachmentScaleRule; // 0x16d(0x01)
	char pad_16E[0x2]; // 0x16e(0x02)
};

// Class MovieSceneTracks.MovieScene3DConstraintTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieScene3DConstraintTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> ConstraintSections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieScene3DAttachTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieScene3DAttachTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScene3DPathSection
// Size: 0x200 (Inherited: 0x158)
struct UMovieScene3DPathSection : UMovieScene3DConstraintSection {
	struct FMovieSceneFloatChannel TimingCurve; // 0x158(0xa0)
	enum class MovieScene3DPathSection_Axis FrontAxisEnum; // 0x1f8(0x01)
	enum class MovieScene3DPathSection_Axis UpAxisEnum; // 0x1f9(0x01)
	char pad_1FA[0x2]; // 0x1fa(0x02)
	char bFollow : 1; // 0x1fc(0x01)
	char bReverse : 1; // 0x1fc(0x01)
	char bForceUpright : 1; // 0x1fc(0x01)
	char pad_1FC_3 : 5; // 0x1fc(0x01)
	char pad_1FD[0x3]; // 0x1fd(0x03)
};

// Class MovieSceneTracks.MovieScene3DPathTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieScene3DPathTrack : UMovieScene3DConstraintTrack {
};

// Class MovieSceneTracks.MovieScene3DTransformSection
// Size: 0x780 (Inherited: 0x130)
struct UMovieScene3DTransformSection : UMovieSceneSection {
	struct FMovieSceneTransformMask TransformMask; // 0x130(0x04)
	char pad_134[0x4]; // 0x134(0x04)
	struct FMovieSceneFloatChannel Translation[0x3]; // 0x138(0x1e0)
	struct FMovieSceneFloatChannel Rotation[0x3]; // 0x318(0x1e0)
	struct FMovieSceneFloatChannel Scale[0x3]; // 0x4f8(0x1e0)
	struct FMovieSceneFloatChannel ManualWeight; // 0x6d8(0xa0)
	char pad_778[0x4]; // 0x778(0x04)
	bool bUseQuaternionInterpolation; // 0x77c(0x01)
	char pad_77D[0x3]; // 0x77d(0x03)
};

// Class MovieSceneTracks.MovieScene3DTransformTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieScene3DTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneActorReferenceSection
// Size: 0x270 (Inherited: 0x130)
struct UMovieSceneActorReferenceSection : UMovieSceneSection {
	struct FMovieSceneActorReferenceData ActorReferenceData; // 0x130(0xb0)
	struct FIntegralCurve ActorGuidIndexCurve; // 0x1e0(0x80)
	struct TArray<struct FString> ActorGuidStrings; // 0x260(0x10)
};

// Class MovieSceneTracks.MovieSceneActorReferenceTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneActorReferenceTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneAudioSection
// Size: 0x380 (Inherited: 0x130)
struct UMovieSceneAudioSection : UMovieSceneSection {
	struct USoundBase* Sound; // 0x130(0x08)
	struct FFrameNumber StartFrameOffset; // 0x138(0x04)
	float StartOffset; // 0x13c(0x04)
	float AudioStartTime; // 0x140(0x04)
	float AudioDilationFactor; // 0x144(0x04)
	float AudioVolume; // 0x148(0x04)
	char pad_14C[0x4]; // 0x14c(0x04)
	struct FMovieSceneFloatChannel SoundVolume; // 0x150(0xa0)
	struct FMovieSceneFloatChannel PitchMultiplier; // 0x1f0(0xa0)
	struct FMovieSceneActorReferenceData AttachActorData; // 0x290(0xb0)
	bool bSuppressSubtitles; // 0x340(0x01)
	bool bOverrideAttenuation; // 0x341(0x01)
	char pad_342[0x6]; // 0x342(0x06)
	struct USoundAttenuation* AttenuationSettings; // 0x348(0x08)
	struct FDelegate OnQueueSubtitles; // 0x350(0x10)
	struct FMulticastInlineDelegate OnAudioFinished; // 0x360(0x10)
	struct FMulticastInlineDelegate OnAudioPlaybackPercent; // 0x370(0x10)

	void SetStartOffset(struct FFrameNumber InStartOffset); // Function MovieSceneTracks.MovieSceneAudioSection.SetStartOffset // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0x364bbf0
	void SetSound(struct USoundBase* InSound); // Function MovieSceneTracks.MovieSceneAudioSection.SetSound // (Final|Native|Public|BlueprintCallable) // @ game+0x364bb70
	struct FFrameNumber GetStartOffset(); // Function MovieSceneTracks.MovieSceneAudioSection.GetStartOffset // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0x364ba90
	struct USoundBase* GetSound(); // Function MovieSceneTracks.MovieSceneAudioSection.GetSound // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x364ba70
};

// Class MovieSceneTracks.MovieSceneAudioTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneAudioTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AudioSections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieSceneBoolSection
// Size: 0x1c8 (Inherited: 0x130)
struct UMovieSceneBoolSection : UMovieSceneSection {
	bool DefaultValue; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
	struct FMovieSceneBoolChannel BoolCurve; // 0x138(0x90)
};

// Class MovieSceneTracks.MovieSceneBoolTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneBoolTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneByteSection
// Size: 0x1c8 (Inherited: 0x130)
struct UMovieSceneByteSection : UMovieSceneSection {
	struct FMovieSceneByteChannel ByteCurve; // 0x130(0x98)
};

// Class MovieSceneTracks.MovieSceneByteTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieSceneByteTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0x88(0x08)
};

// Class MovieSceneTracks.MovieSceneCameraAnimSection
// Size: 0x170 (Inherited: 0x130)
struct UMovieSceneCameraAnimSection : UMovieSceneSection {
	struct FMovieSceneCameraAnimSectionData AnimData; // 0x130(0x20)
	struct UCameraAnim* CameraAnim; // 0x150(0x08)
	float PlayRate; // 0x158(0x04)
	float PlayScale; // 0x15c(0x04)
	float BlendInTime; // 0x160(0x04)
	float BlendOutTime; // 0x164(0x04)
	bool bLooping; // 0x168(0x01)
	char pad_169[0x7]; // 0x169(0x07)
};

// Class MovieSceneTracks.MovieSceneCameraAnimTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneCameraAnimTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraAnimSections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraCutSection
// Size: 0x180 (Inherited: 0x130)
struct UMovieSceneCameraCutSection : UMovieSceneSection {
	struct FGuid CameraGuid; // 0x130(0x10)
	struct FMovieSceneObjectBindingID CameraBindingID; // 0x140(0x18)
	struct FViewTargetTransitionParams BlendParams; // 0x158(0x10)
	struct FLMRMovieSceneCameraCutParams CustomCameraCutParams; // 0x168(0x18)

	void SetCameraBindingID(struct FMovieSceneObjectBindingID& InCameraBindingID); // Function MovieSceneTracks.MovieSceneCameraCutSection.SetCameraBindingID // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x364bab0
	struct FLMRMovieSceneCameraCutParams GetCustomCameraCutParams(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetCustomCameraCutParams // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x364ba30
	struct FMovieSceneObjectBindingID GetCameraBindingID(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetCameraBindingID // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x364b9f0
	struct FViewTargetTransitionParams GetBlendParams(); // Function MovieSceneTracks.MovieSceneCameraCutSection.GetBlendParams // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x364b9c0
};

// Class MovieSceneTracks.MovieSceneCameraCutTrack
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneCameraCutTrack : UMovieSceneNameableTrack {
	bool bCanBlend; // 0x58(0x01)
	char pad_59[0x7]; // 0x59(0x07)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x60(0x10)
};

// Class MovieSceneTracks.MovieSceneCameraShakeSection
// Size: 0x170 (Inherited: 0x130)
struct UMovieSceneCameraShakeSection : UMovieSceneSection {
	struct FMovieSceneCameraShakeSectionData ShakeData; // 0x130(0x20)
	struct UCameraShake* ShakeClass; // 0x150(0x08)
	float PlayScale; // 0x158(0x04)
	enum class ECameraAnimPlaySpace PlaySpace; // 0x15c(0x01)
	char pad_15D[0x3]; // 0x15d(0x03)
	struct FRotator UserDefinedPlaySpace; // 0x160(0x0c)
	char pad_16C[0x4]; // 0x16c(0x04)
};

// Class MovieSceneTracks.MovieSceneCameraShakeTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneCameraShakeTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> CameraShakeSections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieSceneCinematicShotSection
// Size: 0x1d0 (Inherited: 0x1a8)
struct UMovieSceneCinematicShotSection : UMovieSceneSubSection {
	struct FString ShotDisplayName; // 0x1a8(0x10)
	struct FText DisplayName; // 0x1b8(0x18)

	void SetShotDisplayName(struct FString InShotDisplayName); // Function MovieSceneTracks.MovieSceneCinematicShotSection.SetShotDisplayName // (Final|Native|Public|BlueprintCallable) // @ game+0x3652080
	struct FString GetShotDisplayName(); // Function MovieSceneTracks.MovieSceneCinematicShotSection.GetShotDisplayName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3651ee0
};

// Class MovieSceneTracks.MovieSceneCinematicShotTrack
// Size: 0x68 (Inherited: 0x68)
struct UMovieSceneCinematicShotTrack : UMovieSceneSubTrack {
};

// Class MovieSceneTracks.MovieSceneColorSection
// Size: 0x3b0 (Inherited: 0x130)
struct UMovieSceneColorSection : UMovieSceneSection {
	struct FMovieSceneFloatChannel RedCurve; // 0x130(0xa0)
	struct FMovieSceneFloatChannel GreenCurve; // 0x1d0(0xa0)
	struct FMovieSceneFloatChannel BlueCurve; // 0x270(0xa0)
	struct FMovieSceneFloatChannel AlphaCurve; // 0x310(0xa0)
};

// Class MovieSceneTracks.MovieSceneColorTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieSceneColorTrack : UMovieScenePropertyTrack {
	bool bIsSlateColor; // 0x88(0x01)
	char pad_89[0x7]; // 0x89(0x07)
};

// Class MovieSceneTracks.MovieSceneEnumSection
// Size: 0x1c8 (Inherited: 0x130)
struct UMovieSceneEnumSection : UMovieSceneSection {
	struct FMovieSceneByteChannel EnumCurve; // 0x130(0x98)
};

// Class MovieSceneTracks.MovieSceneEnumTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieSceneEnumTrack : UMovieScenePropertyTrack {
	struct UEnum* Enum; // 0x88(0x08)
};

// Class MovieSceneTracks.MovieSceneEulerTransformTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneEulerTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneEventSectionBase
// Size: 0x130 (Inherited: 0x130)
struct UMovieSceneEventSectionBase : UMovieSceneSection {
};

// Class MovieSceneTracks.MovieSceneEventRepeaterSection
// Size: 0x158 (Inherited: 0x130)
struct UMovieSceneEventRepeaterSection : UMovieSceneEventSectionBase {
	struct FMovieSceneEvent Event; // 0x130(0x28)
};

// Class MovieSceneTracks.MovieSceneEventSection
// Size: 0x230 (Inherited: 0x130)
struct UMovieSceneEventSection : UMovieSceneSection {
	struct FNameCurve events; // 0x130(0x78)
	struct FMovieSceneEventSectionData EventData; // 0x1a8(0x88)
};

// Class MovieSceneTracks.MovieSceneEventTrack
// Size: 0x80 (Inherited: 0x58)
struct UMovieSceneEventTrack : UMovieSceneNameableTrack {
	char bFireEventsWhenForwards : 1; // 0x58(0x01)
	char bFireEventsWhenBackwards : 1; // 0x58(0x01)
	char pad_58_2 : 6; // 0x58(0x01)
	char pad_59[0x3]; // 0x59(0x03)
	enum class EFireEventsAtPosition EventPosition; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	struct TArray<struct FMovieSceneObjectBindingID> EventReceivers; // 0x60(0x10)
	struct TArray<struct UMovieSceneSection*> Sections; // 0x70(0x10)
};

// Class MovieSceneTracks.MovieSceneEventTriggerSection
// Size: 0x1b8 (Inherited: 0x130)
struct UMovieSceneEventTriggerSection : UMovieSceneEventSectionBase {
	struct FMovieSceneEventChannel EventChannel; // 0x130(0x88)
};

// Class MovieSceneTracks.MovieSceneFadeSection
// Size: 0x1e8 (Inherited: 0x1d0)
struct UMovieSceneFadeSection : UMovieSceneFloatSection {
	struct FLinearColor FadeColor; // 0x1d0(0x10)
	char bFadeAudio : 1; // 0x1e0(0x01)
	char pad_1E0_1 : 7; // 0x1e0(0x01)
	char pad_1E1[0x7]; // 0x1e1(0x07)
};

// Class MovieSceneTracks.MovieSceneFloatTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneFloatTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneFadeTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneFadeTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneIntegerSection
// Size: 0x1c0 (Inherited: 0x130)
struct UMovieSceneIntegerSection : UMovieSceneSection {
	struct FMovieSceneIntegerChannel IntegerCurve; // 0x130(0x90)
};

// Class MovieSceneTracks.MovieSceneIntegerTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneIntegerTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneLevelVisibilitySection
// Size: 0x148 (Inherited: 0x130)
struct UMovieSceneLevelVisibilitySection : UMovieSceneSection {
	enum class ELevelVisibility Visibility; // 0x130(0x01)
	char pad_131[0x7]; // 0x131(0x07)
	struct TArray<struct FName> LevelNames; // 0x138(0x10)

	void SetVisibility(enum class ELevelVisibility InVisibility); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetVisibility // (Final|Native|Public|BlueprintCallable) // @ game+0x3652170
	void SetLevelNames(struct TArray<struct FName>& InLevelNames); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.SetLevelNames // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x3651fd0
	enum class ELevelVisibility GetVisibility(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetVisibility // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3651fa0
	struct TArray<struct FName> GetLevelNames(); // Function MovieSceneTracks.MovieSceneLevelVisibilitySection.GetLevelNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x3651eb0
};

// Class MovieSceneTracks.MovieSceneLevelVisibilityTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneLevelVisibilityTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieSceneMaterialParameterCollectionTrack
// Size: 0x70 (Inherited: 0x68)
struct UMovieSceneMaterialParameterCollectionTrack : UMovieSceneMaterialTrack {
	struct UMaterialParameterCollection* MPC; // 0x68(0x08)
};

// Class MovieSceneTracks.MovieSceneComponentMaterialTrack
// Size: 0x70 (Inherited: 0x68)
struct UMovieSceneComponentMaterialTrack : UMovieSceneMaterialTrack {
	int32_t MaterialIndex; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
};

// Class MovieSceneTracks.MovieSceneObjectPropertySection
// Size: 0x1f0 (Inherited: 0x130)
struct UMovieSceneObjectPropertySection : UMovieSceneSection {
	struct FMovieSceneObjectPathChannel ObjectChannel; // 0x130(0xc0)
};

// Class MovieSceneTracks.MovieSceneObjectPropertyTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieSceneObjectPropertyTrack : UMovieScenePropertyTrack {
	struct UObject* PropertyClass; // 0x88(0x08)
};

// Class MovieSceneTracks.MovieSceneParameterSection
// Size: 0x190 (Inherited: 0x130)
struct UMovieSceneParameterSection : UMovieSceneSection {
	struct TArray<struct FBoolParameterNameAndCurve> BoolParameterNamesAndCurves; // 0x130(0x10)
	struct TArray<struct FScalarParameterNameAndCurve> ScalarParameterNamesAndCurves; // 0x140(0x10)
	struct TArray<struct FVector2DParameterNameAndCurves> Vector2DParameterNamesAndCurves; // 0x150(0x10)
	struct TArray<struct FVectorParameterNameAndCurves> VectorParameterNamesAndCurves; // 0x160(0x10)
	struct TArray<struct FColorParameterNameAndCurves> ColorParameterNamesAndCurves; // 0x170(0x10)
	struct TArray<struct FTransformParameterNameAndCurves> TransformParameterNamesAndCurves; // 0x180(0x10)
};

// Class MovieSceneTracks.MovieSceneParticleParameterTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneParticleParameterTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieSceneParticleSection
// Size: 0x1c8 (Inherited: 0x130)
struct UMovieSceneParticleSection : UMovieSceneSection {
	struct FMovieSceneParticleChannel ParticleKeys; // 0x130(0x98)
};

// Class MovieSceneTracks.MovieSceneParticleTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneParticleTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> ParticleSections; // 0x58(0x10)
};

// Class MovieSceneTracks.MovieScenePrimitiveMaterialSection
// Size: 0x1f0 (Inherited: 0x130)
struct UMovieScenePrimitiveMaterialSection : UMovieSceneSection {
	struct FMovieSceneObjectPathChannel MaterialChannel; // 0x130(0xc0)
};

// Class MovieSceneTracks.MovieScenePrimitiveMaterialTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieScenePrimitiveMaterialTrack : UMovieScenePropertyTrack {
	int32_t MaterialIndex; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationSection
// Size: 0x230 (Inherited: 0x130)
struct UMovieSceneSkeletalAnimationSection : UMovieSceneSection {
	struct FMovieSceneSkeletalAnimationParams Params; // 0x130(0xd8)
	struct UAnimSequence* AnimSequence; // 0x208(0x08)
	struct UAnimSequenceBase* Animation; // 0x210(0x08)
	float StartOffset; // 0x218(0x04)
	float EndOffset; // 0x21c(0x04)
	float PlayRate; // 0x220(0x04)
	char bReverse : 1; // 0x224(0x01)
	char pad_224_1 : 7; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
	struct FName SlotName; // 0x228(0x08)
};

// Class MovieSceneTracks.MovieSceneSkeletalAnimationTrack
// Size: 0x70 (Inherited: 0x58)
struct UMovieSceneSkeletalAnimationTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> AnimationSections; // 0x58(0x10)
	bool bUseLegacySectionIndexBlend; // 0x68(0x01)
	char pad_69[0x7]; // 0x69(0x07)
};

// Class MovieSceneTracks.MovieSceneSlomoSection
// Size: 0x1d0 (Inherited: 0x1d0)
struct UMovieSceneSlomoSection : UMovieSceneFloatSection {
};

// Class MovieSceneTracks.MovieSceneSlomoTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneSlomoTrack : UMovieSceneFloatTrack {
};

// Class MovieSceneTracks.MovieSceneSpawnSection
// Size: 0x1c8 (Inherited: 0x1c8)
struct UMovieSceneSpawnSection : UMovieSceneBoolSection {
};

// Class MovieSceneTracks.MovieSceneSpawnTrack
// Size: 0x78 (Inherited: 0x58)
struct UMovieSceneSpawnTrack : UMovieSceneTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
	struct FGuid ObjectGuid; // 0x68(0x10)
};

// Class MovieSceneTracks.MovieSceneStringSection
// Size: 0x1d0 (Inherited: 0x130)
struct UMovieSceneStringSection : UMovieSceneSection {
	struct FMovieSceneStringChannel StringCurve; // 0x130(0xa0)
};

// Class MovieSceneTracks.MovieSceneStringTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneStringTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneTransformTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneTransformTrack : UMovieScenePropertyTrack {
};

// Class MovieSceneTracks.MovieSceneVectorSection
// Size: 0x3b8 (Inherited: 0x130)
struct UMovieSceneVectorSection : UMovieSceneSection {
	struct FMovieSceneFloatChannel Curves[0x4]; // 0x130(0x280)
	int32_t ChannelsUsed; // 0x3b0(0x04)
	char pad_3B4[0x4]; // 0x3b4(0x04)
};

// Class MovieSceneTracks.MovieSceneVectorTrack
// Size: 0x90 (Inherited: 0x88)
struct UMovieSceneVectorTrack : UMovieScenePropertyTrack {
	int32_t NumChannelsUsed; // 0x88(0x04)
	char pad_8C[0x4]; // 0x8c(0x04)
};

// Class MovieSceneTracks.MovieSceneVisibilityTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneVisibilityTrack : UMovieSceneBoolTrack {
};

// Class MovieSceneTracks.TranslucencySortPriorityTrack
// Size: 0x88 (Inherited: 0x88)
struct UTranslucencySortPriorityTrack : UMovieSceneIntegerTrack {
};

