// ScriptStruct MagicLeapAudio.MagicLeapAudioDummyStruct
// Size: 0x01 (Inherited: 0x00)
struct FMagicLeapAudioDummyStruct {
	char pad_0[0x1]; // 0x00(0x01)
};

