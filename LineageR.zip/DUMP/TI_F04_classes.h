// BlueprintGeneratedClass TI_F04.TI_F04_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_F04_C : ALevelScriptActor {
};

