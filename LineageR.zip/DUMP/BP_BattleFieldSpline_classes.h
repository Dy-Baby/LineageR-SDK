// BlueprintGeneratedClass BP_BattleFieldSpline.BP_BattleFieldSpline_C
// Size: 0x310 (Inherited: 0x2c0)
struct ABP_BattleFieldSpline_C : ALMRBattleFieldGridSplineActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct USplineComponent* Spline; // 0x2c8(0x08)
	enum class ESplineMeshAxis ForwardAxis; // 0x2d0(0x01)
	char pad_2D1[0x7]; // 0x2d1(0x07)
	struct UStaticMesh* StaticMesh; // 0x2d8(0x08)
	struct FStaticMaterial mat; // 0x2e0(0x30)

	void MakeSplinePath(); // Function BP_BattleFieldSpline.BP_BattleFieldSpline_C.MakeSplinePath // (Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_BattleFieldSpline(int32_t EntryPoint); // Function BP_BattleFieldSpline.BP_BattleFieldSpline_C.ExecuteUbergraph_BP_BattleFieldSpline // (Final|UbergraphFunction|HasDefaults) // @ game+0x2849850
};

