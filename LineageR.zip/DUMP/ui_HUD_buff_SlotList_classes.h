// WidgetBlueprintGeneratedClass ui_HUD_buff_SlotList.ui_HUD_buff_SlotList_C
// Size: 0x470 (Inherited: 0x440)
struct Uui_HUD_buff_SlotList_C : ULMRBuffWidget {
	struct UWidgetAnimation* Ani_Fold; // 0x440(0x08)
	struct UWidgetAnimation* Ani_Expand; // 0x448(0x08)
	struct ULMRButton* BtnBuff_Expand; // 0x450(0x08)
	struct ULMRImage* Img_Activate; // 0x458(0x08)
	struct ULMRImage* img_Glow; // 0x460(0x08)
	struct ULMRImage* Img_Round; // 0x468(0x08)
};

