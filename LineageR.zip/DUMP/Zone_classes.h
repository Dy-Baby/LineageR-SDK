// BlueprintGeneratedClass Zone.Zone_C
// Size: 0x228 (Inherited: 0x228)
struct AZone_C : ALevelScriptActor {
};

