// BlueprintGeneratedClass BP_BuffCardParent.BP_BuffCardParent_C
// Size: 0x6b0 (Inherited: 0x6b0)
struct ABP_BuffCardParent_C : ALMRBuffCardActor {
};

