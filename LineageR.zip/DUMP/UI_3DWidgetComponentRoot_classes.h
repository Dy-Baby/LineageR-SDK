// WidgetBlueprintGeneratedClass UI_3DWidgetComponentRoot.UI_3DWidgetComponentRoot_C
// Size: 0x2c0 (Inherited: 0x2c0)
struct UUI_3DWidgetComponentRoot_C : ULMR3DWidgetComponentRoot {
};

