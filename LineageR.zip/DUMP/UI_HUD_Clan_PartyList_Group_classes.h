// WidgetBlueprintGeneratedClass UI_HUD_Clan_PartyList_Group.UI_HUD_Clan_PartyList_Group_C
// Size: 0x2a0 (Inherited: 0x258)
struct UUI_HUD_Clan_PartyList_Group_C : UUserWidget {
	struct UBP_Button_OK_C* BP_Button_Joining; // 0x258(0x08)
	struct ULMRButton* button_Slot; // 0x260(0x08)
	struct ULMRImage* img_Line; // 0x268(0x08)
	struct ULMRImage* LMRImage_BG; // 0x270(0x08)
	struct ULMRTextBlock* Num_Group; // 0x278(0x08)
	struct UUI_HUD_Clan_PartyList_C* UI_HUD_Clan_PartyList_1_2; // 0x280(0x08)
	struct UUI_HUD_Clan_PartyList_C* UI_HUD_Clan_PartyList_1_3; // 0x288(0x08)
	struct UUI_HUD_Clan_PartyList_C* UI_HUD_Clan_PartyList_1_4; // 0x290(0x08)
	struct UUI_HUD_Clan_PartyList_C* UI_HUD_Clan_PartyList_1_5; // 0x298(0x08)
};

