// BlueprintGeneratedClass BP_CommandGuide_Burst.BP_CommandGuide_Burst_C
// Size: 0x230 (Inherited: 0x220)
struct ABP_CommandGuide_Burst_C : AActor {
	struct UParticleSystemComponent* ParticleSystem; // 0x220(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x228(0x08)
};

