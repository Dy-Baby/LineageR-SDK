// BlueprintGeneratedClass TalkingIsland.TalkingIsland_C
// Size: 0x234 (Inherited: 0x228)
struct ATalkingIsland_C : ALevelScriptActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x228(0x08)
	int32_t Num; // 0x230(0x04)

	void ExecuteUbergraph_TalkingIsland(int32_t EntryPoint); // Function TalkingIsland.TalkingIsland_C.ExecuteUbergraph_TalkingIsland // (Final|UbergraphFunction) // @ game+0x2849850
};

