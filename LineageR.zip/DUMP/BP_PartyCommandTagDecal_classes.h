// BlueprintGeneratedClass BP_PartyCommandTagDecal.BP_PartyCommandTagDecal_C
// Size: 0x2a8 (Inherited: 0x2a0)
struct ABP_PartyCommandTagDecal_C : ALMRPartyCommandDecalActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a0(0x08)

	void SetCommandSound(enum class ELMRPartyCommandTagType ePartyCommandType); // Function BP_PartyCommandTagDecal.BP_PartyCommandTagDecal_C.SetCommandSound // (Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_PartyCommandTagDecal(int32_t EntryPoint); // Function BP_PartyCommandTagDecal.BP_PartyCommandTagDecal_C.ExecuteUbergraph_BP_PartyCommandTagDecal // (Final|UbergraphFunction) // @ game+0x2849850
};

