// WidgetBlueprintGeneratedClass BP_NcPrivacyWidget.BP_NcPrivacyWidget_C
// Size: 0x428 (Inherited: 0x428)
struct UBP_NcPrivacyWidget_C : UNcPrivacyWidget {
};

