// Class LWCutscene.LMRMovieSceneAnimationTypeSection
// Size: 0x1d8 (Inherited: 0x130)
struct ULMRMovieSceneAnimationTypeSection : UMovieSceneSection {
	struct FLMRMovieSceneAnimationParams params_; // 0x130(0xa8)
};

// Class LWCutscene.LMRMovieSceneAnimationTypeTrack
// Size: 0x68 (Inherited: 0x58)
struct ULMRMovieSceneAnimationTypeTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> Sections; // 0x58(0x10)
};

