// WidgetBlueprintGeneratedClass BP_NcSimpleLoginWidget.BP_NcSimpleLoginWidget_C
// Size: 0x450 (Inherited: 0x448)
struct UBP_NcSimpleLoginWidget_C : UNcSimpleLoginWidget {
	struct UBP_NcSimpleLoginSlotWidget_C* BP_NcSimpleLoginSlotWidget; // 0x448(0x08)
};

