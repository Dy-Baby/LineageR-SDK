// WidgetBlueprintGeneratedClass UI_MinimapPortal.UI_MinimapPortal_C
// Size: 0x2f0 (Inherited: 0x2f0)
struct UUI_MinimapPortal_C : ULMRMinimapPortalWidget {
};

