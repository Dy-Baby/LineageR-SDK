// BlueprintGeneratedClass BP_BattleFieldTargetCommandDecal.BP_BattleFieldTargetCommandDecal_C
// Size: 0x250 (Inherited: 0x250)
struct ABP_BattleFieldTargetCommandDecal_C : ALMRDecalActor {
};

