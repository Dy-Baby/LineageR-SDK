// WidgetBlueprintGeneratedClass UI_InvisibleGestureWidget.UI_InvisibleGestureWidget_C
// Size: 0x4e8 (Inherited: 0x4e8)
struct UUI_InvisibleGestureWidget_C : ULMRBaseGestureWidget {
};

