// WidgetBlueprintGeneratedClass BP_NcAlertWidget.BP_NcAlertWidget_C
// Size: 0x408 (Inherited: 0x400)
struct UBP_NcAlertWidget_C : UNcAlertWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x400(0x08)

	void Construct(); // Function BP_NcAlertWidget.BP_NcAlertWidget_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_NcAlertWidget(int32_t EntryPoint); // Function BP_NcAlertWidget.BP_NcAlertWidget_C.ExecuteUbergraph_BP_NcAlertWidget // (Final|UbergraphFunction) // @ game+0x2849850
};

