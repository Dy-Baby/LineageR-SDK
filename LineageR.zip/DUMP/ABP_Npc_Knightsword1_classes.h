// AnimBlueprintGeneratedClass ABP_Npc_Knightsword1.ABP_Npc_Knightsword1_C
// Size: 0xff8 (Inherited: 0xff8)
struct UABP_Npc_Knightsword1_C : UABP_Npc_Master_LookAt_SP_SP2_C {
};

