// WidgetBlueprintGeneratedClass UI_HUD_Memory_Share_Confirm_Row.UI_HUD_Memory_Share_Confirm_Row_C
// Size: 0x2f8 (Inherited: 0x2e8)
struct UUI_HUD_Memory_Share_Confirm_Row_C : ULMRMemoryShareConfirmRowWidget {
	struct ULMRImage* image_Accept; // 0x2e8(0x08)
	struct ULMRImage* image_Cancel; // 0x2f0(0x08)
};

