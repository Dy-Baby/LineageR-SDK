// BlueprintGeneratedClass BP_NPC_LWmascot.BP_NPC_LWmascot_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_NPC_LWmascot_C : ALMRObject {
};

