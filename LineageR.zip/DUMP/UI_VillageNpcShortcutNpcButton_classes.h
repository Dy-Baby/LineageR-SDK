// WidgetBlueprintGeneratedClass UI_VillageNpcShortcutNpcButton.UI_VillageNpcShortcutNpcButton_C
// Size: 0x500 (Inherited: 0x500)
struct UUI_VillageNpcShortcutNpcButton_C : ULMRVillageNpcShortcutNpcButtonWidget {
};

