// BlueprintGeneratedClass BP_LMRGameInstance.BP_LMRGameInstance_C
// Size: 0x298 (Inherited: 0x298)
struct UBP_LMRGameInstance_C : ULMRGameInstance {
};

