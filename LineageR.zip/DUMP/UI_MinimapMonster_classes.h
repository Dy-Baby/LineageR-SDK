// WidgetBlueprintGeneratedClass UI_MinimapMonster.UI_MinimapMonster_C
// Size: 0x310 (Inherited: 0x310)
struct UUI_MinimapMonster_C : ULMRMinimapMonsterWidget {
};

