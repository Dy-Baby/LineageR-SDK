// BlueprintGeneratedClass BP_LMR_GAMEMODE_INTRO.BP_LMR_GAMEMODE_INTRO_C
// Size: 0x2c8 (Inherited: 0x2c0)
struct ABP_LMR_GAMEMODE_INTRO_C : ALMRGameModeIntro {
	struct USceneComponent* DefaultSceneRoot; // 0x2c0(0x08)
};

