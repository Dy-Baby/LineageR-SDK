// WidgetBlueprintGeneratedClass UI_HUD_party_Option_Btn.UI_HUD_party_Option_Btn_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UUI_HUD_party_Option_Btn_C : ULMRPartyPlayerOptionWidget {
};

