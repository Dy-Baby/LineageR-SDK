// WidgetBlueprintGeneratedClass UI_HUD_QSlot_Slot.UI_HUD_QSlot_Slot_C
// Size: 0x660 (Inherited: 0x650)
struct UUI_HUD_QSlot_Slot_C : ULMRHudQuickSlotBig {
	struct UWidgetAnimation* Ani_QSlot_Exp; // 0x650(0x08)
	struct ULMRImage* Bod_QSlot_Glow_Line; // 0x658(0x08)
};

