// WidgetBlueprintGeneratedClass UI_SocketStone_SimpleSlot_Small.UI_SocketStone_SimpleSlot_Small_C
// Size: 0x2d0 (Inherited: 0x2c8)
struct UUI_SocketStone_SimpleSlot_Small_C : ULMRSocketStoneSimpleSlotWidget {
	struct UWidgetAnimation* ani_select; // 0x2c8(0x08)
};

