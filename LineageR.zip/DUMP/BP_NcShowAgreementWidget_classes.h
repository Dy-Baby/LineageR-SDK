// WidgetBlueprintGeneratedClass BP_NcShowAgreementWidget.BP_NcShowAgreementWidget_C
// Size: 0x440 (Inherited: 0x440)
struct UBP_NcShowAgreementWidget_C : UNcShowAgreementWidget {
};

