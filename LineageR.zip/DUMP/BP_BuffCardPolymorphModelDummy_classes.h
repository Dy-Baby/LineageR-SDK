// BlueprintGeneratedClass BP_BuffCardPolymorphModelDummy.BP_BuffCardPolymorphModelDummy_C
// Size: 0x5f0 (Inherited: 0x5f0)
struct ABP_BuffCardPolymorphModelDummy_C : ALMRObject {
};

