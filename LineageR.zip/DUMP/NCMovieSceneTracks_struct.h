// Enum NCMovieSceneTracks.EWidgetType
enum class EWidgetType : uint8 {
	None = 0,
	TextBlcok = 1,
	RichTextBlock = 2,
	Image = 3,
	EWidgetType_MAX = 4
};

// ScriptStruct NCMovieSceneTracks.MovieSceneInGameCameraBlendTransformTemplateNC01
// Size: 0x4b0 (Inherited: 0x20)
struct FMovieSceneInGameCameraBlendTransformTemplateNC01 : FMovieSceneEvalTemplate {
	char pad_20[0x490]; // 0x20(0x490)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneMorphTargetTemplateNC01
// Size: 0xc8 (Inherited: 0x20)
struct FMovieSceneMorphTargetTemplateNC01 : FMovieSceneEvalTemplate {
	struct FMovieSceneFloatChannel WeightCurve; // 0x20(0xa0)
	struct FName MorphTargetName; // 0xc0(0x08)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleAnimationParams
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneSubTitleAnimationParams {
	struct FText WidgetAnimationName; // 0x00(0x18)
	float Rate; // 0x18(0x04)
	bool Inverse; // 0x1c(0x01)
	bool KeepState; // 0x1d(0x01)
	char pad_1E[0x2]; // 0x1e(0x02)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleContentParams
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneSubTitleContentParams {
	struct FText WidgetName; // 0x00(0x18)
	enum class EWidgetType WidgetType; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleImageParams
// Size: 0x98 (Inherited: 0x00)
struct FMovieSceneSubTitleImageParams {
	struct FSlateBrush Brush; // 0x00(0x88)
	struct FLinearColor ColorAndOpacity; // 0x88(0x10)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleRichTextParams
// Size: 0x438 (Inherited: 0x00)
struct FMovieSceneSubTitleRichTextParams {
	int32_t ID; // 0x00(0x04)
	float DisplayTimePerCharacter; // 0x04(0x04)
	bool bOverrideDefaultStyle; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct FTextBlockStyleNC01 DefaultTextStyleOverride; // 0x10(0x308)
	float MinDesiredWidth; // 0x318(0x04)
	char pad_31C[0x4]; // 0x31c(0x04)
	struct FEllipsisStyleNC01 EllipsisStyle; // 0x320(0x20)
	struct FStrikethroughStyleNC01 StrikethroughStyle; // 0x340(0xf0)
	enum class ETextJustifyNC01 Justification; // 0x430(0x01)
	char pad_431[0x7]; // 0x431(0x07)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleTextParams
// Size: 0x1e8 (Inherited: 0x00)
struct FMovieSceneSubTitleTextParams {
	int32_t ID; // 0x00(0x04)
	float DisplayTimePerCharacter; // 0x04(0x04)
	struct FString StyleTag; // 0x08(0x10)
	bool bOverrideColorAndOpacity; // 0x18(0x01)
	bool bOverrideFont; // 0x19(0x01)
	bool bOverrideAdditionalKerning; // 0x1a(0x01)
	bool bOverrideShadowOffset; // 0x1b(0x01)
	bool bOverrideShadowColorAndOpacity; // 0x1c(0x01)
	char pad_1D[0x3]; // 0x1d(0x03)
	struct FSlateColor ColorAndOpacity; // 0x20(0x28)
	struct FSlateFontInfo Font; // 0x48(0x50)
	float AdditionalKerning; // 0x98(0x04)
	struct FVector2D ShadowOffset; // 0x9c(0x08)
	struct FLinearColor ShadowColorAndOpacity; // 0xa4(0x10)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct FEllipsisStyleNC01 EllipsisStyle; // 0xb8(0x20)
	struct FStrikethroughStyleNC01 StrikethroughStyle; // 0xd8(0xf0)
	enum class ETextJustifyNC01 Justification; // 0x1c8(0x01)
	bool UseOuterGlow; // 0x1c9(0x01)
	char pad_1CA[0x2]; // 0x1ca(0x02)
	struct FLinearColor OuterGlowColor; // 0x1cc(0x10)
	float OuterGlowRadius; // 0x1dc(0x04)
	float OuterGlowDensity; // 0x1e0(0x04)
	float OuterGlowStrength; // 0x1e4(0x04)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleSimpleAnimationParams
// Size: 0x20 (Inherited: 0x00)
struct FMovieSceneSubTitleSimpleAnimationParams {
	struct FText WidgetName; // 0x00(0x18)
	bool KeepState; // 0x18(0x01)
	char pad_19[0x7]; // 0x19(0x07)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleTemplateBaseNC01
// Size: 0x28 (Inherited: 0x20)
struct FMovieSceneSubTitleTemplateBaseNC01 : FMovieSceneEvalTemplate {
	struct UUserWidget* SubTitleWidgetClass; // 0x20(0x08)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleSimpleAnimationSectionTemplateNC01
// Size: 0x30 (Inherited: 0x28)
struct FMovieSceneSubTitleSimpleAnimationSectionTemplateNC01 : FMovieSceneSubTitleTemplateBaseNC01 {
	struct UMovieSceneSubTitleSimpleAnimationSectionNC01* SimpleAnimationSection; // 0x28(0x08)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleAnimationSectionTemplateNC01
// Size: 0x58 (Inherited: 0x28)
struct FMovieSceneSubTitleAnimationSectionTemplateNC01 : FMovieSceneSubTitleTemplateBaseNC01 {
	struct FMovieSceneSubTitleAnimationParams Params; // 0x28(0x20)
	struct FFrameNumber SectionStartTime; // 0x48(0x04)
	struct FFrameRate TickResolution; // 0x4c(0x08)
	char pad_54[0x4]; // 0x54(0x04)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleContentSectionTemplateNC01
// Size: 0x40 (Inherited: 0x28)
struct FMovieSceneSubTitleContentSectionTemplateNC01 : FMovieSceneSubTitleTemplateBaseNC01 {
	struct UMovieSceneSubTitleContentSectionBaseNC01* ContentSection; // 0x28(0x08)
	struct FFrameNumber SectionStartTime; // 0x30(0x04)
	struct FFrameRate TickResolution; // 0x34(0x08)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneSubTitleSectionTemplateNC01
// Size: 0x28 (Inherited: 0x28)
struct FMovieSceneSubTitleSectionTemplateNC01 : FMovieSceneSubTitleTemplateBaseNC01 {
};

// ScriptStruct NCMovieSceneTracks.MovieSceneFollowTargetCamKeyStruct
// Size: 0x48 (Inherited: 0x08)
struct FMovieSceneFollowTargetCamKeyStruct : FMovieSceneKeyStruct {
	float Distance; // 0x08(0x04)
	struct FRotator Rotation; // 0x0c(0x0c)
	struct FVector Offset; // 0x18(0x0c)
	float Weight; // 0x24(0x04)
	struct FFrameNumber Time; // 0x28(0x04)
	char pad_2C[0x1c]; // 0x2c(0x1c)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneTargetFollowCamTemplateNC01
// Size: 0x5d0 (Inherited: 0x20)
struct FMovieSceneTargetFollowCamTemplateNC01 : FMovieSceneEvalTemplate {
	struct FMovieSceneFloatChannel TargetFollowCamDistanceChannel; // 0x20(0xa0)
	struct FMovieSceneFloatChannel TargetFollowCamRotationChannel[0x3]; // 0xc0(0x1e0)
	struct FMovieSceneFloatChannel TargetFollowCamOffsetChannel[0x3]; // 0x2a0(0x1e0)
	struct FMovieSceneFloatChannel TargetFollowCamWeightChannel; // 0x480(0xa0)
	struct FName TargetBoneSocketName; // 0x520(0x08)
	struct FMovieSceneObjectBindingID TargetBindingObjectID; // 0x528(0x18)
	char pad_540[0x90]; // 0x540(0x90)
};

// ScriptStruct NCMovieSceneTracks.MovieSceneWalkingSnapFloorTemplateNC01
// Size: 0x300 (Inherited: 0x20)
struct FMovieSceneWalkingSnapFloorTemplateNC01 : FMovieSceneEvalTemplate {
	struct FMovieSceneBoolChannel WalkingSnapFloorChannel; // 0x20(0x90)
	bool bSnapFloorAtBeginning; // 0xb0(0x01)
	bool bIsAvailabeFallingState; // 0xb1(0x01)
	char pad_B2[0x2]; // 0xb2(0x02)
	float UpperDistZ; // 0xb4(0x04)
	float LowerDistZ; // 0xb8(0x04)
	struct FFrameRate TickResolution; // 0xbc(0x08)
	struct FFrameNumber GoalFrameNumber; // 0xc4(0x04)
	char pad_C8[0x238]; // 0xc8(0x238)
};

