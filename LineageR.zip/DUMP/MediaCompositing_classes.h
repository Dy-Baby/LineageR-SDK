// Class MediaCompositing.MovieSceneMediaPlayerPropertySection
// Size: 0x140 (Inherited: 0x130)
struct UMovieSceneMediaPlayerPropertySection : UMovieSceneSection {
	struct UMediaSource* MediaSource; // 0x130(0x08)
	bool bLoop; // 0x138(0x01)
	char pad_139[0x7]; // 0x139(0x07)
};

// Class MediaCompositing.MovieSceneMediaPlayerPropertyTrack
// Size: 0x88 (Inherited: 0x88)
struct UMovieSceneMediaPlayerPropertyTrack : UMovieScenePropertyTrack {
};

// Class MediaCompositing.MovieSceneMediaSection
// Size: 0x160 (Inherited: 0x130)
struct UMovieSceneMediaSection : UMovieSceneSection {
	struct UMediaSource* MediaSource; // 0x130(0x08)
	bool bLooping; // 0x138(0x01)
	char pad_139[0x3]; // 0x139(0x03)
	struct FFrameNumber StartFrameOffset; // 0x13c(0x04)
	struct UMediaTexture* MediaTexture; // 0x140(0x08)
	struct UMediaSoundComponent* MediaSoundComponent; // 0x148(0x08)
	bool bUseExternalMediaPlayer; // 0x150(0x01)
	char pad_151[0x7]; // 0x151(0x07)
	struct UMediaPlayer* ExternalMediaPlayer; // 0x158(0x08)
};

// Class MediaCompositing.MovieSceneMediaTrack
// Size: 0x68 (Inherited: 0x58)
struct UMovieSceneMediaTrack : UMovieSceneNameableTrack {
	struct TArray<struct UMovieSceneSection*> MediaSections; // 0x58(0x10)
};

