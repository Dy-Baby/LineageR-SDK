// WidgetBlueprintGeneratedClass UI_HUD.UI_HUD_C
// Size: 0x2e0 (Inherited: 0x2b8)
struct UUI_HUD_C : ULMRMainWidget {
	struct UCanvasPanel* MainRootPanel; // 0x2b8(0x08)
	struct UUI_Game_HUD_C* UI_Game_HUD; // 0x2c0(0x08)
	struct UUI_GameInfo_HUD_C* UI_GameInfo_HUD; // 0x2c8(0x08)
	struct UUI_LongPress_C* UI_LongPress; // 0x2d0(0x08)
	struct UUI_WidgetNameTag_C* UI_UINameTag; // 0x2d8(0x08)
};

