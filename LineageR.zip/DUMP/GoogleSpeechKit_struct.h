// Enum GoogleSpeechKit.EGoogleRecordingDeviceType
enum class EGoogleRecordingDeviceType : uint8 {
	RECORDING_DEVICE_TYPE_UNSPECIFIED = 0,
	SMARTPHONE = 1,
	PC = 2,
	PHONE_LINE = 3,
	VEHICLE = 4,
	OTHER_OUTDOOR_DEVICE = 5,
	OTHER_INDOOR_DEVICE = 6,
	EGoogleRecordingDeviceType_MAX = 7
};

// Enum GoogleSpeechKit.EGoogleOriginalMediaType
enum class EGoogleOriginalMediaType : uint8 {
	ORIGINAL_MEDIA_TYPE_UNSPECIFIED = 0,
	AUDIO = 1,
	VIDEO = 2,
	EGoogleOriginalMediaType_MAX = 3
};

// Enum GoogleSpeechKit.EGoogleMicrophoneDistance
enum class EGoogleMicrophoneDistance : uint8 {
	MICROPHONE_DISTANCE_UNSPECIFIED = 0,
	NEARFIELD = 1,
	MIDFIELD = 2,
	FARFIELD = 3,
	EGoogleMicrophoneDistance_MAX = 4
};

// Enum GoogleSpeechKit.EGoogleInteractionType
enum class EGoogleInteractionType : uint8 {
	INTERACTION_TYPE_UNSPECIFIED = 0,
	DISCUSSION = 1,
	PRESENTATION = 2,
	PHONE_CALL = 3,
	VOICEMAIL = 4,
	PROFESSIONALLY_PRODUCED = 5,
	VOICE_SEARCH = 6,
	VOICE_COMMAND = 7,
	DICTATION = 8,
	EGoogleInteractionType_MAX = 9
};

// Enum GoogleSpeechKit.EGoogleRecognitionModel
enum class EGoogleRecognitionModel : uint8 {
	Video = 0,
	PhoneCall = 1,
	CommandAndSearch = 2,
	Default = 3,
	EGoogleRecognitionModel_MAX = 4
};

// Enum GoogleSpeechKit.EGoogleSTTLanguage
enum class EGoogleSTTLanguage : uint8 {
	Afrikaans = 0,
	Amharic = 1,
	Armenian = 2,
	Azerbaijani = 3,
	Indonesian = 4,
	Malay = 5,
	BengaliBangladesh = 6,
	BengaliIndia = 7,
	Catalan = 8,
	Czech = 9,
	Danish = 10,
	German = 11,
	EnglishAustralia = 12,
	EnglishCanada = 13,
	EnglishGhana = 14,
	EnglishUK = 15,
	EnglishIndia = 16,
	EnglishIreland = 17,
	EnglishKenya = 18,
	EnglishNewZealand = 19,
	EnglishNigeria = 20,
	EnglishPhilippines = 21,
	EnglishSouthAfrica = 22,
	EnglishTanzania = 23,
	EnglishUnitedStates = 24,
	SpanishArgentina = 25,
	SpanishBolivia = 26,
	SpanishChile = 27,
	SpanishColombia = 28,
	SpanishCostaRica = 29,
	SpanishEcuador = 30,
	SpanishElSalvador = 31,
	SpanishSpain = 32,
	SpanishUnitedStates = 33,
	SpanishGuatemala = 34,
	SpanishHonduras = 35,
	SpanishMexico = 36,
	SpanishNicaragua = 37,
	SpanishPanama = 38,
	SpanishParaguay = 39,
	SpanishPeru = 40,
	SpanishPuertoRico = 41,
	SpanishDominicanRepublic = 42,
	SpanishUruguay = 43,
	SpanishVenezuela = 44,
	BasqueSpain = 45,
	FilipinoPhilippines = 46,
	FrenchCanada = 47,
	FrenchFrance = 48,
	GalicianSpain = 49,
	GeorgianGeorgia = 50,
	GujaratiIndia = 51,
	CroatianCroatia = 52,
	ZuluSouthAfrica = 53,
	IcelandicIceland = 54,
	ItalianItaly = 55,
	JavaneseIndonesia = 56,
	KannadaIndia = 57,
	KhmerCambodia = 58,
	LaoLaos = 59,
	LatvianLatvia = 60,
	LithuanianLithuania = 61,
	HungarianHungary = 62,
	MalayalamIndia = 63,
	MarathiIndia = 64,
	DutchNetherlands = 65,
	NepaliNepal = 66,
	NorwegianBokmalNorway = 67,
	PolishPoland = 68,
	PortugueseBrazil = 69,
	PortuguesePortugal = 70,
	RomanianRomania = 71,
	SinhalaSriLanka = 72,
	SlovakSlovakia = 73,
	SlovenianSlovenia = 74,
	SundaneseIndonesia = 75,
	SwahiliTanzania = 76,
	SwahiliKenya = 77,
	FinnishFinland = 78,
	SwedishSweden = 79,
	TamilIndia = 80,
	TamilSingapore = 81,
	TamilSriLanka = 82,
	TamilMalaysia = 83,
	TeluguIndia = 84,
	VietnameseVietnam = 85,
	TurkishTurkey = 86,
	UrduPakistan = 87,
	UrduIndia = 88,
	GreekGreece = 89,
	BulgarianBulgaria = 90,
	RussianRussia = 91,
	SerbianSerbia = 92,
	UkrainianUkraine = 93,
	HebrewIsrael = 94,
	ArabicIsrael = 95,
	ArabicJordan = 96,
	ArabicUnitedArabEmirates = 97,
	ArabicBahrain = 98,
	ArabicAlgeria = 99,
	ArabicSaudiArabia = 100,
	ArabicIraq = 101,
	ArabicKuwait = 102,
	ArabicMorocco = 103,
	ArabicTunisia = 104,
	ArabicOman = 105,
	ArabicStateofPalestine = 106,
	ArabicQatar = 107,
	ArabicLebanon = 108,
	ArabicEgypt = 109,
	PersianIran = 110,
	HindiIndia = 111,
	ThaiThailand = 112,
	KoreanSouthKorea = 113,
	ChineseMandarinTraditionalTaiwan = 114,
	ChineseCantoneseTraditionalHongKong = 115,
	JapaneseJapan = 116,
	ChineseMandarinSimplifiedHongKong = 117,
	ChineseMandarinSimplifiedChina = 118,
	EGoogleSTTLanguage_MAX = 119
};

// Enum GoogleSpeechKit.EAudioEffectsProfile
enum class EAudioEffectsProfile : uint8 {
	Wearable = 0,
	Handset = 1,
	Headphone = 2,
	SmallBluetoothSpeaker = 3,
	MediumBluetoothSpeaker = 4,
	LargeHomeEntertainment = 5,
	LargeAutomotive = 6,
	Telephony = 7,
	EAudioEffectsProfile_MAX = 8
};

// Enum GoogleSpeechKit.EGoogleTTSLanguage
enum class EGoogleTTSLanguage : uint8 {
	ar_XA_Wavenet_A_FEMALE = 0,
	ar_XA_Wavenet_B_MALE = 1,
	ar_XA_Wavenet_C_MALE = 2,
	cs_CZ_Wavenet_A_FEMALE = 3,
	da_DK_Wavenet_A_FEMALE = 4,
	de_DE_Wavenet_A_FEMALE = 5,
	de_DE_Wavenet_B_MALE = 6,
	de_DE_Wavenet_C_FEMALE = 7,
	de_DE_Wavenet_D_MALE = 8,
	el_GR_Wavenet_A_FEMALE = 9,
	en_AU_Wavenet_A_FEMALE = 10,
	en_AU_Wavenet_B_MALE = 11,
	en_AU_Wavenet_C_FEMALE = 12,
	en_AU_Wavenet_D_MALE = 13,
	en_GB_Wavenet_A_FEMALE = 14,
	en_GB_Wavenet_B_MALE = 15,
	en_GB_Wavenet_C_FEMALE = 16,
	en_GB_Wavenet_D_MALE = 17,
	en_IN_Wavenet_A_FEMALE = 18,
	en_IN_Wavenet_B_MALE = 19,
	en_IN_Wavenet_C_MALE = 20,
	en_US_Wavenet_A_MALE = 21,
	en_US_Wavenet_B_MALE = 22,
	en_US_Wavenet_C_FEMALE = 23,
	en_US_Wavenet_D_MALE = 24,
	en_US_Wavenet_E_FEMALE = 25,
	en_US_Wavenet_F_FEMALE = 26,
	fi_FI_Wavenet_A_FEMALE = 27,
	fil_PH_Wavenet_A_FEMALE = 28,
	fr_CA_Wavenet_A_FEMALE = 29,
	fr_CA_Wavenet_B_MALE = 30,
	fr_CA_Wavenet_C_FEMALE = 31,
	fr_CA_Wavenet_D_MALE = 32,
	fr_FR_Wavenet_A_FEMALE = 33,
	fr_FR_Wavenet_B_MALE = 34,
	fr_FR_Wavenet_C_FEMALE = 35,
	fr_FR_Wavenet_D_MALE = 36,
	hi_IN_Wavenet_A_FEMALE = 37,
	hi_IN_Wavenet_B_MALE = 38,
	hi_IN_Wavenet_C_MALE = 39,
	hu_HU_Wavenet_A_FEMALE = 40,
	id_ID_Wavenet_A_FEMALE = 41,
	id_ID_Wavenet_B_MALE = 42,
	id_ID_Wavenet_C_MALE = 43,
	it_IT_Wavenet_A_FEMALE = 44,
	ja_JP_Wavenet_A_FEMALE = 45,
	ja_JP_Wavenet_B_FEMALE = 46,
	ja_JP_Wavenet_C_MALE = 47,
	ja_JP_Wavenet_D_MALE = 48,
	ko_KR_Wavenet_B_FEMALE = 49,
	ko_KR_Wavenet_C_MALE = 50,
	ko_KR_Wavenet_D_MALE = 51,
	ko_KR_Wavenet_A_FEMALE = 52,
	nb_no_Wavenet_E_FEMALE = 53,
	nb_NO_Wavenet_A_FEMALE = 54,
	nb_NO_Wavenet_B_MALE = 55,
	nb_NO_Wavenet_C_FEMALE = 56,
	nb_NO_Wavenet_D_MALE = 57,
	nl_NL_Wavenet_B_MALE = 58,
	nl_NL_Wavenet_C_MALE = 59,
	nl_NL_Wavenet_D_FEMALE = 60,
	nl_NL_Wavenet_E_FEMALE = 61,
	nl_NL_Wavenet_A_FEMALE = 62,
	pl_PL_Wavenet_A_FEMALE = 63,
	pl_PL_Wavenet_B_MALE = 64,
	pl_PL_Wavenet_C_MALE = 65,
	pl_PL_Wavenet_D_FEMALE = 66,
	pl_PL_Wavenet_E_FEMALE = 67,
	pt_BR_Wavenet_A_FEMALE = 68,
	pt_PT_Wavenet_A_FEMALE = 69,
	pt_PT_Wavenet_B_MALE = 70,
	pt_PT_Wavenet_C_MALE = 71,
	pt_PT_Wavenet_D_FEMALE = 72,
	ru_RU_Wavenet_A_FEMALE = 73,
	ru_RU_Wavenet_B_MALE = 74,
	ru_RU_Wavenet_C_FEMALE = 75,
	ru_RU_Wavenet_D_MALE = 76,
	sk_SK_Wavenet_A_FEMALE = 77,
	sv_SE_Wavenet_A_FEMALE = 78,
	tr_TR_Wavenet_A_FEMALE = 79,
	tr_TR_Wavenet_B_MALE = 80,
	tr_TR_Wavenet_C_FEMALE = 81,
	tr_TR_Wavenet_D_FEMALE = 82,
	tr_TR_Wavenet_E_MALE = 83,
	uk_UA_Wavenet_A_FEMALE = 84,
	vi_VN_Wavenet_A_FEMALE = 85,
	vi_VN_Wavenet_B_MALE = 86,
	vi_VN_Wavenet_C_FEMALE = 87,
	vi_VN_Wavenet_D_MALE = 88,
	es_ES_Standard_A_FEMALE = 89,
	ar_XA_Standard_A_FEMALE = 90,
	ar_XA_Standard_B_MALE = 91,
	ar_XA_Standard_C_MALE = 92,
	it_IT_Standard_A_FEMALE = 93,
	ru_RU_Standard_A_FEMALE = 94,
	ru_RU_Standard_B_MALE = 95,
	ru_RU_Standard_C_FEMALE = 96,
	ru_RU_Standard_D_MALE = 97,
	ko_KR_Standard_A_FEMALE = 98,
	ko_KR_Standard_B_FEMALE = 99,
	ko_KR_Standard_C_MALE = 100,
	ko_KR_Standard_D_MALE = 101,
	ja_JP_Standard_A_FEMALE = 102,
	ja_JP_Standard_B_FEMALE = 103,
	ja_JP_Standard_C_MALE = 104,
	ja_JP_Standard_D_MALE = 105,
	vi_VN_Standard_A_FEMALE = 106,
	vi_VN_Standard_B_MALE = 107,
	vi_VN_Standard_C_FEMALE = 108,
	vi_VN_Standard_D_MALE = 109,
	fil_PH_Standard_A_FEMALE = 110,
	id_ID_Standard_A_FEMALE = 111,
	id_ID_Standard_B_MALE = 112,
	id_ID_Standard_C_MALE = 113,
	nl_NL_Standard_A_FEMALE = 114,
	nl_NL_Standard_B_MALE = 115,
	nl_NL_Standard_C_MALE = 116,
	nl_NL_Standard_D_FEMALE = 117,
	nl_NL_Standard_E_FEMALE = 118,
	cs_CZ_Standard_A_FEMALE = 119,
	el_GR_Standard_A_FEMALE = 120,
	pt_BR_Standard_A_FEMALE = 121,
	hu_HU_Standard_A_FEMALE = 122,
	pl_PL_Standard_E_FEMALE = 123,
	pl_PL_Standard_A_FEMALE = 124,
	pl_PL_Standard_B_MALE = 125,
	pl_PL_Standard_C_MALE = 126,
	pl_PL_Standard_D_FEMALE = 127,
	sk_SK_Standard_A_FEMALE = 128,
	tr_TR_Standard_A_FEMALE = 129,
	tr_TR_Standard_B_MALE = 130,
	tr_TR_Standard_C_FEMALE = 131,
	tr_TR_Standard_D_FEMALE = 132,
	tr_TR_Standard_E_MALE = 133,
	uk_UA_Standard_A_FEMALE = 134,
	en_IN_Standard_A_FEMALE = 135,
	en_IN_Standard_B_MALE = 136,
	en_IN_Standard_C_MALE = 137,
	hi_IN_Standard_A_FEMALE = 138,
	hi_IN_Standard_B_MALE = 139,
	hi_IN_Standard_C_MALE = 140,
	da_DK_Standard_A_FEMALE = 141,
	fi_FI_Standard_A_FEMALE = 142,
	pt_PT_Standard_A_FEMALE = 143,
	pt_PT_Standard_B_MALE = 144,
	pt_PT_Standard_C_MALE = 145,
	pt_PT_Standard_D_FEMALE = 146,
	nb_no_Standard_E_FEMALE = 147,
	nb_NO_Standard_A_FEMALE = 148,
	nb_NO_Standard_B_MALE = 149,
	nb_NO_Standard_C_FEMALE = 150,
	nb_NO_Standard_D_MALE = 151,
	sv_SE_Standard_A_FEMALE = 152,
	en_GB_Standard_A_FEMALE = 153,
	en_GB_Standard_B_MALE = 154,
	en_GB_Standard_C_FEMALE = 155,
	en_GB_Standard_D_MALE = 156,
	en_US_Standard_B_MALE = 157,
	en_US_Standard_C_FEMALE = 158,
	en_US_Standard_D_MALE = 159,
	en_US_Standard_E_FEMALE = 160,
	de_DE_Standard_A_FEMALE = 161,
	de_DE_Standard_B_MALE = 162,
	en_AU_Standard_A_FEMALE = 163,
	en_AU_Standard_B_MALE = 164,
	en_AU_Standard_C_FEMALE = 165,
	en_AU_Standard_D_MALE = 166,
	fr_CA_Standard_A_FEMALE = 167,
	fr_CA_Standard_B_MALE = 168,
	fr_CA_Standard_C_FEMALE = 169,
	fr_CA_Standard_D_MALE = 170,
	fr_FR_Standard_A_FEMALE = 171,
	fr_FR_Standard_B_MALE = 172,
	fr_FR_Standard_C_FEMALE = 173,
	fr_FR_Standard_D_MALE = 174,
	EGoogleTTSLanguage_MAX = 175
};

// ScriptStruct GoogleSpeechKit.RecognitionVariant
// Size: 0x18 (Inherited: 0x00)
struct FRecognitionVariant {
	struct FString Text; // 0x00(0x10)
	float Confidence; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct GoogleSpeechKit.GoogleSpeechRecognitionParams
// Size: 0x50 (Inherited: 0x00)
struct FGoogleSpeechRecognitionParams {
	struct TArray<char> RawSamples; // 0x00(0x10)
	enum class EGoogleSTTLanguage Language; // 0x10(0x01)
	char pad_11[0x7]; // 0x11(0x07)
	struct TArray<struct FString> speechContexts; // 0x18(0x10)
	enum class EGoogleRecognitionModel Model; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
	struct FGoogleRecognitionMetadata RecognitionMetadata; // 0x30(0x18)
	bool bUseEnhancedModels; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
};

// ScriptStruct GoogleSpeechKit.GoogleRecognitionMetadata
// Size: 0x18 (Inherited: 0x00)
struct FGoogleRecognitionMetadata {
	enum class EGoogleInteractionType InteractionType; // 0x00(0x01)
	enum class EGoogleMicrophoneDistance MicrophoneDistance; // 0x01(0x01)
	enum class EGoogleOriginalMediaType OriginalMediaType; // 0x02(0x01)
	enum class EGoogleRecordingDeviceType RecordingDeviceType; // 0x03(0x01)
	char pad_4[0x4]; // 0x04(0x04)
	struct FString AudioTopic; // 0x08(0x10)
};

// ScriptStruct GoogleSpeechKit.GoogleSpeechSynthesisParams
// Size: 0x40 (Inherited: 0x00)
struct FGoogleSpeechSynthesisParams {
	struct FText Text; // 0x00(0x18)
	bool bUseSsml; // 0x18(0x01)
	char pad_19[0x3]; // 0x19(0x03)
	float Pitch; // 0x1c(0x04)
	float SpeakingRate; // 0x20(0x04)
	char pad_24[0x4]; // 0x24(0x04)
	struct TArray<enum class EAudioEffectsProfile> AudioEffectsStack; // 0x28(0x10)
	enum class EGoogleTTSLanguage Language; // 0x38(0x01)
	char pad_39[0x7]; // 0x39(0x07)
};

