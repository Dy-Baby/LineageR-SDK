// WidgetBlueprintGeneratedClass BP_NcWidget_Template.BP_NcWidget_Template_C
// Size: 0x5c0 (Inherited: 0x5b0)
struct UBP_NcWidget_Template_C : UNcWidget_Template {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x5b0(0x08)
	struct UNamedSlot* ExtraSectionSlot; // 0x5b8(0x08)

	void Construct(); // Function BP_NcWidget_Template.BP_NcWidget_Template_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_BP_NcWidget_Template(int32_t EntryPoint); // Function BP_NcWidget_Template.BP_NcWidget_Template_C.ExecuteUbergraph_BP_NcWidget_Template // (Final|UbergraphFunction) // @ game+0x2849850
};

