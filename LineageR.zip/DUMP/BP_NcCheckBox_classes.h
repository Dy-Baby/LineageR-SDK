// WidgetBlueprintGeneratedClass BP_NcCheckBox.BP_NcCheckBox_C
// Size: 0x428 (Inherited: 0x428)
struct UBP_NcCheckBox_C : UNcCheckBox {
};

