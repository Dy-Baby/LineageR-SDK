// BlueprintGeneratedClass BP_BuffCardTableParent.BP_BuffCardTableParent_C
// Size: 0x6c0 (Inherited: 0x6b0)
struct ABP_BuffCardTableParent_C : ALMRBuffCardActor {
	struct UWidgetComponent* WidgetInfo; // 0x6b0(0x08)
	struct USkeletalMeshComponent* ShadowMesh; // 0x6b8(0x08)
};

