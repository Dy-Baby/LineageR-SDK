// WidgetBlueprintGeneratedClass UI_SocketSlots.UI_SocketSlots_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UUI_SocketSlots_C : ULMRSocketSlotsWidget {
};

