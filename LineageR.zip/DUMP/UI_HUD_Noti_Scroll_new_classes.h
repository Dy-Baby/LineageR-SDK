// WidgetBlueprintGeneratedClass UI_HUD_Noti_Scroll_new.UI_HUD_Noti_Scroll_new_C
// Size: 0x2e8 (Inherited: 0x2e8)
struct UUI_HUD_Noti_Scroll_new_C : ULMRBattleLogWidget {
};

