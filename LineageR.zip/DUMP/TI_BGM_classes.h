// BlueprintGeneratedClass TI_BGM.TI_BGM_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_BGM_C : ALevelScriptActor {
};

