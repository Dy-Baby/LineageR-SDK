// WidgetBlueprintGeneratedClass UI_PowerSavingMode_VendettaPlayerList.UI_PowerSavingMode_VendettaPlayerList_C
// Size: 0x2c8 (Inherited: 0x2c8)
struct UUI_PowerSavingMode_VendettaPlayerList_C : ULMRPowerSavingModeVendettaSlotWidget {
};

