// BlueprintGeneratedClass BP_Default_DungeonEnvBlobShadow.BP_Default_DungeonEnvBlobShadow_C
// Size: 0x4a0 (Inherited: 0x4a0)
struct UBP_Default_DungeonEnvBlobShadow_C : ULMRCharacterStaticMeshComponent {
};

