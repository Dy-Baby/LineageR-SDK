// BlueprintGeneratedClass BP_SelectEffect.BP_SelectEffect_C
// Size: 0x238 (Inherited: 0x220)
struct ABP_SelectEffect_C : AActor {
	struct UStaticMeshComponent* StaticMesh; // 0x220(0x08)
	struct UPointLightComponent* PointLight; // 0x228(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x230(0x08)
};

