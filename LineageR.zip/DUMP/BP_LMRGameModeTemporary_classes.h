// BlueprintGeneratedClass BP_LMRGameModeTemporary.BP_LMRGameModeTemporary_C
// Size: 0x2c8 (Inherited: 0x2c0)
struct ABP_LMRGameModeTemporary_C : ALMRGameModeBase {
	struct USceneComponent* DefaultSceneRoot; // 0x2c0(0x08)
};

