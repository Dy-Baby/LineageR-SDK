// AnimBlueprintGeneratedClass ABP_Mdoll_NoviceGolem.ABP_Mdoll_NoviceGolem_C
// Size: 0xb20 (Inherited: 0xb20)
struct UABP_Mdoll_NoviceGolem_C : UABP_Mdoll_Master_C {
};

