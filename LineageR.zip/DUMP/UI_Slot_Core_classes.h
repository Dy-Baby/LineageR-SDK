// WidgetBlueprintGeneratedClass UI_Slot_Core.UI_Slot_Core_C
// Size: 0x488 (Inherited: 0x430)
struct UUI_Slot_Core_C : ULMRSlotCoreWidget {
	struct ULMRImage* BG_None; // 0x430(0x08)
	struct ULMRImage* BG_Normal; // 0x438(0x08)
	struct ULMRImage* BG_Paint; // 0x440(0x08)
	struct ULMRImage* BG_QuickSlot; // 0x448(0x08)
	struct ULMRImage* Flare; // 0x450(0x08)
	struct ULMRImage* GuideBox; // 0x458(0x08)
	struct ULMRImage* Light; // 0x460(0x08)
	struct ULMRImage* LineAura; // 0x468(0x08)
	struct ULMRImage* Outline; // 0x470(0x08)
	struct ULMRImage* OutlineBurst; // 0x478(0x08)
	struct ULMRImage* Rectglow; // 0x480(0x08)
};

