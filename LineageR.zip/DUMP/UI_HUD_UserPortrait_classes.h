// WidgetBlueprintGeneratedClass UI_HUD_UserPortrait.UI_HUD_UserPortrait_C
// Size: 0x310 (Inherited: 0x2f8)
struct UUI_HUD_UserPortrait_C : ULMRUserPortraitWidget {
	struct UWidgetAnimation* ani_select; // 0x2f8(0x08)
	struct ULMRImage* GuideBox; // 0x300(0x08)
	struct ULMRImage* Img_Shadow; // 0x308(0x08)
};

