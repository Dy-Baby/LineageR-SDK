// BlueprintGeneratedClass BP_GatheringEffect.BP_GatheringEffect_C
// Size: 0x280 (Inherited: 0x280)
struct ABP_GatheringEffect_C : ALMRLootingEffectActor {
};

