// BlueprintGeneratedClass TI_G03.TI_G03_C
// Size: 0x228 (Inherited: 0x228)
struct ATI_G03_C : ALevelScriptActor {
};

