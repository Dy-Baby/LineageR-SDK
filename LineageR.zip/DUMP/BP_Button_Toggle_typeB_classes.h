// WidgetBlueprintGeneratedClass BP_Button_Toggle_typeB.BP_Button_Toggle_typeB_C
// Size: 0x418 (Inherited: 0x400)
struct UBP_Button_Toggle_typeB_C : ULMRTemplateToggleButtonSimple {
	struct ULMRImage* Img_Focuse; // 0x400(0x08)
	struct ULMRImage* img_Glow; // 0x408(0x08)
	struct ULMRTextBlock* Text; // 0x410(0x08)
};

