// AnimBlueprintGeneratedClass ABP_Npc_Master.ABP_Npc_Master_C
// Size: 0xa48 (Inherited: 0x440)
struct UABP_Npc_Master_C : ULMRAnimInstance {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x440(0x08)
	struct FAnimNode_Root AnimGraphNode_Root; // 0x448(0x30)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_3; // 0x478(0x28)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult_2; // 0x4a0(0x28)
	struct FAnimNode_BlendSpacePlayer AnimGraphNode_BlendSpacePlayer; // 0x4c8(0xe0)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_4; // 0x5a8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_3; // 0x5d8(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_3; // 0x650(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine_2; // 0x680(0xb0)
	struct FAnimNode_BlendListByBool AnimGraphNode_BlendListByBool; // 0x730(0xa0)
	struct FAnimNode_Slot AnimGraphNode_Slot; // 0x7d0(0x48)
	struct FAnimNode_TransitionResult AnimGraphNode_TransitionResult; // 0x818(0x28)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer_2; // 0x840(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult_2; // 0x8b8(0x30)
	struct FAnimNode_SequencePlayer AnimGraphNode_SequencePlayer; // 0x8e8(0x78)
	struct FAnimNode_StateResult AnimGraphNode_StateResult; // 0x960(0x30)
	struct FAnimNode_StateMachine AnimGraphNode_StateMachine; // 0x990(0xb0)
	float SpineLookAtAlpha; // 0xa40(0x04)
	float HeadLookAtAlpha; // 0xa44(0x04)

	void AnimGraph(struct FPoseLink& AnimGraph); // Function ABP_Npc_Master.ABP_Npc_Master_C.AnimGraph // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_BlendSpacePlayer_B20FEEA8431D33A59DC71AA4AC7BC747(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_BlendSpacePlayer_B20FEEA8431D33A59DC71AA4AC7BC747 // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_2F57749F4D1441421D49BA8C5F59382B(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_2F57749F4D1441421D49BA8C5F59382B // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_BlendListByBool_ABBA7EF846A6EFBFA6E3BFB5707846EE(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_BlendListByBool_ABBA7EF846A6EFBFA6E3BFB5707846EE // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_0FAF85824C3ACBB5FF007F8E37FDD431(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_0FAF85824C3ACBB5FF007F8E37FDD431 // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_F06986B04836C42CE1AB999CAFCA3D62(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_F06986B04836C42CE1AB999CAFCA3D62 // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_E1011C494C2AFC5E16D965A350379D41(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_E1011C494C2AFC5E16D965A350379D41 // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_26A0C5584708AC37B22693AF82573E5B(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_SequencePlayer_26A0C5584708AC37B22693AF82573E5B // (BlueprintEvent) // @ game+0x2849850
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_ACD98CF14B7367C8B903709967E2AB14(); // Function ABP_Npc_Master.ABP_Npc_Master_C.EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Npc_Master_AnimGraphNode_TransitionResult_ACD98CF14B7367C8B903709967E2AB14 // (BlueprintEvent) // @ game+0x2849850
	void ExecuteUbergraph_ABP_Npc_Master(int32_t EntryPoint); // Function ABP_Npc_Master.ABP_Npc_Master_C.ExecuteUbergraph_ABP_Npc_Master // (Final|UbergraphFunction) // @ game+0x2849850
};

