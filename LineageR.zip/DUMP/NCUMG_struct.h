// Enum NCUMG.EComboBoxMenuDirectioon
enum class EComboBoxMenuDirectioon : uint8 {
	Downward = 0,
	Upward = 1,
	Leftward = 2,
	Rightward = 3,
	EComboBoxMenuDirectioon_MAX = 4
};

// Enum NCUMG.EComboBoxArrowPosition
enum class EComboBoxArrowPosition : uint8 {
	Left = 0,
	Right = 1,
	EComboBoxArrowPosition_MAX = 2
};

// Enum NCUMG.ETextJustifyNC01
enum class ETextJustifyNC01 : uint8 {
	Left = 0,
	Center = 1,
	Right = 2,
	EqualSpace = 3,
	ETextJustifyNC01_MAX = 4
};

// Enum NCUMG.EPaperFlipBookStatus
enum class EPaperFlipBookStatus : uint8 {
	Play = 0,
	Pause = 1,
	Stop = 2,
	EPaperFlipBookStatus_MAX = 3
};

// Enum NCUMG.EMenuPlacementNC01
enum class EMenuPlacementNC01 : uint8 {
	MenuPlacementNC01_BelowAnchor = 0,
	MenuPlacementNC01_CenteredBelowAnchor = 1,
	MenuPlacementNC01_BelowRightAnchor = 2,
	MenuPlacementNC01_ComboBox = 3,
	MenuPlacementNC01_ComboBoxUp = 4,
	MenuPlacementNC01_ComboBoxRightV2 = 5,
	MenuPlacementNC01_ComboBoxLeft = 6,
	MenuPlacementNC01_ComboBoxRight = 7,
	MenuPlacementNC01_MenuRight = 8,
	MenuPlacementNC01_AboveAnchor = 9,
	MenuPlacementNC01_CenteredAboveAnchor = 10,
	MenuPlacementNC01_AboveRightAnchor = 11,
	MenuPlacementNC01_MenuLeft = 12,
	MenuPlacementNC01_Center = 13,
	MenuPlacementNC01_RightLeftCenter = 14,
	MenuPlacementNC01_MatchBottomLeft = 15,
	MenuPlacementNC01_MAX = 16
};

// Enum NCUMG.EScrollBarLayoutTypeNC01
enum class EScrollBarLayoutTypeNC01 : uint8 {
	SeperateBox = 0,
	Overlap = 1,
	EScrollBarLayoutTypeNC01_MAX = 2
};

// Enum NCUMG.EStretchNC01
enum class EStretchNC01 : uint8 {
	None = 0,
	Fill = 1,
	ScaleToFit = 2,
	ScaleToFitX = 3,
	ScaleToFitY = 4,
	ScaleToFill = 5,
	ScaleBySafeZone = 6,
	UserSpecified = 7,
	ScaleToText = 8,
	EStretchNC01_MAX = 9
};

// Enum NCUMG.EUIParticleStateNC01
enum class EUIParticleStateNC01 : uint8 {
	ActivateSystem = 0,
	DeactivateSystem = 1,
	Complete = 2,
	EUIParticleStateNC01_MAX = 3
};

// ScriptStruct NCUMG.ComboBoxStyleNC01
// Size: 0xe40 (Inherited: 0x08)
struct FComboBoxStyleNC01 : FSlateWidgetStyle {
	struct FComboBoxCommonInfoNC01 CommonInfo; // 0x08(0x30)
	struct FComboBoxButtonStyleNC01 ButtonStyle; // 0x38(0x4e8)
	struct FComboBoxMenuStyleNC01 MenuStyle; // 0x520(0x920)
};

// ScriptStruct NCUMG.ComboBoxMenuStyleNC01
// Size: 0x920 (Inherited: 0x08)
struct FComboBoxMenuStyleNC01 : FSlateWidgetStyle {
	enum class EComboBoxMenuDirectioon MenuDirection; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float MinListHeight; // 0x0c(0x04)
	float MaxListHeight; // 0x10(0x04)
	float FixedWidth; // 0x14(0x04)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x18(0x38)
	struct FSlateFontInfo Font; // 0x50(0x50)
	float AdditionalKerning; // 0xa0(0x04)
	char pad_A4[0x4]; // 0xa4(0x04)
	struct FSlateBrush MenuBorderBrush; // 0xa8(0x88)
	struct FMargin MenuBorderPadding; // 0x130(0x10)
	struct FVector2D MenuBorderOffset; // 0x140(0x08)
	struct FTableRowStyle ItemRowStyle; // 0x148(0x7c8)
	struct FMargin ItemRowPadding; // 0x910(0x10)
};

// ScriptStruct NCUMG.BaseTextStyleInfoNC01
// Size: 0x38 (Inherited: 0x00)
struct FBaseTextStyleInfoNC01 {
	struct UDataTable* BaseTextStyleSet; // 0x00(0x08)
	struct TArray<struct FName> StyleTagCandidates; // 0x08(0x10)
	struct FString StyleTag; // 0x18(0x10)
	bool bOverrideColorAndOpacity; // 0x28(0x01)
	bool bOverrideFont; // 0x29(0x01)
	bool bOverrideAdditionalKerning; // 0x2a(0x01)
	bool bOverrideShadowOffset; // 0x2b(0x01)
	bool bOverrideShadowColorAndOpacity; // 0x2c(0x01)
	bool bOverrideOuterGlow; // 0x2d(0x01)
	bool bOverrideMargin; // 0x2e(0x01)
	bool bOverrideLineHeightPercentage; // 0x2f(0x01)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct NCUMG.ComboBoxButtonStyleNC01
// Size: 0x4e8 (Inherited: 0x08)
struct FComboBoxButtonStyleNC01 : FSlateWidgetStyle {
	struct FMargin Padding; // 0x08(0x10)
	struct FComboBoxArrowStyleNC01 ArrowStyle; // 0x18(0x1a0)
	struct FBaseTextStyleInfoNC01 BaseTextStyleInfo; // 0x1b8(0x38)
	float AdditionalKerning; // 0x1f0(0x04)
	char pad_1F4[0x4]; // 0x1f4(0x04)
	struct FSlateFontInfo Font; // 0x1f8(0x50)
	struct FSlateColor TextColor; // 0x248(0x28)
	struct FButtonStyle ButtonStyle; // 0x270(0x278)
};

// ScriptStruct NCUMG.ComboBoxArrowStyleNC01
// Size: 0x1a0 (Inherited: 0x08)
struct FComboBoxArrowStyleNC01 : FSlateWidgetStyle {
	struct UDataTable* TextStyleSet; // 0x08(0x08)
	struct FText OpenArrowText; // 0x10(0x18)
	struct FText CloseArrowText; // 0x28(0x18)
	struct FVector2D TextOffset; // 0x40(0x08)
	bool HasOpenArrow; // 0x48(0x01)
	char pad_49[0x7]; // 0x49(0x07)
	struct FSlateBrush OpenArrowImage; // 0x50(0x88)
	bool HasCloseArrow; // 0xd8(0x01)
	char pad_D9[0x7]; // 0xd9(0x07)
	struct FSlateBrush CloseArrowImage; // 0xe0(0x88)
	enum class EComboBoxArrowPosition ArrowPosition; // 0x168(0x01)
	char pad_169[0x3]; // 0x169(0x03)
	struct FVector2D ArrowOffset; // 0x16c(0x08)
	char pad_174[0x4]; // 0x174(0x04)
	struct FSlateColor ArrowColor; // 0x178(0x28)
};

// ScriptStruct NCUMG.ComboBoxCommonInfoNC01
// Size: 0x30 (Inherited: 0x00)
struct FComboBoxCommonInfoNC01 {
	struct FSlateSound PressedSlateSound; // 0x00(0x18)
	struct FSlateSound SelectionChangeSlateSound; // 0x18(0x18)
};

// ScriptStruct NCUMG.ComboBoxStyleNC02
// Size: 0x1368 (Inherited: 0x08)
struct FComboBoxStyleNC02 : FSlateWidgetStyle {
	struct FComboBoxCommonInfoNC01 CommonInfo; // 0x08(0x30)
	struct FComboBoxButtonStyleNC02 ButtonStyle; // 0x38(0x768)
	struct FComboBoxMenuStyleNC02 MenuStyle; // 0x7a0(0xbc8)
};

// ScriptStruct NCUMG.ComboBoxMenuStyleNC02
// Size: 0xbc8 (Inherited: 0x08)
struct FComboBoxMenuStyleNC02 : FSlateWidgetStyle {
	enum class EComboBoxMenuDirectioon MenuDirection; // 0x08(0x01)
	char pad_9[0x3]; // 0x09(0x03)
	float MinListHeight; // 0x0c(0x04)
	float MaxListHeight; // 0x10(0x04)
	float FixedWidth; // 0x14(0x04)
	struct UDataTable* TextStyleSet; // 0x18(0x08)
	struct TArray<struct URichTextBlockDecoratorNC01*> DecoratorClasses; // 0x20(0x10)
	bool bOverrideDefaultStyle; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FTextBlockStyleNC01 DefaultTextStyleOverride; // 0x38(0x308)
	bool bOverrideDefaultStyleTag; // 0x340(0x01)
	char pad_341[0x3]; // 0x341(0x03)
	struct FName OverrideDefaultStyleTagName; // 0x344(0x08)
	char pad_34C[0x4]; // 0x34c(0x04)
	struct FSlateBrush MenuBorderBrush; // 0x350(0x88)
	struct FMargin MenuBorderPadding; // 0x3d8(0x10)
	struct FVector2D MenuBorderOffset; // 0x3e8(0x08)
	struct FTableRowStyle ItemRowStyle; // 0x3f0(0x7c8)
	struct FMargin ItemRowPadding; // 0xbb8(0x10)
};

// ScriptStruct NCUMG.TextBlockStyleNC01
// Size: 0x308 (Inherited: 0x08)
struct FTextBlockStyleNC01 : FSlateWidgetStyle {
	struct FSlateFontInfo Font; // 0x08(0x50)
	float AdditionalKerning; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
	struct FSlateColor ColorAndOpacity; // 0x60(0x28)
	struct FVector2D ShadowOffset; // 0x88(0x08)
	struct FLinearColor ShadowColorAndOpacity; // 0x90(0x10)
	struct FSlateColor SelectedBackgroundColor; // 0xa0(0x28)
	struct FLinearColor HighlightColor; // 0xc8(0x10)
	struct FSlateBrush HighlightShape; // 0xd8(0x88)
	struct FSlateBrush StrikeBrush; // 0x160(0x88)
	struct FSlateBrush BackGroundImageBrush; // 0x1e8(0x88)
	struct FMargin BackGroundImageSizeOffset; // 0x270(0x10)
	struct FSlateBrush UnderlineBrush; // 0x280(0x88)
};

// ScriptStruct NCUMG.ComboBoxButtonStyleNC02
// Size: 0x768 (Inherited: 0x08)
struct FComboBoxButtonStyleNC02 : FSlateWidgetStyle {
	struct FMargin Padding; // 0x08(0x10)
	struct FComboBoxArrowStyleNC01 ArrowStyle; // 0x18(0x1a0)
	struct UDataTable* TextStyleSet; // 0x1b8(0x08)
	struct TArray<struct URichTextBlockDecoratorNC01*> DecoratorClasses; // 0x1c0(0x10)
	bool bOverrideDefaultStyle; // 0x1d0(0x01)
	char pad_1D1[0x7]; // 0x1d1(0x07)
	struct FTextBlockStyleNC01 DefaultTextStyleOverride; // 0x1d8(0x308)
	bool bOverrideDefaultStyleTag; // 0x4e0(0x01)
	char pad_4E1[0x3]; // 0x4e1(0x03)
	struct FName OverrideDefaultStyleTagName; // 0x4e4(0x08)
	char pad_4EC[0x4]; // 0x4ec(0x04)
	struct FButtonStyle ButtonStyle; // 0x4f0(0x278)
};

// ScriptStruct NCUMG.EditableTextBoxStyleNC01
// Size: 0x7f0 (Inherited: 0x08)
struct FEditableTextBoxStyleNC01 : FSlateWidgetStyle {
	struct FSlateBrush BackgroundImageNormal; // 0x08(0x88)
	struct FSlateBrush BackgroundImageHovered; // 0x90(0x88)
	struct FSlateBrush BackgroundImageFocused; // 0x118(0x88)
	struct FSlateBrush BackgroundImageReadOnly; // 0x1a0(0x88)
	struct FMargin Padding; // 0x228(0x10)
	struct FSlateFontInfo Font; // 0x238(0x50)
	struct FSlateColor ForegroundColor; // 0x288(0x28)
	struct FSlateColor BackgroundColor; // 0x2b0(0x28)
	struct FSlateColor ReadOnlyForegroundColor; // 0x2d8(0x28)
	struct FMargin HScrollBarPadding; // 0x300(0x10)
	struct FMargin VScrollBarPadding; // 0x310(0x10)
	struct FScrollBarStyle ScrollBarStyle; // 0x320(0x4d0)
};

// ScriptStruct NCUMG.HintTextStyleInfoNC01
// Size: 0x30 (Inherited: 0x00)
struct FHintTextStyleInfoNC01 {
	struct UDataTable* BaseTextStyleSet; // 0x00(0x08)
	struct TArray<struct FName> StyleTagCandidates; // 0x08(0x10)
	struct FString StyleTag; // 0x18(0x10)
	char pad_28[0x8]; // 0x28(0x08)
};

// ScriptStruct NCUMG.EditableTextStyleNC01
// Size: 0x218 (Inherited: 0x08)
struct FEditableTextStyleNC01 : FSlateWidgetStyle {
	struct FSlateFontInfo Font; // 0x08(0x50)
	struct FSlateColor ColorAndOpacity; // 0x58(0x28)
	struct FSlateBrush BackgroundImageSelected; // 0x80(0x88)
	struct FSlateBrush BackgroundImageComposing; // 0x108(0x88)
	struct FSlateBrush CaretImage; // 0x190(0x88)
};

// ScriptStruct NCUMG.OuterGlowStyleNC01
// Size: 0x38 (Inherited: 0x08)
struct FOuterGlowStyleNC01 : FSlateWidgetStyle {
	bool UseOuterGlow; // 0x08(0x01)
	char pad_9[0x7]; // 0x09(0x07)
	struct UObject* GlowMaterial; // 0x10(0x08)
	struct FLinearColor OuterGlowColor; // 0x18(0x10)
	float OuterGlowRadius; // 0x28(0x04)
	float OuterGlowDensity; // 0x2c(0x04)
	float OuterGlowStrength; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// ScriptStruct NCUMG.SlateFlipBookBrushNC01
// Size: 0x18 (Inherited: 0x00)
struct FSlateFlipBookBrushNC01 {
	char pad_0[0x8]; // 0x00(0x08)
	struct UObject* ResourceObject; // 0x08(0x08)
	struct FVector2D ImageSize; // 0x10(0x08)
};

// ScriptStruct NCUMG.MovieSceneTextStyleMaterialSectionTemplateNC01
// Size: 0xa0 (Inherited: 0x80)
struct FMovieSceneTextStyleMaterialSectionTemplateNC01 : FMovieSceneParameterSectionTemplate {
	struct FName TableKey; // 0x80(0x08)
	struct FString MaterialTypeString; // 0x88(0x10)
	struct UMovieSceneTextStyleMaterialTrackNC01* MaterialTrack; // 0x98(0x08)
};

// ScriptStruct NCUMG.MovieSceneTextStylePropertyTemplateNC01
// Size: 0x38 (Inherited: 0x20)
struct FMovieSceneTextStylePropertyTemplateNC01 : FMovieSceneEvalTemplate {
	struct UMovieSceneTextStyleGlowPropertySectionNC01* PropertySection; // 0x20(0x08)
	struct FName TableKey; // 0x28(0x08)
	char pad_30[0x8]; // 0x30(0x08)
};

// ScriptStruct NCUMG.RichImageRowNC01
// Size: 0xa0 (Inherited: 0x08)
struct FRichImageRowNC01 : FTableRowBase {
	struct FSlateBrush Brush; // 0x08(0x88)
	struct FMargin Margin; // 0x90(0x10)
};

// ScriptStruct NCUMG.RichTextStyleRowNC01
// Size: 0x368 (Inherited: 0x08)
struct FRichTextStyleRowNC01 : FTableRowBase {
	struct FTextBlockStyleNC01 TextStyle; // 0x08(0x308)
	struct FOuterGlowStyleNC01 OuterGlowStyle; // 0x310(0x38)
	struct FTextLayoutStyleNC01 TextLayoutStyle; // 0x348(0x20)
};

// ScriptStruct NCUMG.TextLayoutStyleNC01
// Size: 0x20 (Inherited: 0x08)
struct FTextLayoutStyleNC01 : FSlateWidgetStyle {
	struct FMargin Margin; // 0x08(0x10)
	float LineHeightPercentage; // 0x18(0x04)
	char pad_1C[0x4]; // 0x1c(0x04)
};

// ScriptStruct NCUMG.ScrollBoxAdditionalStyleNC01
// Size: 0xa8 (Inherited: 0x08)
struct FScrollBoxAdditionalStyleNC01 : FSlateWidgetStyle {
	float ContentBorderTop; // 0x08(0x04)
	float ContentBorderBottom; // 0x0c(0x04)
	struct FLinearColor ContentBorderColor; // 0x10(0x10)
	struct FSlateBrush ContentBorderBrush; // 0x20(0x88)
};

// ScriptStruct NCUMG.BackGroundImageStyleNC01
// Size: 0x90 (Inherited: 0x08)
struct FBackGroundImageStyleNC01 : FSlateWidgetStyle {
	struct FSlateBrush BackGroundImageBrush; // 0x08(0x88)
};

// ScriptStruct NCUMG.EllipsisStyleNC01
// Size: 0x20 (Inherited: 0x08)
struct FEllipsisStyleNC01 : FSlateWidgetStyle {
	bool UseEllipsis; // 0x08(0x01)
	bool UsePerLine; // 0x09(0x01)
	char pad_A[0x6]; // 0x0a(0x06)
	struct FString EllipsisString; // 0x10(0x10)
};

// ScriptStruct NCUMG.StrikethroughStyleNC01
// Size: 0xf0 (Inherited: 0x08)
struct FStrikethroughStyleNC01 : FSlateWidgetStyle {
	struct FSlateBrush StrikethroughBrush; // 0x08(0x88)
	float StrikethroughThickness; // 0x90(0x04)
	float StrikethroughVerticalOffset; // 0x94(0x04)
	bool ApplyStrikethroughToAllLines; // 0x98(0x01)
	char pad_99[0x7]; // 0x99(0x07)
	struct TSet<int8_t> LineIndexSetToApplyStrikethrough; // 0xa0(0x50)
};

