// WidgetBlueprintGeneratedClass UI_PowerSavingMode_ChatList.UI_PowerSavingMode_ChatList_C
// Size: 0x2d0 (Inherited: 0x2d0)
struct UUI_PowerSavingMode_ChatList_C : ULMRPowerSavingModeChatSlotWidget {
};

