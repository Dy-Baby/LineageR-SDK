// BlueprintGeneratedClass BP_LMRGameManager.BP_LMRGameManager_C
// Size: 0x118 (Inherited: 0x118)
struct UBP_LMRGameManager_C : ULMRGameManager {
};

